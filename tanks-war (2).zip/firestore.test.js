const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_123";
const BOB_UID = "bob_uid_456";
const CHARLIE_UID = "charlie_uid_789";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validUserProfilePayload(uid, overrides = {}) {
  const now = new Date(Date.now() - 2000);
  return {
    userId: uid,
    displayName: "Comandante T34",
    bombas: 180,
    gemas: 450,
    fichasCentella: 35,
    unlockedTankIds: ["recluta_m4", "especialista_t34"],
    tankLevels: { recluta_m4: 1, especialista_t34: 1 },
    activeTankId: "especialista_t34",
    selectedModeId: "supervivencia_3d",
    dailyDateKey: "2026-11-22",
    dailyFcEarned: 0,
    dailyMatchGemsEarned: 0,
    dailyBonusGemsEarned: 0,
    dailyAdsWatched: 0,
    simulateMondayForTesting: false,
    hasBattlePass: false,
    claimedPassTiers: [],
    totalWins: 0,
    totalMatches: 0,
    totalShotsFired: 0,
    totalDamageDealt: 0,
    totalCardsPlayed: 0,
    totalUpgradesDone: 0,
    totalAdsWatchedAllTime: 0,
    claimedMissionIds: [],
    soundEnabled: true,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validQueuePayload(uid, modeId = "supervivencia_3d", overrides = {}) {
  const now = new Date(Date.now() - 2000);
  return {
    userId: uid,
    displayName: "Player " + uid,
    tankId: "especialista_t34",
    tankLevel: 2,
    modeId,
    status: "WAITING",
    participantUids: [uid],
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validMatchPayload(hostUid, guestUid, modeId = "supervivencia_3d", overrides = {}) {
  const now = new Date(Date.now() - 2000);
  return {
    hostUid,
    guestUid,
    participantUids: [hostUid, guestUid],
    modeId,
    hostName: "Alice",
    hostTankId: "especialista_t34",
    hostLevel: 2,
    guestName: "Bob",
    guestTankId: "epica_kv2",
    guestLevel: 3,
    status: "INTRO",
    hostReady: false,
    guestReady: false,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validPlayerStatePayload(uid, participantUids, overrides = {}) {
  const now = new Date(Date.now() - 2000);
  return {
    userId: uid,
    participantUids,
    x: uid === participantUids[0] ? 2.4 : 27.6,
    y: 7.5,
    chassisAngle: 0.0,
    turretAngle: 0.0,
    hp: 2250,
    maxHp: 2250,
    shieldHp: 0,
    turboActive: false,
    overchargeActive: false,
    recentShots: [],
    claimedPickupIds: [],
    wallHps: { b_west_gate: 1100, b_east_gate: 1100 },
    arenaPickups: [],
    reportedDamageDealt: 0,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated context is denied across all collections", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).set(validUserProfilePayload(ALICE_UID))
  );
  await assertFails(unauthDb.collection("matchmaking_queue").get());
  await assertFails(
    unauthDb.collection("matchmaking_queue").doc(ALICE_UID).set(validQueuePayload(ALICE_UID))
  );
  await assertFails(unauthDb.collection("matches").doc("match_1").get());
  await assertFails(
    unauthDb
      .collection("matches")
      .doc("match_1")
      .collection("players")
      .doc(ALICE_UID)
      .get()
  );
});

test("UserProfile: owner create, partial update, isolation, and field validation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  // Valid create
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(validUserProfilePayload(ALICE_UID))
  );

  // Owner read succeeds
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());

  // Cross-user read & write denied
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({
      bombas: 9999,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Valid partial update preserving createdAt & userId
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      bombas: 205,
      gemas: 500,
      dailyAdsWatched: 1,
      totalAdsWatchedAllTime: 1,
      weeklyOfferClaimedWeekKey: "2026-W47",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Immutable field tamper rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      createdAt: new Date(Date.now() - 100),
      updatedAt: new Date(Date.now() - 100),
    })
  );

  // Invalid dailyAdsWatched > 4 rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      dailyAdsWatched: 5,
      updatedAt: new Date(Date.now() - 100),
    })
  );

  // Shadow extra field rejected
  await assertFails(
    bobDb
      .collection("users")
      .doc(BOB_UID)
      .set(validUserProfilePayload(BOB_UID, { isAdmin: true }))
  );

  // Future timestamp rejected
  await assertFails(
    bobDb
      .collection("users")
      .doc(BOB_UID)
      .set(
        validUserProfilePayload(BOB_UID, {
          updatedAt: new Date(Date.now() + 60000),
        })
      )
  );
});

test("Matchmaking queue: enqueue, heartbeat, filtered query, atomic pairing transaction, and terminal lock", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();

  // Alice enqueues
  await assertSucceeds(
    aliceDb
      .collection("matchmaking_queue")
      .doc(ALICE_UID)
      .set(validQueuePayload(ALICE_UID, "supervivencia_3d"))
  );

  // Alice updates heartbeat
  await assertSucceeds(
    aliceDb.collection("matchmaking_queue").doc(ALICE_UID).update({
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Unfiltered list on matchmaking_queue works only if all matched docs are WAITING or participant;
  // Once a MATCHED doc exists, unfiltered .get() must fail whereas filtered query succeeds!
  await assertSucceeds(
    bobDb
      .collection("matchmaking_queue")
      .where("status", "==", "WAITING")
      .where("modeId", "==", "supervivencia_3d")
      .get()
  );

  // Bob CANNOT spoof MATCHED without creating the /matches/{matchId} doc atomically
  await assertFails(
    bobDb.collection("matchmaking_queue").doc(ALICE_UID).update({
      status: "MATCHED",
      matchId: "nonexistent_match",
      matchedByUid: BOB_UID,
      participantUids: [ALICE_UID, BOB_UID],
      updatedAt: new Date(Date.now() - 400),
    })
  );

  // Bob atomically creates /matches/{matchId} and pairs Alice's ticket via runTransaction
  const matchId = "match_1001_ab";
  await assertSucceeds(
    bobDb.runTransaction(async (tx) => {
      const queueRef = bobDb.collection("matchmaking_queue").doc(ALICE_UID);
      const snap = await tx.get(queueRef);
      if (!snap.exists) throw new Error("Missing queue");
      const matchRef = bobDb.collection("matches").doc(matchId);
      tx.set(matchRef, validMatchPayload(ALICE_UID, BOB_UID, "supervivencia_3d"));
      tx.update(queueRef, {
        status: "MATCHED",
        matchId,
        matchedByUid: BOB_UID,
        participantUids: [ALICE_UID, BOB_UID],
        updatedAt: new Date(Date.now() - 300),
      });
    })
  );

  // Charlie cannot hijack an already MATCHED ticket
  await assertFails(
    charlieDb.collection("matchmaking_queue").doc(ALICE_UID).update({
      status: "MATCHED",
      matchId: "match_hijack",
      matchedByUid: CHARLIE_UID,
      participantUids: [ALICE_UID, CHARLIE_UID],
      updatedAt: new Date(Date.now() - 200),
    })
  );

  // Charlie's unfiltered queue query fails because Alice's ticket is MATCHED and Charlie isn't a participant
  await assertFails(charlieDb.collection("matchmaking_queue").get());

  // Charlie's filtered query for WAITING entries still succeeds!
  await assertSucceeds(
    charlieDb
      .collection("matchmaking_queue")
      .where("status", "==", "WAITING")
      .where("modeId", "==", "supervivencia_3d")
      .get()
  );

  // Alice can delete her own matched queue ticket during cleanup
  await assertSucceeds(aliceDb.collection("matchmaking_queue").doc(ALICE_UID).delete());
});

test("PvP Matches & PlayerState subcollection: lifecycle, participant isolation, bounds, and query alignment", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  const matchId = "match_live_2026";

  // Seed match via Bob pairing
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx
      .firestore()
      .collection("matches")
      .doc(matchId)
      .set(validMatchPayload(ALICE_UID, BOB_UID));
  });

  // Charlie (non-participant) cannot read or update match
  await assertFails(charlieDb.collection("matches").doc(matchId).get());
  await assertFails(
    charlieDb.collection("matches").doc(matchId).update({
      status: "FINISHED",
      winnerUid: CHARLIE_UID,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Both participants create their own player telemetry state
  await assertSucceeds(
    aliceDb
      .collection("matches")
      .doc(matchId)
      .collection("players")
      .doc(ALICE_UID)
      .set(validPlayerStatePayload(ALICE_UID, [ALICE_UID, BOB_UID]))
  );
  await assertSucceeds(
    bobDb
      .collection("matches")
      .doc(matchId)
      .collection("players")
      .doc(BOB_UID)
      .set(validPlayerStatePayload(BOB_UID, [ALICE_UID, BOB_UID]))
  );

  // Alice cannot overwrite Bob's player document
  await assertFails(
    aliceDb
      .collection("matches")
      .doc(matchId)
      .collection("players")
      .doc(BOB_UID)
      .update({
        hp: 0,
        updatedAt: new Date(Date.now() - 400),
      })
  );

  // Out-of-bounds x coordinate > 30 rejected
  await assertFails(
    aliceDb
      .collection("matches")
      .doc(matchId)
      .collection("players")
      .doc(ALICE_UID)
      .update({
        x: 35.0,
        updatedAt: new Date(Date.now() - 400),
      })
  );

  // Alice updates her live pose & recentShots cleanly
  await assertSucceeds(
    aliceDb
      .collection("matches")
      .doc(matchId)
      .collection("players")
      .doc(ALICE_UID)
      .update({
        x: 12.5,
        y: 6.2,
        chassisAngle: 0.35,
        turretAngle: 0.1,
        hp: 2100,
        recentShots: [
          {
            shotId: 1,
            x: 13.2,
            y: 6.3,
            vx: 7.4,
            vy: 0.7,
            damage: 540,
            radius: 0.4,
            heavy: false,
            lightning: false,
          },
        ],
        updatedAt: new Date(Date.now() - 350),
      })
  );

  // Query alignment on players subcollection
  await assertSucceeds(
    aliceDb
      .collection("matches")
      .doc(matchId)
      .collection("players")
      .where("participantUids", "array-contains", ALICE_UID)
      .get()
  );
  // Non-participant cannot run unfiltered list or query Alice's match players
  await assertFails(
    charlieDb
      .collection("matches")
      .doc(matchId)
      .collection("players")
      .get()
  );
  await assertFails(
    charlieDb
      .collection("matches")
      .doc(matchId)
      .collection("players")
      .where("participantUids", "array-contains", ALICE_UID)
      .get()
  );

  // Match transition INTRO -> PLAYING -> FINISHED
  await assertSucceeds(
    aliceDb.collection("matches").doc(matchId).update({
      hostReady: true,
      guestReady: true,
      status: "PLAYING",
      startedAt: new Date(Date.now() - 300),
      updatedAt: new Date(Date.now() - 300),
    })
  );

  await assertSucceeds(
    bobDb.collection("matches").doc(matchId).update({
      status: "FINISHED",
      winnerUid: ALICE_UID,
      updatedAt: new Date(Date.now() - 200),
    })
  );

  // Terminal lock: updates & deletes rejected after FINISHED
  await assertFails(
    bobDb.collection("matches").doc(matchId).update({
      status: "FINISHED",
      winnerUid: BOB_UID,
      updatedAt: new Date(Date.now() - 100),
    })
  );
  await assertFails(aliceDb.collection("matches").doc(matchId).delete());
  await assertFails(
    aliceDb.collection("matches").doc(matchId).collection("players").doc(ALICE_UID).delete()
  );
});
