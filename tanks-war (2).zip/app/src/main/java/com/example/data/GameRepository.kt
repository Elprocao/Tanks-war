package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.CurrencyType
import com.example.model.EconomyRules
import com.example.model.GameStateSnapshot
import com.example.model.TankDefinition
import com.example.model.TankRarity
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.Calendar
import java.util.Locale
import kotlin.random.Random

private val Context.gameDataStore by preferencesDataStore(name = "tanks_war_local_storage")

class GameRepository(private val context: Context) {

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val adapter = moshi.adapter(GameStateSnapshot::class.java)
    private val stateKey = stringPreferencesKey("game_state_json_v1")

    val stateFlow: Flow<GameStateSnapshot> = context.gameDataStore.data.map { prefs ->
        val raw = prefs[stateKey]
        val parsed = if (raw.isNullOrBlank()) {
            GameStateSnapshot(dailyDateKey = currentDateKey())
        } else {
            runCatching { adapter.fromJson(raw) }.getOrNull()
                ?: GameStateSnapshot(dailyDateKey = currentDateKey())
        }
        normalizeForToday(parsed)
    }

    suspend fun ensureInitialized() {
        val current = stateFlow.first()
        saveSnapshot(current)
    }

    suspend fun updateState(transform: (GameStateSnapshot) -> GameStateSnapshot): GameStateSnapshot {
        var result = GameStateSnapshot(dailyDateKey = currentDateKey())
        context.gameDataStore.edit { prefs ->
            val raw = prefs[stateKey]
            val parsed = if (raw.isNullOrBlank()) {
                GameStateSnapshot(dailyDateKey = currentDateKey())
            } else {
                runCatching { adapter.fromJson(raw) }.getOrNull()
                    ?: GameStateSnapshot(dailyDateKey = currentDateKey())
            }
            val normalized = normalizeForToday(parsed)
            result = normalizeForToday(transform(normalized))
            prefs[stateKey] = adapter.toJson(result)
        }
        return result
    }

    private suspend fun saveSnapshot(snapshot: GameStateSnapshot) {
        context.gameDataStore.edit { prefs ->
            prefs[stateKey] = adapter.toJson(normalizeForToday(snapshot))
        }
    }

    private fun normalizeForToday(snapshot: GameStateSnapshot): GameStateSnapshot {
        val today = currentDateKey()
        val withDate = if (snapshot.dailyDateKey != today) {
            snapshot.copy(
                dailyDateKey = today,
                dailyFcEarned = 0,
                dailyMatchGemsEarned = 0,
                dailyBonusGemsEarned = 0,
                dailyAdsWatched = 0
            )
        } else {
            snapshot
        }
        val fixedUnlocked = (withDate.unlockedTankIds + listOf("recluta_m4", "especialista_t34")).distinct()
        val fixedLevels = withDate.tankLevels.toMutableMap().apply {
            fixedUnlocked.forEach { id -> putIfAbsent(id, 1) }
        }
        val fixedActive = if (withDate.activeTankId in fixedUnlocked) {
            withDate.activeTankId
        } else {
            "especialista_t34"
        }
        return withDate.copy(
            unlockedTankIds = fixedUnlocked,
            tankLevels = fixedLevels,
            activeTankId = fixedActive
        )
    }

    fun isMondayAvailable(snapshot: GameStateSnapshot): Boolean {
        val cal = Calendar.getInstance()
        val realMonday = cal.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY
        return realMonday || snapshot.simulateMondayForTesting
    }

    fun isWeeklyOfferClaimedThisWeek(snapshot: GameStateSnapshot): Boolean {
        return snapshot.weeklyOfferClaimedWeekKey == currentWeekKey()
    }

    fun currentDateKey(): String {
        val cal = Calendar.getInstance()
        return String.format(
            Locale.US,
            "%04d-%02d-%02d",
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun currentWeekKey(): String {
        val cal = Calendar.getInstance()
        return String.format(
            Locale.US,
            "%04d-W%02d",
            cal.get(Calendar.YEAR),
            cal.get(Calendar.WEEK_OF_YEAR)
        )
    }

    fun rollRarityFromCrate(random: Random = Random.Default): TankRarity {
        // Exact distribution:
        // Esp: 2.5%, Ep: 7.5%, Mi: 10%, Leg: 13%, Cent: 17%, Estándar: 50% (sum = 100%)
        val roll = random.nextDouble(0.0, 100.0)
        var cumulative = 0.0
        val order = listOf(
            TankRarity.ESPECIAL,
            TankRarity.EPICA,
            TankRarity.MITICA,
            TankRarity.LEGENDARIA,
            TankRarity.CENTELLA,
            TankRarity.ESTANDAR
        )
        for (rarity in order) {
            cumulative += rarity.probabilityPercent
            if (roll < cumulative) return rarity
        }
        return TankRarity.ESTANDAR
    }

    fun pickTankForRarity(rarity: TankRarity, random: Random = Random.Default): TankDefinition {
        val pool = GameCatalog.tanks.filter { it.rarity == rarity }
        return pool[random.nextInt(pool.size)]
    }

    fun canAfford(snapshot: GameStateSnapshot, currency: CurrencyType, amount: Int): Boolean {
        return when (currency) {
            CurrencyType.BOMBAS -> snapshot.bombas >= amount
            CurrencyType.GEMAS -> snapshot.gemas >= amount
            CurrencyType.FICHAS_CENTELLA -> snapshot.fichasCentella >= amount
        }
    }
}
