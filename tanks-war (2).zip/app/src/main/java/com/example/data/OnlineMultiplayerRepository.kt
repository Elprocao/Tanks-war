package com.example.data

import android.content.Context
import com.example.R
import com.example.model.BattleMode
import com.example.model.GameStateSnapshot
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlin.random.Random

class OnlineMultiplayerRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        auth = Firebase.auth
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("Debes iniciar sesión con Google antes de acceder a Firestore.")
    }

    // --- USER PROFILE CLOUD SYNC ---

    fun observeUserProfile(uid: String): Flow<UserProfileDoc?> = flow {
        if (uid.isBlank() || auth.currentUser?.uid != uid) {
            emit(null)
            return@flow
        }
        val path = "users/$uid"
        emitAll(
            db.collection("users").document(uid)
                .snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else snap.toObject(
                        UserProfileDoc::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val toLog = firestoreError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.GET, path)
                    }
                    throw (firestoreError ?: error)
                }
        )
    }

    suspend fun ensureUserProfile(
        uid: String,
        fallbackSnapshot: GameStateSnapshot,
        displayName: String
    ): Result<UserProfileDoc> {
        val path = "users/$uid"
        return try {
            val activeUid = requireUserId()
            require(activeUid == uid) { "User mismatch" }
            val docRef = db.collection("users").document(uid)
            val existing = docRef.get().await()
            if (existing.exists()) {
                val parsed = existing.toObject(
                    UserProfileDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: UserProfileDoc(userId = uid, displayName = UserProfileMapper.sanitizeDisplayName(displayName))
                Result.success(parsed)
            } else {
                val payload = UserProfileMapper.toCreateMap(uid, displayName, fallbackSnapshot)
                docRef.set(payload).await()
                val created = docRef.get().await().toObject(
                    UserProfileDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: UserProfileDoc(userId = uid, displayName = UserProfileMapper.sanitizeDisplayName(displayName))
                Result.success(created)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun saveUserProfile(
        uid: String,
        displayName: String,
        snapshot: GameStateSnapshot
    ): Result<Unit> {
        val path = "users/$uid"
        return try {
            val activeUid = requireUserId()
            require(activeUid == uid) { "User mismatch" }
            val docRef = db.collection("users").document(uid)
            val updateMap = UserProfileMapper.toUpdateMap(displayName, snapshot)
            try {
                docRef.update(updateMap).await()
            } catch (e: FirebaseFirestoreException) {
                if (e.code == FirebaseFirestoreException.Code.NOT_FOUND) {
                    docRef.set(UserProfileMapper.toCreateMap(uid, displayName, snapshot)).await()
                } else {
                    throw e
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- ONLINE MATCHMAKING QUEUE ---

    suspend fun findWaitingOpponents(
        myUid: String,
        modeId: String
    ): Result<List<MatchmakingEntryDoc>> {
        val path = "matchmaking_queue"
        return try {
            val activeUid = requireUserId()
            require(activeUid == myUid) { "User mismatch" }
            val validModeId = BattleMode.fromId(modeId).id
            val querySnap = db.collection(path)
                .whereEqualTo("status", QueueStatus.WAITING.name)
                .whereEqualTo("modeId", validModeId)
                .get()
                .await()

            val nowMs = System.currentTimeMillis()
            val candidates = querySnap.documents
                .mapNotNull { doc ->
                    doc.toObject(
                        MatchmakingEntryDoc::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .filter { entry ->
                    entry.userId.isNotBlank() &&
                        entry.userId != myUid &&
                        QueueStatus.fromRaw(entry.status) == QueueStatus.WAITING
                }
                .filter { entry ->
                    val updatedMs = entry.updatedAt?.toDate()?.time ?: nowMs
                    // Exclude stale ghost entries older than 35 seconds (allow modest clock skew)
                    (nowMs - updatedMs) <= 35_000L
                }
                .sortedBy { it.createdAt?.toDate()?.time ?: 0L }

            Result.success(candidates)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            Result.failure(e)
        }
    }

    suspend fun enqueueSelf(entry: MatchmakingEntryDoc): Result<Unit> {
        val path = "matchmaking_queue/${entry.userId}"
        return try {
            val activeUid = requireUserId()
            require(activeUid == entry.userId) { "Can only enqueue own UID" }
            val docRef = db.collection("matchmaking_queue").document(entry.userId)
            // Always clean up any previously finished/matched ticket so allow create applies cleanly
            try {
                val cur = docRef.get().await()
                if (cur.exists()) {
                    docRef.delete().await()
                }
            } catch (_: Exception) {
                // Continue to set
            }
            docRef.set(entry.toCreateMap()).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun heartbeatQueue(uid: String): Result<Unit> {
        val path = "matchmaking_queue/$uid"
        return try {
            val activeUid = requireUserId()
            require(activeUid == uid) { "Can only heartbeat own ticket" }
            db.collection("matchmaking_queue").document(uid)
                .update(mapOf("updatedAt" to FieldValue.serverTimestamp()))
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun cancelQueue(uid: String): Result<Unit> {
        val path = "matchmaking_queue/$uid"
        return try {
            val currentUid = auth.currentUser?.uid ?: return Result.success(Unit)
            if (currentUid != uid) return Result.success(Unit)
            db.collection("matchmaking_queue").document(uid).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    fun observeQueueTicket(uid: String): Flow<MatchmakingEntryDoc?> = flow {
        if (uid.isBlank() || auth.currentUser?.uid != uid) {
            emit(null)
            return@flow
        }
        val path = "matchmaking_queue/$uid"
        emitAll(
            db.collection("matchmaking_queue").document(uid)
                .snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else snap.toObject(
                        MatchmakingEntryDoc::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val toLog = firestoreError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.GET, path)
                    }
                    throw (firestoreError ?: error)
                }
        )
    }

    suspend fun pairOpponentTransaction(
        myEntry: MatchmakingEntryDoc,
        hostEntry: MatchmakingEntryDoc
    ): Result<String> {
        val matchId = "match_${System.currentTimeMillis()}_${Random.nextInt(1000, 9999)}"
        val path = "matches/$matchId"
        return try {
            val activeUid = requireUserId()
            require(activeUid == myEntry.userId && activeUid != hostEntry.userId) {
                "Invalid matchmaking pairing UIDs"
            }
            val queueRef = db.collection("matchmaking_queue").document(hostEntry.userId)
            val matchRef = db.collection("matches").document(matchId)

            db.runTransaction { tx ->
                val queueSnap = tx.get(queueRef)
                if (!queueSnap.exists()) {
                    throw IllegalStateException("RIVAL_QUEUE_MISSING")
                }
                val currentStatus = queueSnap.getString("status")
                val currentMode = queueSnap.getString("modeId")
                if (currentStatus != QueueStatus.WAITING.name || currentMode != BattleMode.fromId(myEntry.modeId).id) {
                    throw IllegalStateException("RIVAL_ALREADY_MATCHED")
                }

                val matchPayload = PvpMatchMapper.toCreateMap(
                    host = hostEntry,
                    guest = myEntry
                )
                tx.set(matchRef, matchPayload)
                tx.update(
                    queueRef,
                    mapOf(
                        "status" to QueueStatus.MATCHED.name,
                        "matchId" to matchId,
                        "matchedByUid" to myEntry.userId,
                        "participantUids" to listOf(hostEntry.userId, myEntry.userId),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()

            // Remove own queue ticket if one was created before finding host
            try {
                db.collection("matchmaking_queue").document(myEntry.userId).delete().await()
            } catch (_: Exception) {
                // Non-fatal
            }

            Result.success(matchId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    // --- LIVE 1v1 PVP MATCH ROOM & TELEMETRY ---

    suspend fun getMatchOnce(matchId: String): Result<PvpMatchDoc?> {
        val path = "matches/$matchId"
        return try {
            requireUserId()
            val snap = db.collection("matches").document(matchId).get().await()
            val parsed = if (snap.exists()) {
                snap.toObject(PvpMatchDoc::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            } else null
            Result.success(parsed)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    fun observeMatch(matchId: String, uid: String): Flow<PvpMatchDoc?> = flow {
        if (uid.isBlank() || auth.currentUser?.uid != uid) {
            emit(null)
            return@flow
        }
        val path = "matches/$matchId"
        emitAll(
            db.collection("matches").document(matchId)
                .snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else snap.toObject(
                        PvpMatchDoc::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val toLog = firestoreError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(toLog, OperationType.GET, path)
                    }
                    throw (firestoreError ?: error)
                }
        )
    }

    suspend fun createInitialPlayerState(
        matchId: String,
        userId: String,
        participantUids: List<String>,
        x: Float,
        y: Float,
        chassisAngle: Float,
        turretAngle: Float,
        hp: Int,
        maxHp: Int,
        wallHps: Map<String, Int>
    ): Result<Unit> {
        val path = "matches/$matchId/players/$userId"
        return try {
            val activeUid = requireUserId()
            require(activeUid == userId) { "Can only write own player state" }
            val docRef = db.collection("matches").document(matchId)
                .collection("players").document(userId)
            val payload = MatchPlayerStateDoc.toCreateMap(
                userId = userId,
                participantUids = participantUids,
                x = x,
                y = y,
                chassisAngle = chassisAngle,
                turretAngle = turretAngle,
                hp = hp,
                maxHp = maxHp,
                wallHps = wallHps
            )
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun markReadyAndStartIfReady(
        matchId: String,
        isHost: Boolean,
        forceStart: Boolean = false
    ): Result<Unit> {
        val path = "matches/$matchId"
        return try {
            requireUserId()
            val matchRef = db.collection("matches").document(matchId)
            db.runTransaction { tx ->
                val snap = tx.get(matchRef)
                if (!snap.exists()) return@runTransaction
                val status = snap.getString("status") ?: PvpMatchStatus.INTRO.name
                if (status == PvpMatchStatus.FINISHED.name) return@runTransaction

                val hostReady = (snap.getBoolean("hostReady") ?: false) || isHost
                val guestReady = (snap.getBoolean("guestReady") ?: false) || !isHost
                val bothReady = hostReady && guestReady
                val shouldPlay = (bothReady || forceStart) && status == PvpMatchStatus.INTRO.name

                val updates = mutableMapOf<String, Any>(
                    "hostReady" to hostReady,
                    "guestReady" to guestReady,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (shouldPlay) {
                    updates["status"] = PvpMatchStatus.PLAYING.name
                    updates["startedAt"] = FieldValue.serverTimestamp()
                }
                tx.update(matchRef, updates)
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeMatchPlayers(matchId: String, myUid: String): Flow<List<MatchPlayerStateDoc>> = flow {
        if (myUid.isBlank() || auth.currentUser?.uid != myUid) {
            emit(emptyList())
            return@flow
        }
        val path = "matches/$matchId/players"
        emitAll(
            db.collection("matches").document(matchId).collection("players")
                .whereArrayContains("participantUids", myUid)
                .snapshots()
                .map { querySnap ->
                    querySnap.toObjects(
                        MatchPlayerStateDoc::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val toLog = firestoreError ?: (error as? Exception)
                    if (toLog != null && auth.currentUser?.uid == myUid) {
                        handleFirestoreError(toLog, OperationType.LIST, path)
                    }
                    throw (firestoreError ?: error)
                }
        )
    }

    suspend fun publishPlayerState(
        matchId: String,
        userId: String,
        updateMap: Map<String, Any>
    ): Result<Unit> {
        val path = "matches/$matchId/players/$userId"
        return try {
            val activeUid = requireUserId()
            require(activeUid == userId) { "Can only update own player state" }
            db.collection("matches").document(matchId)
                .collection("players").document(userId)
                .update(updateMap)
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun finishMatch(
        matchId: String,
        winnerUid: String,
        forfeitByUid: String? = null
    ): Result<Unit> {
        val path = "matches/$matchId"
        return try {
            requireUserId()
            val matchRef = db.collection("matches").document(matchId)
            db.runTransaction { tx ->
                val snap = tx.get(matchRef)
                if (!snap.exists()) return@runTransaction
                if (snap.getString("status") == PvpMatchStatus.FINISHED.name) return@runTransaction
                val updates = mutableMapOf<String, Any>(
                    "status" to PvpMatchStatus.FINISHED.name,
                    "winnerUid" to winnerUid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (!forfeitByUid.isNullOrBlank()) {
                    updates["forfeitByUid"] = forfeitByUid
                }
                tx.update(matchRef, updates)
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }
}
