package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.model.BattleCard
import com.example.model.BattleCardEffect
import com.example.model.CurrencyType
import com.example.model.MissionDefinition
import com.example.model.MissionProgressType
import com.example.model.ShopPackDefinition
import com.example.model.ShopPackKind
import com.example.model.TankDefinition
import com.example.model.TankHullStyle
import com.example.model.TankRarity
import com.example.ui.theme.CentellaCyan
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.ElixirPurple
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GreenAction
import com.example.ui.theme.RarityEspecial

object GameCatalog {

    val tanks: List<TankDefinition> = listOf(
        TankDefinition(
            id = "recluta_m4",
            name = "Recluta M4",
            subtitle = "Tanque estándar equilibrado",
            rarity = TankRarity.ESTANDAR,
            speedTilesPerSec = 1.5f,
            baseHp = 1900,
            baseDamage = 500,
            unlockCurrency = CurrencyType.BOMBAS,
            unlockCost = 0,
            hullStyle = TankHullStyle.CLASSIC_T34,
            primaryColorHex = 0xFF64748B,
            secondaryColorHex = 0xFF94A3B8,
            unlockedByDefault = true
        ),
        TankDefinition(
            id = "escudero_b1",
            name = "Escudero B1",
            subtitle = "Blindaje compacto de academia",
            rarity = TankRarity.ESTANDAR,
            speedTilesPerSec = 1.5f,
            baseHp = 2000,
            baseDamage = 500,
            unlockCurrency = CurrencyType.BOMBAS,
            unlockCost = 80,
            hullStyle = TankHullStyle.HEAVY_KV2,
            primaryColorHex = 0xFF475569,
            secondaryColorHex = 0xFFCBD5E1
        ),
        TankDefinition(
            id = "especialista_t34",
            name = "Especialista T-34",
            subtitle = "Icono versátil del garaje",
            rarity = TankRarity.ESPECIAL,
            speedTilesPerSec = 1.8f,
            baseHp = 2250,
            baseDamage = 500,
            unlockCurrency = CurrencyType.GEMAS,
            unlockCost = 1000,
            hullStyle = TankHullStyle.CLASSIC_T34,
            primaryColorHex = 0xFF4D7C3E,
            secondaryColorHex = 0xFF74A85B,
            unlockedByDefault = true
        ),
        TankDefinition(
            id = "cazador_stug",
            name = "Cazador StuG",
            subtitle = "Cañón directo de alta precisión",
            rarity = TankRarity.ESPECIAL,
            speedTilesPerSec = 2.0f,
            baseHp = 2480,
            baseDamage = 500,
            unlockCurrency = CurrencyType.GEMAS,
            unlockCost = 1000,
            hullStyle = TankHullStyle.PANZER_FAST,
            primaryColorHex = 0xFF2563EB,
            secondaryColorHex = 0xFF60A5FA
        ),
        TankDefinition(
            id = "kv2_blindado",
            name = "KV-2 Blindado",
            subtitle = "Torreta pesada de choque frontal",
            rarity = TankRarity.EPICA,
            speedTilesPerSec = 2.2f,
            baseHp = 3350,
            baseDamage = 520,
            unlockCurrency = CurrencyType.GEMAS,
            unlockCost = 2200,
            hullStyle = TankHullStyle.HEAVY_KV2,
            primaryColorHex = 0xFF9333EA,
            secondaryColorHex = 0xFFC084FC
        ),
        TankDefinition(
            id = "panzer_relampago",
            name = "Panzer IV Turbo",
            subtitle = "Chasis ágil para flanqueos",
            rarity = TankRarity.EPICA,
            speedTilesPerSec = 2.9f,
            baseHp = 2800,
            baseDamage = 510,
            unlockCurrency = CurrencyType.GEMAS,
            unlockCost = 2650,
            hullStyle = TankHullStyle.PANZER_FAST,
            primaryColorHex = 0xFF7E22CE,
            secondaryColorHex = 0xFFE879F9
        ),
        TankDefinition(
            id = "centauro_mitico",
            name = "Centauro Mítico",
            subtitle = "Orugas rápidas y doble blindaje",
            rarity = TankRarity.MITICA,
            speedTilesPerSec = 4.4f,
            baseHp = 3750,
            baseDamage = 540,
            unlockCurrency = CurrencyType.GEMAS,
            unlockCost = 5000,
            hullStyle = TankHullStyle.CENTAURO_DUAL,
            primaryColorHex = 0xFFE11D48,
            secondaryColorHex = 0xFFFB7185
        ),
        TankDefinition(
            id = "titan_carmesi",
            name = "Titán Carmesí",
            subtitle = "Fortaleza móvil de gran calibre",
            rarity = TankRarity.MITICA,
            speedTilesPerSec = 3.5f,
            baseHp = 4000,
            baseDamage = 550,
            unlockCurrency = CurrencyType.GEMAS,
            unlockCost = 5000,
            hullStyle = TankHullStyle.HEAVY_KV2,
            primaryColorHex = 0xFFBE123C,
            secondaryColorHex = 0xFFFDA4AF
        ),
        TankDefinition(
            id = "soberano_dorado",
            name = "Soberano Dorado",
            subtitle = "Velocidad élite y acero áureo",
            rarity = TankRarity.LEGENDARIA,
            speedTilesPerSec = 5.0f,
            baseHp = 4600,
            baseDamage = 575,
            unlockCurrency = CurrencyType.GEMAS,
            unlockCost = 6200,
            hullStyle = TankHullStyle.SOVEREIGN_GOLD,
            primaryColorHex = 0xFFD97706,
            secondaryColorHex = 0xFFFDE047
        ),
        TankDefinition(
            id = "fenix_legendario",
            name = "Fénix Acorazado",
            subtitle = "Máxima resistencia legendaria",
            rarity = TankRarity.LEGENDARIA,
            speedTilesPerSec = 5.0f,
            baseHp = 5000,
            baseDamage = 600,
            unlockCurrency = CurrencyType.GEMAS,
            unlockCost = 7000,
            hullStyle = TankHullStyle.SOVEREIGN_GOLD,
            primaryColorHex = 0xFFB45309,
            secondaryColorHex = 0xFFFBBF24
        ),
        TankDefinition(
            id = "centella_x900",
            name = "Centella X-900",
            subtitle = "Propulsión eléctrica de 7 cas/seg",
            rarity = TankRarity.CENTELLA,
            speedTilesPerSec = 7.0f,
            baseHp = 7500,
            baseDamage = 625,
            unlockCurrency = CurrencyType.FICHAS_CENTELLA,
            unlockCost = 5500,
            hullStyle = TankHullStyle.CENTELLA_VOLT,
            primaryColorHex = 0xFF0891B2,
            secondaryColorHex = 0xFF67E8F9
        ),
        TankDefinition(
            id = "tormenta_volt",
            name = "Tormenta Volt",
            subtitle = "Apex eléctrico con blindaje extremo",
            rarity = TankRarity.CENTELLA,
            speedTilesPerSec = 7.0f,
            baseHp = 8500,
            baseDamage = 650,
            unlockCurrency = CurrencyType.FICHAS_CENTELLA,
            unlockCost = 7000,
            hullStyle = TankHullStyle.CENTELLA_VOLT,
            primaryColorHex = 0xFF0284C7,
            secondaryColorHex = 0xFF22D3EE
        )
    )

    val aiOpponents: List<TankDefinition> = listOf(
        tanks.first { it.id == "kv2_blindado" },
        tanks.first { it.id == "cazador_stug" },
        tanks.first { it.id == "panzer_relampago" },
        tanks.first { it.id == "centauro_mitico" },
        tanks.first { it.id == "soberano_dorado" }
    )

    val battleDeck: List<BattleCard> = listOf(
        BattleCard(
            id = "card_heavy_bomb",
            name = "Bomba Mega",
            description = "Proyectil pesado 1.8x daño",
            elixirCost = 3,
            effect = BattleCardEffect.HEAVY_BOMB,
            badgeColor = CrimsonDanger
        ),
        BattleCard(
            id = "card_triple_burst",
            name = "Ráfaga x3",
            description = "Dispara 3 bombas en abanico",
            elixirCost = 4,
            effect = BattleCardEffect.TRIPLE_BURST,
            badgeColor = GoldPrimary
        ),
        BattleCard(
            id = "card_shield",
            name = "Escudo",
            description = "Absorbe 900 de daño (4s)",
            elixirCost = 3,
            effect = BattleCardEffect.ARMOR_SHIELD,
            badgeColor = RarityEspecial
        ),
        BattleCard(
            id = "card_turbo",
            name = "Turbo Orugas",
            description = "x1.8 velocidad y recarga (4.5s)",
            elixirCost = 2,
            effect = BattleCardEffect.TURBO_TRACKS,
            badgeColor = ElixirPurple
        ),
        BattleCard(
            id = "card_centella_bolt",
            name = "Rayo Centella",
            description = "Disparo ultrarrápido 2.2x + stun",
            elixirCost = 5,
            effect = BattleCardEffect.CENTELLA_BOLT,
            badgeColor = CentellaCyan
        ),
        BattleCard(
            id = "card_repair",
            name = "Reparación",
            description = "Restaura +22% de vida",
            elixirCost = 4,
            effect = BattleCardEffect.REPAIR_KIT,
            badgeColor = GreenAction
        )
    )

    val missions: List<MissionDefinition> = listOf(
        MissionDefinition(
            id = "m_first_win",
            title = "Primera Victoria",
            description = "Gana 1 batalla en la arena 30x15",
            target = 1,
            rewardGems = 300,
            rewardFc = 2,
            progressType = MissionProgressType.WINS
        ),
        MissionDefinition(
            id = "m_artillery",
            title = "Artillero de Hierro",
            description = "Dispara 20 bombas en combate",
            target = 20,
            rewardGems = 250,
            rewardFc = 1,
            progressType = MissionProgressType.SHOTS_FIRED
        ),
        MissionDefinition(
            id = "m_strategist",
            title = "Estratega Táctico",
            description = "Usa 5 cartas de combate",
            target = 5,
            rewardGems = 450,
            rewardFc = 2,
            progressType = MissionProgressType.CARDS_PLAYED
        ),
        MissionDefinition(
            id = "m_engineer",
            title = "Ingeniero de Garaje",
            description = "Mejora cualquier tanque de nivel",
            target = 1,
            rewardGems = 500,
            rewardFc = 2,
            progressType = MissionProgressType.UPGRADES_DONE
        ),
        MissionDefinition(
            id = "m_demolisher",
            title = "Demoledor Pesado",
            description = "Inflige 6.000 de daño total",
            target = 6000,
            rewardGems = 800,
            rewardFc = 3,
            progressType = MissionProgressType.DAMAGE_DEALT
        ),
        MissionDefinition(
            id = "m_streak_3",
            title = "Comandante Imparable",
            description = "Consigue 3 victorias en duelo",
            target = 3,
            rewardGems = 1200,
            rewardFc = 4,
            progressType = MissionProgressType.WINS
        ),
        MissionDefinition(
            id = "m_veteran_5",
            title = "Leyenda Blindada",
            description = "Consigue 5 victorias en duelo",
            target = 5,
            rewardGems = 2000,
            rewardFc = 5,
            progressType = MissionProgressType.WINS
        ),
        MissionDefinition(
            id = "m_optional_ad",
            title = "Patrocinio Voluntario",
            description = "Mira 1 anuncio opcional en la Tienda",
            target = 1,
            rewardGems = 200,
            rewardFc = 1,
            progressType = MissionProgressType.OPTIONAL_ADS_WATCHED
        )
    )

    val shopPacks: List<ShopPackDefinition> = listOf(
        ShopPackDefinition(
            id = "pack_daily_ad",
            title = "OFERTA DIARIA (AD)",
            subtitle = "Anuncio 100% opcional • Máx. 4/día",
            rewardLabel = "+10 b  +25 g  +5 fc",
            priceLabel = "VER AD",
            kind = ShopPackKind.OPTIONAL_AD,
            bombsGranted = 10,
            gemsGranted = 25,
            fcGranted = 5,
            highlighted = true
        ),
        ShopPackDefinition(
            id = "pack_bombs_30",
            title = "PACK BOMBAS 30",
            subtitle = "Canje directo con gemas",
            rewardLabel = "30 Bombas",
            priceLabel = "100 g",
            kind = ShopPackKind.BOMBS_FOR_GEMS,
            bombsGranted = 30,
            gemCost = 100
        ),
        ShopPackDefinition(
            id = "pack_bombs_100",
            title = "PACK BOMBAS 100",
            subtitle = "Impulso inicial de taller",
            rewardLabel = "100 Bombas",
            priceLabel = "2,49 €",
            kind = ShopPackKind.BOMBS_FOR_EUR,
            bombsGranted = 100
        ),
        ShopPackDefinition(
            id = "pack_bombs_250",
            title = "PACK BOMBAS 250",
            subtitle = "Arsenal táctico completo",
            rewardLabel = "250 Bombas",
            priceLabel = "4,99 €",
            kind = ShopPackKind.BOMBS_FOR_EUR,
            bombsGranted = 250
        ),
        ShopPackDefinition(
            id = "pack_bombs_650",
            title = "PACK BOMBAS 650",
            subtitle = "Reserva de comandante",
            rewardLabel = "650 Bombas",
            priceLabel = "9,99 €",
            kind = ShopPackKind.BOMBS_FOR_EUR,
            bombsGranted = 650
        ),
        ShopPackDefinition(
            id = "pack_bombs_2000",
            title = "SÚPER PACK 2000",
            subtitle = "Máximo valor en bombas",
            rewardLabel = "2000 Bombas",
            priceLabel = "24,99 €",
            kind = ShopPackKind.BOMBS_FOR_EUR,
            bombsGranted = 2000,
            highlighted = true
        ),
        ShopPackDefinition(
            id = "pack_monday_fc",
            title = "OFERTA SEMANAL LUNES",
            subtitle = "Solo lunes • Máx. 1 vez/semana",
            rewardLabel = "150 Fichas Centella",
            priceLabel = "1,99 €",
            kind = ShopPackKind.MONDAY_WEEKLY_FC,
            fcGranted = 150,
            highlighted = true
        )
    )

    data class PassTierReward(val tier: Int, val winsRequired: Int, val bombs: Int, val gems: Int, val fc: Int)

    val passMilestones: List<PassTierReward> = listOf(
        PassTierReward(tier = 1, winsRequired = 1, bombs = 60, gems = 150, fc = 10),
        PassTierReward(tier = 2, winsRequired = 2, bombs = 90, gems = 250, fc = 15),
        PassTierReward(tier = 3, winsRequired = 4, bombs = 140, gems = 400, fc = 25),
        PassTierReward(tier = 4, winsRequired = 6, bombs = 200, gems = 600, fc = 40),
        PassTierReward(tier = 5, winsRequired = 10, bombs = 350, gems = 1000, fc = 80)
    )

    fun tankById(id: String): TankDefinition =
        tanks.firstOrNull { it.id == id } ?: tanks.first()
}
