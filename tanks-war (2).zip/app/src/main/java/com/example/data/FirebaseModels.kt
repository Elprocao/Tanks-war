package com.example.data

import androidx.annotation.Keep
import com.example.model.BattleMode
import com.example.model.EconomyRules
import com.example.model.GameStateSnapshot
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp
import kotlin.math.PI

enum class QueueStatus {
    WAITING,
    MATCHED,
    CANCELLED;

    companion object {
        fun fromRaw(raw: String?): QueueStatus =
            entries.firstOrNull { it.name == raw } ?: CANCELLED
    }
}

enum class PvpMatchStatus {
    INTRO,
    PLAYING,
    FINISHED;

    companion object {
        fun fromRaw(raw: String?): PvpMatchStatus =
            entries.firstOrNull { it.name == raw } ?: INTRO
    }
}

@Keep
@IgnoreExtraProperties
data class UserProfileDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "Comandante",
    val bombas: Int = 180,
    val gemas: Int = 450,
    val fichasCentella: Int = 35,
    val unlockedTankIds: List<String> = listOf("recluta_m4", "especialista_t34"),
    val tankLevels: Map<String, Int> = mapOf("recluta_m4" to 1, "especialista_t34" to 1),
    val activeTankId: String = "especialista_t34",
    val selectedModeId: String = BattleMode.SUPERVIVENCIA_3D.id,
    val dailyDateKey: String = "",
    val dailyFcEarned: Int = 0,
    val dailyMatchGemsEarned: Int = 0,
    val dailyBonusGemsEarned: Int = 0,
    val dailyAdsWatched: Int = 0,
    val weeklyOfferClaimedWeekKey: String? = null,
    val simulateMondayForTesting: Boolean = false,
    val hasBattlePass: Boolean = false,
    val claimedPassTiers: List<Int> = emptyList(),
    val totalWins: Int = 0,
    val totalMatches: Int = 0,
    val totalShotsFired: Int = 0,
    val totalDamageDealt: Int = 0,
    val totalCardsPlayed: Int = 0,
    val totalUpgradesDone: Int = 0,
    val totalAdsWatchedAllTime: Int = 0,
    val claimedMissionIds: List<String> = emptyList(),
    val soundEnabled: Boolean = true,
    val lastCratePullSummary: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

object UserProfileMapper {
    fun sanitizeDisplayName(raw: String?): String {
        val cleaned = raw?.trim().orEmpty()
        return if (cleaned.isEmpty()) "Comandante" else cleaned.take(40)
    }

    fun toSnapshot(doc: UserProfileDoc): GameStateSnapshot = GameStateSnapshot(
        bombas = doc.bombas.coerceAtLeast(0),
        gemas = doc.gemas.coerceAtLeast(0),
        fichasCentella = doc.fichasCentella.coerceAtLeast(0),
        unlockedTankIds = doc.unlockedTankIds.ifEmpty { listOf("recluta_m4", "especialista_t34") }.take(30),
        tankLevels = doc.tankLevels.ifEmpty { mapOf("recluta_m4" to 1, "especialista_t34" to 1) },
        activeTankId = doc.activeTankId.ifBlank { "especialista_t34" }.take(60),
        selectedModeId = BattleMode.fromId(doc.selectedModeId).id,
        dailyDateKey = doc.dailyDateKey.take(20),
        dailyFcEarned = doc.dailyFcEarned.coerceIn(0, EconomyRules.MAX_DAILY_FC),
        dailyMatchGemsEarned = doc.dailyMatchGemsEarned.coerceIn(0, EconomyRules.MAX_DAILY_MATCH_GEMS),
        dailyBonusGemsEarned = doc.dailyBonusGemsEarned.coerceIn(0, EconomyRules.MAX_DAILY_BONUS_GEMS),
        dailyAdsWatched = doc.dailyAdsWatched.coerceIn(0, EconomyRules.MAX_DAILY_ADS),
        weeklyOfferClaimedWeekKey = doc.weeklyOfferClaimedWeekKey?.take(20),
        simulateMondayForTesting = doc.simulateMondayForTesting,
        hasBattlePass = doc.hasBattlePass,
        claimedPassTiers = doc.claimedPassTiers.take(20),
        totalWins = doc.totalWins.coerceAtLeast(0),
        totalMatches = doc.totalMatches.coerceAtLeast(0),
        totalShotsFired = doc.totalShotsFired.coerceAtLeast(0),
        totalDamageDealt = doc.totalDamageDealt.coerceAtLeast(0),
        totalCardsPlayed = doc.totalCardsPlayed.coerceAtLeast(0),
        totalUpgradesDone = doc.totalUpgradesDone.coerceAtLeast(0),
        totalAdsWatchedAllTime = doc.totalAdsWatchedAllTime.coerceAtLeast(0),
        claimedMissionIds = doc.claimedMissionIds.take(30),
        soundEnabled = doc.soundEnabled,
        lastCratePullSummary = doc.lastCratePullSummary?.take(120)
    )

    private fun baseFieldsMap(
        displayName: String,
        snapshot: GameStateSnapshot
    ): MutableMap<String, Any?> {
        val unlocked = (snapshot.unlockedTankIds + listOf("recluta_m4", "especialista_t34"))
            .distinct()
            .take(30)
        val levels = snapshot.tankLevels.entries
            .filter { it.key in unlocked }
            .associate { it.key to it.value.coerceIn(1, EconomyRules.MAX_TANK_LEVEL) }
            .toMutableMap()
        unlocked.forEach { levels.putIfAbsent(it, 1) }

        return mutableMapOf(
            "displayName" to sanitizeDisplayName(displayName),
            "bombas" to snapshot.bombas.coerceIn(0, 10_000_000),
            "gemas" to snapshot.gemas.coerceIn(0, 10_000_000),
            "fichasCentella" to snapshot.fichasCentella.coerceIn(0, 10_000_000),
            "unlockedTankIds" to unlocked,
            "tankLevels" to levels,
            "activeTankId" to (if (snapshot.activeTankId in unlocked) snapshot.activeTankId else "especialista_t34").take(60),
            "selectedModeId" to BattleMode.fromId(snapshot.selectedModeId).id,
            "dailyDateKey" to snapshot.dailyDateKey.take(20),
            "dailyFcEarned" to snapshot.dailyFcEarned.coerceIn(0, EconomyRules.MAX_DAILY_FC),
            "dailyMatchGemsEarned" to snapshot.dailyMatchGemsEarned.coerceIn(0, EconomyRules.MAX_DAILY_MATCH_GEMS),
            "dailyBonusGemsEarned" to snapshot.dailyBonusGemsEarned.coerceIn(0, EconomyRules.MAX_DAILY_BONUS_GEMS),
            "dailyAdsWatched" to snapshot.dailyAdsWatched.coerceIn(0, EconomyRules.MAX_DAILY_ADS),
            "weeklyOfferClaimedWeekKey" to snapshot.weeklyOfferClaimedWeekKey?.takeIf { it.isNotBlank() }?.take(20),
            "simulateMondayForTesting" to snapshot.simulateMondayForTesting,
            "hasBattlePass" to snapshot.hasBattlePass,
            "claimedPassTiers" to snapshot.claimedPassTiers.take(20),
            "totalWins" to snapshot.totalWins.coerceAtLeast(0),
            "totalMatches" to snapshot.totalMatches.coerceAtLeast(0),
            "totalShotsFired" to snapshot.totalShotsFired.coerceAtLeast(0),
            "totalDamageDealt" to snapshot.totalDamageDealt.coerceAtLeast(0),
            "totalCardsPlayed" to snapshot.totalCardsPlayed.coerceAtLeast(0),
            "totalUpgradesDone" to snapshot.totalUpgradesDone.coerceAtLeast(0),
            "totalAdsWatchedAllTime" to snapshot.totalAdsWatchedAllTime.coerceAtLeast(0),
            "claimedMissionIds" to snapshot.claimedMissionIds.take(30),
            "soundEnabled" to snapshot.soundEnabled,
            "lastCratePullSummary" to snapshot.lastCratePullSummary?.takeIf { it.isNotBlank() }?.take(120)
        )
    }

    fun toCreateMap(
        uid: String,
        displayName: String,
        snapshot: GameStateSnapshot
    ): Map<String, Any> {
        val map = baseFieldsMap(displayName, snapshot)
        map["userId"] = uid
        map["createdAt"] = FieldValue.serverTimestamp()
        map["updatedAt"] = FieldValue.serverTimestamp()
        @Suppress("UNCHECKED_CAST")
        return map.filterValues { it != null } as Map<String, Any>
    }

    fun toUpdateMap(
        displayName: String,
        snapshot: GameStateSnapshot
    ): Map<String, Any> {
        val map = baseFieldsMap(displayName, snapshot)
        map["updatedAt"] = FieldValue.serverTimestamp()
        @Suppress("UNCHECKED_CAST")
        return map.filterValues { it != null } as Map<String, Any>
    }
}

@Keep
@IgnoreExtraProperties
data class MatchmakingEntryDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "Comandante",
    val tankId: String = "especialista_t34",
    val tankLevel: Int = 1,
    val modeId: String = BattleMode.SUPERVIVENCIA_3D.id,
    val status: String = QueueStatus.WAITING.name,
    val participantUids: List<String> = emptyList(),
    val matchId: String? = null,
    val matchedByUid: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "userId" to userId,
        "displayName" to UserProfileMapper.sanitizeDisplayName(displayName),
        "tankId" to tankId.ifBlank { "especialista_t34" }.take(60),
        "tankLevel" to tankLevel.coerceIn(1, EconomyRules.MAX_TANK_LEVEL),
        "modeId" to BattleMode.fromId(modeId).id,
        "status" to QueueStatus.WAITING.name,
        "participantUids" to listOf(userId),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class PvpMatchDoc(
    @DocumentId val id: String = "",
    val hostUid: String = "",
    val guestUid: String = "",
    val participantUids: List<String> = emptyList(),
    val modeId: String = BattleMode.SUPERVIVENCIA_3D.id,
    val hostName: String = "Jugador 1",
    val hostTankId: String = "especialista_t34",
    val hostLevel: Int = 1,
    val guestName: String = "Jugador 2",
    val guestTankId: String = "especialista_t34",
    val guestLevel: Int = 1,
    val status: String = PvpMatchStatus.INTRO.name,
    val hostReady: Boolean = false,
    val guestReady: Boolean = false,
    val winnerUid: String? = null,
    val forfeitByUid: String? = null,
    @ServerTimestamp val startedAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

object PvpMatchMapper {
    fun toCreateMap(
        host: MatchmakingEntryDoc,
        guest: MatchmakingEntryDoc
    ): Map<String, Any> = mapOf(
        "hostUid" to host.userId,
        "guestUid" to guest.userId,
        "participantUids" to listOf(host.userId, guest.userId),
        "modeId" to BattleMode.fromId(guest.modeId).id,
        "hostName" to UserProfileMapper.sanitizeDisplayName(host.displayName),
        "hostTankId" to host.tankId.ifBlank { "especialista_t34" }.take(60),
        "hostLevel" to host.tankLevel.coerceIn(1, EconomyRules.MAX_TANK_LEVEL),
        "guestName" to UserProfileMapper.sanitizeDisplayName(guest.displayName),
        "guestTankId" to guest.tankId.ifBlank { "especialista_t34" }.take(60),
        "guestLevel" to guest.tankLevel.coerceIn(1, EconomyRules.MAX_TANK_LEVEL),
        "status" to PvpMatchStatus.INTRO.name,
        "hostReady" to false,
        "guestReady" to false,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

data class RemoteShotData(
    val shotId: Long,
    val x: Float,
    val y: Float,
    val vx: Float,
    val vy: Float,
    val damage: Int,
    val radius: Float,
    val heavy: Boolean,
    val lightning: Boolean
) {
    fun toMap(): Map<String, Any> = mapOf(
        "shotId" to shotId,
        "x" to x.toDouble(),
        "y" to y.toDouble(),
        "vx" to vx.toDouble(),
        "vy" to vy.toDouble(),
        "damage" to damage,
        "radius" to radius.toDouble(),
        "heavy" to heavy,
        "lightning" to lightning
    )

    companion object {
        fun fromMap(map: Map<*, *>): RemoteShotData? {
            val shotId = (map["shotId"] as? Number)?.toLong() ?: return null
            val x = (map["x"] as? Number)?.toFloat() ?: return null
            val y = (map["y"] as? Number)?.toFloat() ?: return null
            val vx = (map["vx"] as? Number)?.toFloat() ?: 0f
            val vy = (map["vy"] as? Number)?.toFloat() ?: 0f
            val dmg = (map["damage"] as? Number)?.toInt() ?: EconomyRules.BASE_BOMB_DAMAGE
            val rad = (map["radius"] as? Number)?.toFloat() ?: 0.40f
            val heavy = map["heavy"] as? Boolean ?: false
            val lightning = map["lightning"] as? Boolean ?: false
            return RemoteShotData(shotId, x, y, vx, vy, dmg, rad, heavy, lightning)
        }
    }
}

data class RemotePickupData(
    val id: Long,
    val spawnId: String,
    val x: Float,
    val y: Float,
    val kind: String
) {
    fun toMap(): Map<String, Any> = mapOf(
        "id" to id,
        "spawnId" to spawnId,
        "x" to x.toDouble(),
        "y" to y.toDouble(),
        "kind" to kind
    )

    companion object {
        fun fromMap(map: Map<*, *>): RemotePickupData? {
            val id = (map["id"] as? Number)?.toLong() ?: return null
            val spawnId = map["spawnId"] as? String ?: return null
            val x = (map["x"] as? Number)?.toFloat() ?: return null
            val y = (map["y"] as? Number)?.toFloat() ?: return null
            val kind = map["kind"] as? String ?: "MEDKIT"
            return RemotePickupData(id, spawnId, x, y, kind)
        }
    }
}

@Keep
@IgnoreExtraProperties
data class MatchPlayerStateDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val participantUids: List<String> = emptyList(),
    val x: Double = 2.4,
    val y: Double = 7.5,
    val chassisAngle: Double = 0.0,
    val turretAngle: Double = 0.0,
    val hp: Int = 2250,
    val maxHp: Int = 2250,
    val shieldHp: Int = 0,
    val turboActive: Boolean = false,
    val overchargeActive: Boolean = false,
    val recentShots: List<Map<String, Any>> = emptyList(),
    val claimedPickupIds: List<Long> = emptyList(),
    val wallHps: Map<String, Int> = emptyMap(),
    val arenaPickups: List<Map<String, Any>> = emptyList(),
    val reportedDamageDealt: Int = 0,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    companion object {
        fun normalizeAngleRad(rad: Float): Double {
            var a = rad.toDouble()
            while (a > PI) a -= 2.0 * PI
            while (a < -PI) a += 2.0 * PI
            return a.coerceIn(-6.9, 6.9)
        }

        fun toCreateMap(
            userId: String,
            participantUids: List<String>,
            x: Float,
            y: Float,
            chassisAngle: Float,
            turretAngle: Float,
            hp: Int,
            maxHp: Int,
            wallHps: Map<String, Int>
        ): Map<String, Any> = mapOf(
            "userId" to userId,
            "participantUids" to participantUids,
            "x" to x.toDouble().coerceIn(0.0, 30.0),
            "y" to y.toDouble().coerceIn(0.0, 15.0),
            "chassisAngle" to normalizeAngleRad(chassisAngle),
            "turretAngle" to normalizeAngleRad(turretAngle),
            "hp" to hp.coerceIn(0, 25000),
            "maxHp" to maxHp.coerceIn(100, 25000),
            "shieldHp" to 0,
            "turboActive" to false,
            "overchargeActive" to false,
            "recentShots" to emptyList<Map<String, Any>>(),
            "claimedPickupIds" to emptyList<Long>(),
            "wallHps" to wallHps.entries.take(8).associate { it.key to it.value.coerceAtLeast(0) },
            "arenaPickups" to emptyList<Map<String, Any>>(),
            "reportedDamageDealt" to 0,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        fun toUpdateMap(
            x: Float,
            y: Float,
            chassisAngle: Float,
            turretAngle: Float,
            hp: Int,
            shieldHp: Int,
            turboActive: Boolean,
            overchargeActive: Boolean,
            recentShots: List<RemoteShotData>,
            claimedPickupIds: List<Long>,
            wallHps: Map<String, Int>,
            arenaPickups: List<RemotePickupData>,
            reportedDamageDealt: Int
        ): Map<String, Any> = mapOf(
            "x" to x.toDouble().coerceIn(0.0, 30.0),
            "y" to y.toDouble().coerceIn(0.0, 15.0),
            "chassisAngle" to normalizeAngleRad(chassisAngle),
            "turretAngle" to normalizeAngleRad(turretAngle),
            "hp" to hp.coerceIn(0, 25000),
            "shieldHp" to shieldHp.coerceIn(0, 5000),
            "turboActive" to turboActive,
            "overchargeActive" to overchargeActive,
            "recentShots" to recentShots.takeLast(8).map { it.toMap() },
            "claimedPickupIds" to claimedPickupIds.takeLast(30),
            "wallHps" to wallHps.entries.take(8).associate { it.key to it.value.coerceAtLeast(0) },
            "arenaPickups" to arenaPickups.take(3).map { it.toMap() },
            "reportedDamageDealt" to reportedDamageDealt.coerceIn(0, 1_000_000),
            "updatedAt" to FieldValue.serverTimestamp()
        )
    }
}
