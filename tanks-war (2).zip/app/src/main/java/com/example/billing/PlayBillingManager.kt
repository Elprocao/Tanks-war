package com.example.billing

import android.app.Activity
import android.content.Context
import android.util.Log
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.ConsumeParams
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.example.data.GameCatalog
import com.example.model.ShopPackKind
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class BillingConnectionState {
    IDLE,
    CONNECTING,
    READY,
    UNAVAILABLE
}

object PurchaseTokenStore {
    private const val PREFS_NAME = "tanks_war_billing_tokens"
    private const val KEY_TOKENS = "processed_tokens_csv"
    private const val MAX_STORED_TOKENS = 100

    @Synchronized
    fun isProcessed(context: Context, purchaseToken: String): Boolean {
        if (purchaseToken.isBlank()) return false
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_TOKENS, "").orEmpty()
        return raw.split('\n').any { it == purchaseToken }
    }

    @Synchronized
    fun markProcessed(context: Context, purchaseToken: String) {
        if (purchaseToken.isBlank()) return
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val existing = prefs.getString(KEY_TOKENS, "").orEmpty()
            .split('\n')
            .filter { it.isNotBlank() }
            .toMutableList()
        if (purchaseToken !in existing) {
            existing.add(purchaseToken)
        }
        val trimmed = existing.takeLast(MAX_STORED_TOKENS).joinToString("\n")
        prefs.edit().putString(KEY_TOKENS, trimmed).apply()
    }
}

class PlayBillingManager(context: Context) {

    companion object {
        private const val TAG = "PlayBilling"

        val INAPP_PRODUCT_IDS: List<String> = GameCatalog.shopPacks
            .filter { it.kind == ShopPackKind.BOMBS_FOR_EUR || it.kind == ShopPackKind.MONDAY_WEEKLY_FC }
            .map { it.id }
    }

    private val appContext = context.applicationContext

    private val _connectionState = MutableStateFlow(BillingConnectionState.IDLE)
    val connectionState: StateFlow<BillingConnectionState> = _connectionState.asStateFlow()

    private val _productDetailsMap = MutableStateFlow<Map<String, ProductDetails>>(emptyMap())
    val productDetailsMap: StateFlow<Map<String, ProductDetails>> = _productDetailsMap.asStateFlow()

    private val _formattedPrices = MutableStateFlow<Map<String, String>>(emptyMap())
    val formattedPrices: StateFlow<Map<String, String>> = _formattedPrices.asStateFlow()

    private val _statusMessage = MutableStateFlow("Conectando con Google Play...")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    @Volatile
    private var purchaseGrantHandler: ((productId: String, quantity: Int, purchaseToken: String) -> Boolean)? = null

    @Volatile
    private var infoToastCallback: ((String) -> Unit)? = null

    private val purchasesUpdatedListener = PurchasesUpdatedListener { billingResult, purchases ->
        when (billingResult.responseCode) {
            BillingClient.BillingResponseCode.OK -> {
                purchases.orEmpty().forEach { purchase ->
                    handlePurchase(purchase)
                }
            }
            BillingClient.BillingResponseCode.USER_CANCELED -> {
                infoToastCallback?.invoke("Compra cancelada")
            }
            BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> {
                queryAndProcessPurchases()
            }
            else -> {
                val msg = mapBillingError(billingResult)
                Log.w(TAG, "PurchasesUpdated error ${billingResult.responseCode}: ${billingResult.debugMessage}")
                infoToastCallback?.invoke(msg)
            }
        }
    }

    private val billingClient: BillingClient = BillingClient.newBuilder(appContext)
        .setListener(purchasesUpdatedListener)
        .enablePendingPurchases(
            PendingPurchasesParams.newBuilder()
                .enableOneTimeProducts()
                .build()
        )
        .enableAutoServiceReconnection()
        .build()

    fun attachPurchaseHandler(
        onGrant: (productId: String, quantity: Int, purchaseToken: String) -> Boolean,
        onMessage: (String) -> Unit
    ) {
        purchaseGrantHandler = onGrant
        infoToastCallback = onMessage
        if (billingClient.isReady) {
            queryAndProcessPurchases()
        }
    }

    fun detachPurchaseHandler() {
        purchaseGrantHandler = null
        infoToastCallback = null
    }

    fun initializeAndConnect() {
        if (billingClient.isReady) {
            _connectionState.value = BillingConnectionState.READY
            if (_productDetailsMap.value.isEmpty()) {
                queryProductDetails()
            }
            queryAndProcessPurchases()
            return
        }
        if (_connectionState.value == BillingConnectionState.CONNECTING) return

        _connectionState.value = BillingConnectionState.CONNECTING
        _statusMessage.value = "Conectando con Google Play Billing..."

        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    _connectionState.value = BillingConnectionState.READY
                    _statusMessage.value = "Google Play Billing conectado"
                    queryProductDetails()
                    queryAndProcessPurchases()
                } else {
                    _connectionState.value = BillingConnectionState.UNAVAILABLE
                    _statusMessage.value = mapBillingError(billingResult)
                    Log.w(TAG, "Billing setup failed (${billingResult.responseCode}): ${billingResult.debugMessage}")
                }
            }

            override fun onBillingServiceDisconnected() {
                _connectionState.value = BillingConnectionState.UNAVAILABLE
                _statusMessage.value = "Servicio de Google Play desconectado (reconexión automática activa)"
                Log.w(TAG, "Billing service disconnected")
            }
        })
    }

    fun queryProductDetails() {
        if (!billingClient.isReady) {
            initializeAndConnect()
            return
        }
        val productList = INAPP_PRODUCT_IDS.map { productId ->
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(productId)
                .setProductType(BillingClient.ProductType.INAPP)
                .build()
        }
        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(productList)
            .build()

        billingClient.queryProductDetailsAsync(params) { billingResult, queryProductDetailsResult ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                val list = queryProductDetailsResult.productDetailsList
                val detailsMap = list.associateBy { it.productId }
                val pricesMap = list.mapNotNull { details ->
                    val price = details.oneTimePurchaseOfferDetails?.formattedPrice
                    if (price.isNullOrBlank()) null else details.productId to price
                }.toMap()

                _productDetailsMap.value = detailsMap
                _formattedPrices.value = pricesMap
                _statusMessage.value = if (detailsMap.isEmpty()) {
                    "Catálogo pendiente de activar en Google Play Console"
                } else {
                    "Google Play listo (${detailsMap.size}/${INAPP_PRODUCT_IDS.size} packs)"
                }
                Log.i(TAG, "Queried ${detailsMap.size} Play products")
            } else {
                _statusMessage.value = mapBillingError(billingResult)
                Log.w(TAG, "queryProductDetailsAsync failed (${billingResult.responseCode}): ${billingResult.debugMessage}")
            }
        }
    }

    fun queryAndProcessPurchases() {
        if (!billingClient.isReady) return
        val params = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.INAPP)
            .build()

        billingClient.queryPurchasesAsync(params) { billingResult, purchases ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                purchases.forEach { purchase ->
                    handlePurchase(purchase)
                }
            } else {
                Log.w(TAG, "queryPurchasesAsync failed (${billingResult.responseCode}): ${billingResult.debugMessage}")
            }
        }
    }

    fun launchPurchase(
        activity: Activity,
        productId: String,
        obfuscatedAccountId: String,
        onError: (String) -> Unit
    ) {
        if (!billingClient.isReady) {
            initializeAndConnect()
            onError("Conectando con Google Play Store. Inténtalo de nuevo en unos segundos.")
            return
        }

        val details = _productDetailsMap.value[productId]
        if (details == null) {
            queryProductDetails()
            onError("Producto '$productId' aún no disponible en Google Play. Revisa tu conexión o los productos integrados en Play Console.")
            return
        }

        val offerToken = details.oneTimePurchaseOfferDetails?.offerToken
        val productDetailsParamsBuilder = BillingFlowParams.ProductDetailsParams.newBuilder()
            .setProductDetails(details)
        if (!offerToken.isNullOrBlank()) {
            productDetailsParamsBuilder.setOfferToken(offerToken)
        }

        val flowParamsBuilder = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(listOf(productDetailsParamsBuilder.build()))

        if (obfuscatedAccountId.isNotBlank()) {
            flowParamsBuilder.setObfuscatedAccountId(obfuscatedAccountId.take(64))
        }

        val result = billingClient.launchBillingFlow(activity, flowParamsBuilder.build())
        if (result.responseCode != BillingClient.BillingResponseCode.OK) {
            onError(mapBillingError(result))
        }
    }

    private fun handlePurchase(purchase: Purchase) {
        when (purchase.purchaseState) {
            Purchase.PurchaseState.PURCHASED -> {
                val token = purchase.purchaseToken
                if (PurchaseTokenStore.isProcessed(appContext, token)) {
                    // Already credited to player profile; ensure Play finishes consuming it
                    consumePurchase(token)
                    return
                }

                val handler = purchaseGrantHandler ?: return
                val qty = purchase.quantity.coerceAtLeast(1)
                var anyGranted = false
                for (productId in purchase.products) {
                    if (handler.invoke(productId, qty, token)) {
                        anyGranted = true
                    }
                }
                if (anyGranted) {
                    PurchaseTokenStore.markProcessed(appContext, token)
                    consumePurchase(token)
                }
            }
            Purchase.PurchaseState.PENDING -> {
                infoToastCallback?.invoke(
                    "Pago pendiente de confirmación en Google Play. Se acreditará automáticamente al completarse."
                )
            }
            else -> Unit
        }
    }

    private fun consumePurchase(purchaseToken: String) {
        val consumeParams = ConsumeParams.newBuilder()
            .setPurchaseToken(purchaseToken)
            .build()
        billingClient.consumeAsync(consumeParams) { billingResult, _ ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                Log.i(TAG, "Consumed purchase successfully")
            } else {
                Log.w(TAG, "consumeAsync failed (${billingResult.responseCode}): ${billingResult.debugMessage}")
            }
        }
    }

    fun endConnection() {
        try {
            if (billingClient.isReady) {
                billingClient.endConnection()
            }
        } catch (_: Throwable) {
        }
    }

    private fun mapBillingError(result: BillingResult): String {
        return when (result.responseCode) {
            BillingClient.BillingResponseCode.BILLING_UNAVAILABLE ->
                "Google Play Billing no está disponible en este dispositivo o cuenta."
            BillingClient.BillingResponseCode.ITEM_UNAVAILABLE ->
                "Este pack no está disponible actualmente en Google Play."
            BillingClient.BillingResponseCode.NETWORK_ERROR,
            BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE,
            BillingClient.BillingResponseCode.SERVICE_DISCONNECTED ->
                "Sin conexión con Google Play Store. Inténtalo de nuevo."
            BillingClient.BillingResponseCode.USER_CANCELED ->
                "Compra cancelada."
            BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED ->
                "Procesando compra pendiente..."
            else ->
                "Error de Google Play Billing (${result.responseCode})."
        }
    }
}
