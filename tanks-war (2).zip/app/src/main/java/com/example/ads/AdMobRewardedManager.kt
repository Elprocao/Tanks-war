package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class RewardedAdStatus {
    INITIALIZING,
    LOADING,
    READY,
    SHOWING,
    UNAVAILABLE
}

class AdMobRewardedManager(context: Context) {

    companion object {
        private const val TAG = "AdMobRewarded"
        const val REWARDED_AD_UNIT_ID = "ca-app-pub-8632805534978950/8225058963"
    }

    private val appContext = context.applicationContext

    private val _status = MutableStateFlow(RewardedAdStatus.INITIALIZING)
    val status: StateFlow<RewardedAdStatus> = _status.asStateFlow()

    private val _statusMessage = MutableStateFlow("Inicializando anuncios...")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private var rewardedAd: RewardedAd? = null
    private var isInitialized = false
    private var isLoading = false

    fun initializeAndPreload() {
        if (isInitialized) {
            preloadIfNeeded()
            return
        }
        MobileAds.initialize(appContext) {
            isInitialized = true
            preloadIfNeeded()
        }
    }

    fun preloadIfNeeded() {
        if (rewardedAd != null) {
            _status.value = RewardedAdStatus.READY
            _statusMessage.value = "Anuncio listo"
            return
        }
        if (isLoading) return
        isLoading = true
        _status.value = RewardedAdStatus.LOADING
        _statusMessage.value = "Cargando anuncio AdMob..."

        val request = AdRequest.Builder().build()
        RewardedAd.load(
            appContext,
            REWARDED_AD_UNIT_ID,
            request,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    isLoading = false
                    rewardedAd = ad
                    _status.value = RewardedAdStatus.READY
                    _statusMessage.value = "Anuncio listo"
                    Log.i(TAG, "Rewarded ad loaded successfully")
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    isLoading = false
                    rewardedAd = null
                    _status.value = RewardedAdStatus.UNAVAILABLE
                    _statusMessage.value = "Sin anuncios disponibles (${loadAdError.code})"
                    Log.w(TAG, "Rewarded ad failed to load: ${loadAdError.message} (${loadAdError.code})")
                }
            }
        )
    }

    fun showRewardedAd(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onClosedWithoutReward: () -> Unit,
        onFailedToShow: (String) -> Unit
    ) {
        val currentAd = rewardedAd
        if (currentAd == null) {
            preloadIfNeeded()
            onFailedToShow("Cargando anuncio de AdMob, inténtalo de nuevo en unos segundos")
            return
        }

        var earnedReward = false
        _status.value = RewardedAdStatus.SHOWING

        currentAd.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                Log.i(TAG, "Rewarded ad displayed full-screen")
            }

            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                _status.value = RewardedAdStatus.LOADING
                preloadIfNeeded()
                if (!earnedReward) {
                    onClosedWithoutReward()
                }
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                rewardedAd = null
                _status.value = RewardedAdStatus.UNAVAILABLE
                preloadIfNeeded()
                onFailedToShow("No se pudo mostrar el anuncio: ${adError.message}")
            }
        }

        currentAd.show(activity) { _ ->
            earnedReward = true
            onRewardEarned()
        }
    }
}
