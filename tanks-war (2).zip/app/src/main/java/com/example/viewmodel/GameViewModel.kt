package com.example.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.GameCatalog
import com.example.data.GameRepository
import com.example.data.MatchPlayerStateDoc
import com.example.data.MatchmakingEntryDoc
import com.example.data.OnlineMultiplayerRepository
import com.example.data.PvpMatchDoc
import com.example.data.PvpMatchStatus
import com.example.data.QueueStatus
import com.example.data.RemotePickupData
import com.example.data.RemoteShotData
import com.example.data.UserProfileMapper
import com.example.model.AppTab
import com.example.model.BattleCardEffect
import com.example.model.BattleMode
import com.example.model.CurrencyType
import com.example.model.EconomyRules
import com.example.model.GameStateSnapshot
import com.example.model.MissionDefinition
import com.example.model.MissionProgressType
import com.example.model.ShopPackDefinition
import com.example.model.ShopPackKind
import com.example.model.TankDefinition
import com.example.model.TankRarity
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

data class CrateOpeningResult(
    val rarity: TankRarity,
    val tank: TankDefinition,
    val wasAlreadyOwned: Boolean,
    val bonusBombas: Int
)

class GameViewModelFactory(
    private val context: Context,
    private val userId: String,
    private val displayName: String
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val appContext = context.applicationContext
        val dbId = appContext.getString(com.example.R.string.firestore_database_id)
        val firestore = FirebaseFirestore.getInstance(dbId)
        val onlineRepo = OnlineMultiplayerRepository(firestore, Firebase.auth)
        val localRepo = GameRepository(appContext)
        return GameViewModel(
            repository = localRepo,
            onlineRepo = onlineRepo,
            userId = userId,
            displayName = UserProfileMapper.sanitizeDisplayName(displayName)
        ) as T
    }
}

class GameViewModel(
    private val repository: GameRepository,
    private val onlineRepo: OnlineMultiplayerRepository,
    val userId: String,
    val displayName: String
) : ViewModel() {

    private val _snapshot = MutableStateFlow(GameStateSnapshot(dailyDateKey = repository.currentDateKey()))
    val snapshot: StateFlow<GameStateSnapshot> = _snapshot.asStateFlow()

    private val _currentTab = MutableStateFlow(AppTab.HOME)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    private val _selectedTankId = MutableStateFlow("especialista_t34")
    val selectedTankId: StateFlow<String> = _selectedTankId.asStateFlow()

    private val _battleState = MutableStateFlow(BattleUiState(playerDisplayName = displayName))
    val battleState: StateFlow<BattleUiState> = _battleState.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _crateResult = MutableStateFlow<CrateOpeningResult?>(null)
    val crateResult: StateFlow<CrateOpeningResult?> = _crateResult.asStateFlow()

    private var profileObserverJob: Job? = null
    private var matchmakingJob: Job? = null
    private var matchRoomObserverJob: Job? = null
    private var playersObserverJob: Job? = null
    private var battleLoopJob: Job? = null

    private var nextEntityId = 1L
    private var nextShotSeq = 1L

    // Active PvP synchronization state (accessed on Main thread inside viewModelScope)
    private var activeMatchDoc: PvpMatchDoc? = null
    private var remotePlayerDoc: MatchPlayerStateDoc? = null
    private var lastRemoteSeenMs: Long = 0L
    private var playingStartedLocalMs: Long = 0L
    private val outgoingShotsBuffer = mutableListOf<RemoteShotData>()
    private val seenRemoteShotIds = mutableSetOf<Long>()
    private val localClaimedPickupIds = mutableSetOf<Long>()
    private val rewardedMatchIds = mutableSetOf<String>()
    private var forceImmediateSync = false

    // Real-time 360-degree twin-stick joystick inputs (Blue = move, Red = aim/fire)
    @Volatile
    private var moveVecX: Float = 0f

    @Volatile
    private var moveVecY: Float = 0f

    @Volatile
    private var aimVecX: Float = 0f

    @Volatile
    private var aimVecY: Float = 0f

    @Volatile
    private var aimStickActive: Boolean = false

    @Volatile
    private var aimStickFiring: Boolean = false

    @Volatile
    private var pendingReleaseShotAngle: Float? = null

    init {
        initializeCloudAndLocalProfile()
    }

    private fun initializeCloudAndLocalProfile() {
        profileObserverJob?.cancel()
        profileObserverJob = viewModelScope.launch {
            repository.ensureInitialized()
            val localFallback = repository.stateFlow.first()
            _snapshot.value = localFallback

            onlineRepo.ensureUserProfile(
                uid = userId,
                fallbackSnapshot = localFallback,
                displayName = displayName
            ).onFailure {
                showToast("Conectando perfil en la nube...")
            }

            onlineRepo.observeUserProfile(userId)
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val root = firestoreError ?: error
                    showToast("Error sincronizando perfil: ${root.localizedMessage ?: "sin conexión"}")
                }
                .collect { cloudDoc ->
                    if (cloudDoc != null) {
                        val mapped = UserProfileMapper.toSnapshot(cloudDoc)
                        val normalized = normalizeDailyDate(mapped)
                        _snapshot.value = normalized
                        repository.updateState { normalized }
                        if (normalized.dailyDateKey != mapped.dailyDateKey) {
                            onlineRepo.saveUserProfile(userId, displayName, normalized)
                        }
                    }
                }
        }
    }

    private fun normalizeDailyDate(snapshot: GameStateSnapshot): GameStateSnapshot {
        val today = repository.currentDateKey()
        return if (snapshot.dailyDateKey != today) {
            snapshot.copy(
                dailyDateKey = today,
                dailyFcEarned = 0,
                dailyMatchGemsEarned = 0,
                dailyBonusGemsEarned = 0,
                dailyAdsWatched = 0
            )
        } else {
            snapshot
        }
    }

    private suspend fun updateProfileEverywhere(
        transform: (GameStateSnapshot) -> GameStateSnapshot
    ): GameStateSnapshot {
        val updated = repository.updateState(transform)
        _snapshot.value = updated
        onlineRepo.saveUserProfile(userId, displayName, updated)
        return updated
    }

    suspend fun cleanupBeforeSignOut() {
        withContext(NonCancellable) {
            val activeState = _battleState.value
            val currentMatchId = activeState.matchId
            val match = activeMatchDoc
            if (currentMatchId != null && match != null &&
                (activeState.phase == BattlePhase.VS_INTRO || activeState.phase == BattlePhase.PLAYING)
            ) {
                val opponentUid = if (activeState.isHost) match.guestUid else match.hostUid
                onlineRepo.finishMatch(currentMatchId, winnerUid = opponentUid, forfeitByUid = userId)
            }
            onlineRepo.cancelQueue(userId)
            matchmakingJob?.cancel()
            matchRoomObserverJob?.cancel()
            playersObserverJob?.cancel()
            battleLoopJob?.cancel()
            profileObserverJob?.cancel()
        }
    }

    fun selectTab(tab: AppTab) {
        if (tab == AppTab.BATTLE && _battleState.value.phase == BattlePhase.IDLE) {
            startNewBattle()
            return
        }
        _currentTab.value = tab
    }

    fun selectTankForPreview(tankId: String) {
        _selectedTankId.value = tankId
    }

    fun dismissToast() {
        _toastMessage.value = null
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun isMondayOfferUnlocked(): Boolean {
        val state = _snapshot.value
        return repository.isMondayAvailable(state) && !repository.isWeeklyOfferClaimedThisWeek(state)
    }

    fun isMondayTodayOrSimulated(): Boolean = repository.isMondayAvailable(_snapshot.value)

    fun isWeeklyOfferClaimedThisWeek(): Boolean = repository.isWeeklyOfferClaimedThisWeek(_snapshot.value)

    fun toggleSimulateMonday(enabled: Boolean) {
        viewModelScope.launch {
            updateProfileEverywhere { it.copy(simulateMondayForTesting = enabled) }
            showToast(
                if (enabled) "Modo prueba: Lunes simulado activado"
                else "Modo prueba: Usando día real del sistema"
            )
        }
    }

    fun resetDailyLimitsForTesting() {
        viewModelScope.launch {
            updateProfileEverywhere {
                it.copy(
                    dailyFcEarned = 0,
                    dailyMatchGemsEarned = 0,
                    dailyBonusGemsEarned = 0,
                    dailyAdsWatched = 0,
                    weeklyOfferClaimedWeekKey = null
                )
            }
            showToast("Límites diarios y oferta semanal reiniciados")
        }
    }

    fun resetAllProgress() {
        viewModelScope.launch {
            updateProfileEverywhere {
                GameStateSnapshot(dailyDateKey = repository.currentDateKey())
            }
            _selectedTankId.value = "especialista_t34"
            showToast("Progreso reiniciado")
        }
    }

    fun toggleSound(enabled: Boolean) {
        viewModelScope.launch {
            updateProfileEverywhere { it.copy(soundEnabled = enabled) }
        }
    }

    fun selectBattleMode(mode: BattleMode) {
        viewModelScope.launch {
            updateProfileEverywhere { it.copy(selectedModeId = mode.id) }
            showToast("Modo seleccionado: ${mode.title}")
        }
    }

    // --- TANK GARAGE ACTIONS ---

    fun equipTank(tankId: String) {
        val state = _snapshot.value
        if (tankId !in state.unlockedTankIds) {
            showToast("Desbloquea este tanque primero")
            return
        }
        viewModelScope.launch {
            updateProfileEverywhere { it.copy(activeTankId = tankId) }
            val tank = GameCatalog.tankById(tankId)
            showToast("${tank.name} equipado para batalla")
        }
    }

    fun unlockTank(tank: TankDefinition) {
        val state = _snapshot.value
        if (tank.id in state.unlockedTankIds) return
        if (!repository.canAfford(state, tank.unlockCurrency, tank.unlockCost)) {
            showToast("Te faltan ${tank.unlockCost} ${tank.unlockCurrency.symbol} para desbloquearlo")
            return
        }
        viewModelScope.launch {
            updateProfileEverywhere { cur ->
                if (!repository.canAfford(cur, tank.unlockCurrency, tank.unlockCost)) return@updateProfileEverywhere cur
                val updatedLevels = cur.tankLevels.toMutableMap().apply { put(tank.id, 1) }
                cur.copy(
                    bombas = if (tank.unlockCurrency == CurrencyType.BOMBAS) cur.bombas - tank.unlockCost else cur.bombas,
                    gemas = if (tank.unlockCurrency == CurrencyType.GEMAS) cur.gemas - tank.unlockCost else cur.gemas,
                    fichasCentella = if (tank.unlockCurrency == CurrencyType.FICHAS_CENTELLA) cur.fichasCentella - tank.unlockCost else cur.fichasCentella,
                    unlockedTankIds = (cur.unlockedTankIds + tank.id).distinct(),
                    tankLevels = updatedLevels,
                    activeTankId = tank.id
                )
            }
            showToast("¡${tank.name} desbloqueado y equipado!")
        }
    }

    fun upgradeTank(tank: TankDefinition) {
        val state = _snapshot.value
        if (tank.id !in state.unlockedTankIds) {
            showToast("Primero debes desbloquear el tanque")
            return
        }
        val currentLevel = state.tankLevels[tank.id] ?: 1
        if (currentLevel >= EconomyRules.MAX_TANK_LEVEL) {
            showToast("${tank.name} ya está al nivel máximo (10)")
            return
        }
        val cost = EconomyRules.upgradeCostBombas(currentLevel)
        if (state.bombas < cost) {
            showToast("Necesitas $cost Bombas para subir a nivel ${currentLevel + 1}")
            return
        }
        viewModelScope.launch {
            updateProfileEverywhere { cur ->
                val lvl = cur.tankLevels[tank.id] ?: 1
                val stepCost = EconomyRules.upgradeCostBombas(lvl)
                if (lvl >= EconomyRules.MAX_TANK_LEVEL || cur.bombas < stepCost) return@updateProfileEverywhere cur
                val nextMap = cur.tankLevels.toMutableMap().apply { put(tank.id, lvl + 1) }
                cur.copy(
                    bombas = cur.bombas - stepCost,
                    tankLevels = nextMap,
                    totalUpgradesDone = cur.totalUpgradesDone + 1
                )
            }
            showToast("¡${tank.name} subió a Nivel ${currentLevel + 1}!")
        }
    }

    fun openTankCrate() {
        val state = _snapshot.value
        val cost = EconomyRules.CRATE_COST_GEMAS
        if (state.gemas < cost) {
            showToast("Necesitas $cost Gemas para abrir una Caja de Tanque")
            return
        }
        val rarity = repository.rollRarityFromCrate()
        val pulledTank = repository.pickTankForRarity(rarity)
        val alreadyOwned = pulledTank.id in state.unlockedTankIds
        val bonusBombas = if (alreadyOwned) {
            when (rarity) {
                TankRarity.ESTANDAR -> 45
                TankRarity.ESPECIAL -> 80
                TankRarity.EPICA -> 130
                TankRarity.MITICA -> 220
                TankRarity.LEGENDARIA -> 320
                TankRarity.CENTELLA -> 450
            }
        } else {
            25
        }
        viewModelScope.launch {
            updateProfileEverywhere { cur ->
                if (cur.gemas < cost) return@updateProfileEverywhere cur
                val nextUnlocked = (cur.unlockedTankIds + pulledTank.id).distinct()
                val nextLevels = cur.tankLevels.toMutableMap().apply { putIfAbsent(pulledTank.id, 1) }
                cur.copy(
                    gemas = cur.gemas - cost,
                    bombas = cur.bombas + bonusBombas,
                    unlockedTankIds = nextUnlocked,
                    tankLevels = nextLevels,
                    lastCratePullSummary = "${pulledTank.name} (${rarity.displayName})"
                )
            }
            _crateResult.value = CrateOpeningResult(
                rarity = rarity,
                tank = pulledTank,
                wasAlreadyOwned = alreadyOwned,
                bonusBombas = bonusBombas
            )
            _selectedTankId.value = pulledTank.id
        }
    }

    fun dismissCrateResult() {
        _crateResult.value = null
    }

    // --- SHOP, REAL ADMOB REWARDED ADS & GOOGLE PLAY BILLING ---

    fun canWatchOptionalAdToday(): Boolean =
        _snapshot.value.dailyAdsWatched < EconomyRules.MAX_DAILY_ADS

    fun buyGemBombPack(pack: ShopPackDefinition) {
        if (pack.kind != ShopPackKind.BOMBS_FOR_GEMS) return
        val state = _snapshot.value
        if (state.gemas < pack.gemCost) {
            showToast("Necesitas ${pack.gemCost} Gemas para este pack")
            return
        }
        viewModelScope.launch {
            updateProfileEverywhere { cur ->
                if (cur.gemas < pack.gemCost) return@updateProfileEverywhere cur
                cur.copy(
                    gemas = cur.gemas - pack.gemCost,
                    bombas = cur.bombas + pack.bombsGranted
                )
            }
            showToast("+${pack.bombsGranted} Bombas añadidas")
        }
    }

    fun canStartPlayPurchase(pack: ShopPackDefinition): Boolean {
        val state = _snapshot.value
        return when (pack.kind) {
            ShopPackKind.BOMBS_FOR_EUR -> true
            ShopPackKind.MONDAY_WEEKLY_FC -> {
                if (!repository.isMondayAvailable(state)) {
                    showToast("Oferta bloqueada: solo disponible los lunes (activa 'Simular Lunes' para probar)")
                    false
                } else if (repository.isWeeklyOfferClaimedThisWeek(state)) {
                    showToast("Ya compraste la Oferta Semanal esta semana (máx. 1/semana)")
                    false
                } else {
                    true
                }
            }
            else -> false
        }
    }

    /**
     * Invoked EXCLUSIVELY from PlayBillingManager when Google Play reports PurchaseState.PURCHASED
     * for a non-consumed, deduplicated purchaseToken.
     */
    fun grantVerifiedPlayPurchase(productId: String, quantity: Int): Boolean {
        val pack = GameCatalog.shopPacks.firstOrNull { it.id == productId } ?: return false
        val qty = quantity.coerceAtLeast(1)
        viewModelScope.launch {
            updateProfileEverywhere { cur ->
                when (pack.kind) {
                    ShopPackKind.BOMBS_FOR_EUR -> cur.copy(
                        bombas = cur.bombas + (pack.bombsGranted * qty)
                    )
                    ShopPackKind.MONDAY_WEEKLY_FC -> cur.copy(
                        fichasCentella = cur.fichasCentella + (pack.fcGranted * qty),
                        weeklyOfferClaimedWeekKey = repository.currentWeekKey()
                    )
                    else -> cur
                }
            }
            val rewardText = if (pack.fcGranted > 0) {
                "+${pack.fcGranted * qty} Fichas Centella"
            } else {
                "+${pack.bombsGranted * qty} Bombas"
            }
            showToast("Compra Google Play completada: $rewardText")
        }
        return true
    }

    /**
     * Invoked EXCLUSIVELY from Google AdMob's OnUserEarnedRewardListener once the user
     * finishes watching a real rewarded ad.
     */
    fun grantRewardedAdPack(pack: ShopPackDefinition) {
        viewModelScope.launch {
            var grantedGems = 0
            var grantedFc = 0
            var awarded = false
            updateProfileEverywhere { cur ->
                if (cur.dailyAdsWatched >= EconomyRules.MAX_DAILY_ADS) return@updateProfileEverywhere cur
                awarded = true
                val roomBonusGems = (EconomyRules.MAX_DAILY_BONUS_GEMS - cur.dailyBonusGemsEarned).coerceAtLeast(0)
                grantedGems = min(pack.gemsGranted, roomBonusGems)
                val roomFc = (EconomyRules.MAX_DAILY_FC - cur.dailyFcEarned).coerceAtLeast(0)
                grantedFc = min(pack.fcGranted, roomFc)
                cur.copy(
                    bombas = cur.bombas + pack.bombsGranted,
                    gemas = cur.gemas + grantedGems,
                    fichasCentella = cur.fichasCentella + grantedFc,
                    dailyBonusGemsEarned = cur.dailyBonusGemsEarned + grantedGems,
                    dailyFcEarned = cur.dailyFcEarned + grantedFc,
                    dailyAdsWatched = cur.dailyAdsWatched + 1,
                    totalAdsWatchedAllTime = cur.totalAdsWatchedAllTime + 1
                )
            }
            if (awarded) {
                showToast("Recompensa AdMob: +${pack.bombsGranted} b, +$grantedGems g, +$grantedFc fc")
            } else {
                showToast("Límite diario de 4 anuncios alcanzado por hoy")
            }
        }
    }

    // --- MISSIONS & BATTLE PASS ---

    fun missionProgress(mission: MissionDefinition, state: GameStateSnapshot = _snapshot.value): Int {
        return when (mission.progressType) {
            MissionProgressType.WINS -> state.totalWins
            MissionProgressType.SHOTS_FIRED -> state.totalShotsFired
            MissionProgressType.DAMAGE_DEALT -> state.totalDamageDealt
            MissionProgressType.CARDS_PLAYED -> state.totalCardsPlayed
            MissionProgressType.UPGRADES_DONE -> state.totalUpgradesDone
            MissionProgressType.OPTIONAL_ADS_WATCHED -> state.totalAdsWatchedAllTime
        }
    }

    fun claimMission(mission: MissionDefinition) {
        val state = _snapshot.value
        if (mission.id in state.claimedMissionIds) return
        if (missionProgress(mission, state) < mission.target) {
            showToast("Aún no completas esta misión")
            return
        }
        viewModelScope.launch {
            updateProfileEverywhere { cur ->
                if (mission.id in cur.claimedMissionIds) return@updateProfileEverywhere cur
                cur.copy(
                    gemas = cur.gemas + mission.rewardGems,
                    fichasCentella = cur.fichasCentella + mission.rewardFc,
                    claimedMissionIds = cur.claimedMissionIds + mission.id
                )
            }
            showToast("Misión reclamada: +${mission.rewardGems} g y +${mission.rewardFc} fc")
        }
    }

    fun unlockBattlePass() {
        val state = _snapshot.value
        if (state.hasBattlePass) return
        if (state.gemas < EconomyRules.BATTLE_PASS_COST_GEMS) {
            showToast("Necesitas ${EconomyRules.BATTLE_PASS_COST_GEMS} Gemas para activar el Pase")
            return
        }
        viewModelScope.launch {
            updateProfileEverywhere { cur ->
                if (cur.hasBattlePass || cur.gemas < EconomyRules.BATTLE_PASS_COST_GEMS) return@updateProfileEverywhere cur
                cur.copy(
                    gemas = cur.gemas - EconomyRules.BATTLE_PASS_COST_GEMS,
                    hasBattlePass = true
                )
            }
            showToast("¡Pase de Guerra activado!")
        }
    }

    fun claimPassTier(tier: GameCatalog.PassTierReward) {
        val state = _snapshot.value
        if (!state.hasBattlePass) {
            showToast("Activa el Pase de Guerra (1500 g) para reclamar sus hitos")
            return
        }
        if (tier.tier in state.claimedPassTiers) return
        if (state.totalWins < tier.winsRequired) {
            showToast("Necesitas ${tier.winsRequired} victorias para este hito")
            return
        }
        viewModelScope.launch {
            updateProfileEverywhere { cur ->
                if (!cur.hasBattlePass || tier.tier in cur.claimedPassTiers) return@updateProfileEverywhere cur
                cur.copy(
                    bombas = cur.bombas + tier.bombs,
                    gemas = cur.gemas + tier.gems,
                    fichasCentella = cur.fichasCentella + tier.fc,
                    claimedPassTiers = cur.claimedPassTiers + tier.tier
                )
            }
            showToast("Hito ${tier.tier}: +${tier.bombs} b, +${tier.gems} g, +${tier.fc} fc")
        }
    }

    // --- ONLINE REAL-PLAYER PVP MATCHMAKING & LIVE 1v1 ARENA ---

    fun startNewBattle() {
        cancelAllBattleJobs()
        resetJoystickInputs()

        val state = _snapshot.value
        val selectedMode = BattleMode.fromId(state.selectedModeId)
        val playerTank = GameCatalog.tankById(state.activeTankId)
        val playerLevel = (state.tankLevels[playerTank.id] ?: 1).coerceIn(1, EconomyRules.MAX_TANK_LEVEL)

        _battleState.value = BattleUiState(
            phase = BattlePhase.MATCHMAKING,
            battleMode = selectedMode,
            playerDisplayName = displayName,
            playerTank = playerTank,
            playerLevel = playerLevel,
            matchmakingElapsedSec = 0,
            matchmakingStatusText = "Conectando al servidor de emparejamiento..."
        )
        _currentTab.value = AppTab.BATTLE

        val myEntry = MatchmakingEntryDoc(
            userId = userId,
            displayName = displayName,
            tankId = playerTank.id,
            tankLevel = playerLevel,
            modeId = selectedMode.id
        )

        matchmakingJob = viewModelScope.launch {
            var paired = false

            // 1. Check immediately if another real player is already waiting in the queue
            val initialScan = onlineRepo.findWaitingOpponents(userId, selectedMode.id)
            val firstCandidate = initialScan.getOrNull()?.firstOrNull()
            if (firstCandidate != null) {
                val pairRes = onlineRepo.pairOpponentTransaction(myEntry, firstCandidate)
                val matchId = pairRes.getOrNull()
                if (matchId != null) {
                    paired = true
                    enterPairedMatch(matchId = matchId, isHost = false)
                    return@launch
                }
            }

            // 2. Otherwise enqueue ourselves and wait for either an opponent to claim us OR scan periodically
            _battleState.update {
                it.copy(matchmakingStatusText = "Buscando jugador real en ${selectedMode.title}...")
            }
            val enqueueResult = onlineRepo.enqueueSelf(myEntry)
            if (enqueueResult.isFailure) {
                showToast("No se pudo conectar al matchmaking: verifica tu conexión")
                exitBattleToHome()
                return@launch
            }

            // Listen to our own ticket in case an incoming player pairs with us (making us Host)
            val ticketWatcher = launch {
                onlineRepo.observeQueueTicket(userId)
                    .catch { error ->
                        val firestoreError = generateSequence(error) { it.cause }
                            .filterIsInstance<FirebaseFirestoreException>()
                            .firstOrNull()
                        if (firestoreError == null && error is CancellationException) throw error
                    }
                    .collect { ticket ->
                        if (!paired && ticket != null &&
                            QueueStatus.fromRaw(ticket.status) == QueueStatus.MATCHED &&
                            !ticket.matchId.isNullOrBlank()
                        ) {
                            paired = true
                            enterPairedMatch(matchId = ticket.matchId, isHost = true)
                        }
                    }
            }

            // Heartbeat + periodic queue scan loop
            var elapsedSec = 0
            while (!paired) {
                delay(1000L)
                if (paired) break
                elapsedSec++
                _battleState.update {
                    it.copy(
                        matchmakingElapsedSec = elapsedSec,
                        matchmakingStatusText = when {
                            elapsedSec < 5 -> "Buscando jugadores reales en ${selectedMode.title}..."
                            elapsedSec < 15 -> "Sala activa: esperando rival real en línea..."
                            else -> "Cola abierta: comparte o abre el juego en otro dispositivo..."
                        }
                    )
                }

                // Heartbeat every 7s so opponents know this player is live
                if (elapsedSec % 7 == 0) {
                    onlineRepo.heartbeatQueue(userId)
                }

                // Active re-scan every 3s with deterministic tie-breaker for simultaneous enqueues
                if (elapsedSec % 3 == 0 && !paired) {
                    val candidates = onlineRepo.findWaitingOpponents(userId, selectedMode.id)
                        .getOrNull()
                        .orEmpty()
                    val eligible = if (elapsedSec < 4) {
                        candidates.firstOrNull { it.userId < userId }
                    } else {
                        candidates.firstOrNull()
                    }
                    if (eligible != null && !paired) {
                        val res = onlineRepo.pairOpponentTransaction(myEntry, eligible)
                        val matchId = res.getOrNull()
                        if (matchId != null) {
                            paired = true
                            ticketWatcher.cancel()
                            enterPairedMatch(matchId = matchId, isHost = false)
                            break
                        }
                    }
                }
            }
        }
    }

    private fun enterPairedMatch(matchId: String, isHost: Boolean) {
        matchmakingJob?.cancel()
        viewModelScope.launch {
            onlineRepo.cancelQueue(userId)
            val matchDoc = onlineRepo.getMatchOnce(matchId).getOrNull()
            if (matchDoc == null) {
                showToast("La sala PvP cerró antes de iniciar")
                exitBattleToHome()
                return@launch
            }
            activeMatchDoc = matchDoc
            remotePlayerDoc = null
            lastRemoteSeenMs = System.currentTimeMillis()
            playingStartedLocalMs = 0L
            outgoingShotsBuffer.clear()
            seenRemoteShotIds.clear()
            localClaimedPickupIds.clear()
            forceImmediateSync = false

            val mode = BattleMode.fromId(matchDoc.modeId)
            val myTankId = if (isHost) matchDoc.hostTankId else matchDoc.guestTankId
            val myLevel = (if (isHost) matchDoc.hostLevel else matchDoc.guestLevel).coerceIn(1, EconomyRules.MAX_TANK_LEVEL)
            val myName = if (isHost) matchDoc.hostName else matchDoc.guestName

            val enemyTankId = if (isHost) matchDoc.guestTankId else matchDoc.hostTankId
            val enemyLevel = (if (isHost) matchDoc.guestLevel else matchDoc.hostLevel).coerceIn(1, EconomyRules.MAX_TANK_LEVEL)
            val enemyName = if (isHost) matchDoc.guestName else matchDoc.hostName

            val playerTank = GameCatalog.tankById(myTankId)
            val enemyTank = GameCatalog.tankById(enemyTankId)

            val playerMaxHp = playerTank.hpAtLevel(myLevel)
            val enemyMaxHp = enemyTank.hpAtLevel(enemyLevel)

            val westSpawn = SurvivalMapSpec.spawnPoints.first { it.kind == SpawnKind.PLAYER_BASE }
            val eastSpawn = SurvivalMapSpec.spawnPoints.first { it.kind == SpawnKind.ENEMY_BASE }
            val mySpawn = if (isHost) westSpawn else eastSpawn
            val rivalSpawn = if (isHost) eastSpawn else westSpawn
            val myStartAngle = if (isHost) 0f else PI.toFloat()
            val rivalStartAngle = if (isHost) PI.toFloat() else 0f

            val shuffledDeck = GameCatalog.battleDeck.shuffled()
            val hand = shuffledDeck.take(4)
            val next = shuffledDeck.getOrNull(4)
            val initialWalls = SurvivalMapSpec.createInitialWalls()

            _battleState.value = BattleUiState(
                phase = BattlePhase.VS_INTRO,
                battleMode = mode,
                matchId = matchId,
                isHost = isHost,
                playerDisplayName = myName,
                enemyDisplayName = enemyName,
                introCountdownSec = 1.8f,
                timeRemainingSec = EconomyRules.MATCH_DURATION_SECONDS.toFloat(),
                playerTank = playerTank,
                playerLevel = myLevel,
                enemyTank = enemyTank,
                enemyLevel = enemyLevel,
                playerX = mySpawn.x,
                playerY = mySpawn.y,
                playerChassisAngleRad = myStartAngle,
                playerTurretAngleRad = myStartAngle,
                playerIsAiming = false,
                playerHp = playerMaxHp,
                playerMaxHp = playerMaxHp,
                enemyX = rivalSpawn.x,
                enemyY = rivalSpawn.y,
                enemyChassisAngleRad = rivalStartAngle,
                enemyTurretAngleRad = rivalStartAngle,
                enemyHp = enemyMaxHp,
                enemyMaxHp = enemyMaxHp,
                elixir = 5.0f,
                handCards = hand,
                nextCard = next,
                spawnPoints = SurvivalMapSpec.spawnPoints,
                walls = initialWalls,
                pickups = emptyList(),
                safeZone = SafeZoneBounds()
            )

            val destructibleWallMap = initialWalls
                .filter { it.destructible }
                .associate { it.id to it.hp }

            onlineRepo.createInitialPlayerState(
                matchId = matchId,
                userId = userId,
                participantUids = matchDoc.participantUids,
                x = mySpawn.x,
                y = mySpawn.y,
                chassisAngle = myStartAngle,
                turretAngle = myStartAngle,
                hp = playerMaxHp,
                maxHp = playerMaxHp,
                wallHps = destructibleWallMap
            )
            onlineRepo.markReadyAndStartIfReady(matchId, isHost = isHost)

            observeLivePvpMatch(matchId, isHost)
            observeLivePvpPlayers(matchId, isHost)
            launchPvpBattleLoop(matchId, isHost)
        }
    }

    private fun observeLivePvpMatch(matchId: String, isHost: Boolean) {
        matchRoomObserverJob?.cancel()
        matchRoomObserverJob = viewModelScope.launch {
            onlineRepo.observeMatch(matchId, userId)
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                }
                .collect { match ->
                    if (match == null) return@collect
                    activeMatchDoc = match
                    val status = PvpMatchStatus.fromRaw(match.status)
                    val curUi = _battleState.value

                    if (status == PvpMatchStatus.PLAYING && curUi.phase == BattlePhase.VS_INTRO) {
                        if (playingStartedLocalMs == 0L) {
                            playingStartedLocalMs = System.currentTimeMillis()
                        }
                        _battleState.update { it.copy(phase = BattlePhase.PLAYING, introCountdownSec = 0f) }
                    } else if (status == PvpMatchStatus.FINISHED && curUi.phase != BattlePhase.FINISHED) {
                        finalizePvpMatchFromDoc(match, isHost)
                    }
                }
        }
    }

    private fun observeLivePvpPlayers(matchId: String, isHost: Boolean) {
        playersObserverJob?.cancel()
        playersObserverJob = viewModelScope.launch {
            onlineRepo.observeMatchPlayers(matchId, userId)
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                }
                .collect { players ->
                    val rival = players.firstOrNull { it.userId != userId }
                    if (rival != null) {
                        remotePlayerDoc = rival
                        lastRemoteSeenMs = System.currentTimeMillis()

                        // Ingest any new shots emitted by the real opponent
                        val newShots = mutableListOf<BattleProjectile>()
                        rival.recentShots.forEach { rawMap ->
                            val shot = RemoteShotData.fromMap(rawMap) ?: return@forEach
                            if (seenRemoteShotIds.add(shot.shotId)) {
                                newShots += BattleProjectile(
                                    id = nextEntityId++,
                                    x = shot.x,
                                    y = shot.y,
                                    vx = shot.vx,
                                    vy = shot.vy,
                                    fromPlayer = false,
                                    damage = shot.damage,
                                    radiusTiles = shot.radius,
                                    isHeavy = shot.heavy,
                                    isLightning = shot.lightning
                                )
                            }
                        }

                        // Sync claimed pickup IDs from rival
                        rival.claimedPickupIds.forEach { claimedId ->
                            localClaimedPickupIds.add(claimedId)
                        }

                        _battleState.update { cur ->
                            val mergedWalls = cur.walls.map { w ->
                                val remoteHp = rival.wallHps[w.id]
                                if (w.destructible && remoteHp != null) {
                                    w.copy(hp = min(w.hp, remoteHp.coerceAtLeast(0)))
                                } else {
                                    w
                                }
                            }
                            // If we are guest, pickups are spawned by host and synced from host's arenaPickups
                            val updatedPickups = if (!isHost) {
                                rival.arenaPickups
                                    .mapNotNull { RemotePickupData.fromMap(it) }
                                    .filter { it.id !in localClaimedPickupIds }
                                    .map { rp ->
                                        val kind = SupplyKind.entries.firstOrNull { it.name == rp.kind } ?: SupplyKind.MEDKIT
                                        SupplyPickup(id = rp.id, spawnId = rp.spawnId, x = rp.x, y = rp.y, kind = kind)
                                    }
                            } else {
                                cur.pickups.filter { it.id !in localClaimedPickupIds }
                            }

                            cur.copy(
                                enemyHp = rival.hp.coerceIn(0, cur.enemyMaxHp),
                                enemyShieldHp = rival.shieldHp.coerceAtLeast(0),
                                enemyTurboActive = rival.turboActive,
                                enemyOverchargeActive = rival.overchargeActive,
                                enemyRecoilSec = if (newShots.isNotEmpty()) 0.16f else cur.enemyRecoilSec,
                                projectiles = if (newShots.isNotEmpty()) cur.projectiles + newShots else cur.projectiles,
                                walls = mergedWalls,
                                pickups = updatedPickups,
                                opponentConnectionWarning = false
                            )
                        }
                    }
                }
        }
    }

    private suspend fun finalizePvpMatchFromDoc(match: PvpMatchDoc, isHost: Boolean) {
        val matchId = match.id.ifBlank { _battleState.value.matchId ?: return }
        if (!rewardedMatchIds.add(matchId)) return
        battleLoopJob?.cancel()

        val cur = _battleState.value
        val outcome = when (match.winnerUid) {
            userId -> MatchOutcome.VICTORY
            "DRAW" -> MatchOutcome.DRAW
            else -> MatchOutcome.DEFEAT
        }

        val reason = when {
            match.forfeitByUid == userId -> "Abandonaste la partida"
            !match.forfeitByUid.isNullOrBlank() && match.winnerUid == userId -> "Victoria por desconexión o retirada del rival"
            else -> null
        }

        val durationUsed = (EconomyRules.MATCH_DURATION_SECONDS - cur.timeRemainingSec.roundToInt())
            .coerceIn(1, EconomyRules.MATCH_DURATION_SECONDS)

        val summary = applyMatchRewards(
            outcome = outcome,
            durationUsedSec = durationUsed,
            damageDealt = cur.matchDamageDealt,
            shotsFired = cur.matchShotsFired,
            cardsPlayed = cur.matchCardsPlayed,
            reasonLabel = reason
        )

        _battleState.update {
            it.copy(
                phase = BattlePhase.FINISHED,
                playerIsAiming = false,
                projectiles = emptyList(),
                rewardSummary = summary
            )
        }
    }

    fun skipVsIntro() {
        val matchId = _battleState.value.matchId ?: return
        viewModelScope.launch {
            onlineRepo.markReadyAndStartIfReady(
                matchId = matchId,
                isHost = _battleState.value.isHost,
                forceStart = true
            )
        }
    }

    fun exitBattleToHome() {
        val state = _battleState.value
        val matchId = state.matchId
        val match = activeMatchDoc
        val shouldForfeit = matchId != null && match != null &&
            (state.phase == BattlePhase.VS_INTRO || state.phase == BattlePhase.PLAYING)

        cancelAllBattleJobs()
        resetJoystickInputs()

        viewModelScope.launch {
            withContext(NonCancellable) {
                onlineRepo.cancelQueue(userId)
                if (shouldForfeit && matchId != null && match != null) {
                    val opponentUid = if (state.isHost) match.guestUid else match.hostUid
                    onlineRepo.finishMatch(matchId, winnerUid = opponentUid, forfeitByUid = userId)
                }
            }
        }

        activeMatchDoc = null
        remotePlayerDoc = null
        _battleState.value = BattleUiState(phase = BattlePhase.IDLE, playerDisplayName = displayName)
        _currentTab.value = AppTab.HOME
    }

    private fun cancelAllBattleJobs() {
        matchmakingJob?.cancel()
        matchmakingJob = null
        matchRoomObserverJob?.cancel()
        matchRoomObserverJob = null
        playersObserverJob?.cancel()
        playersObserverJob = null
        battleLoopJob?.cancel()
        battleLoopJob = null
    }

    private fun resetJoystickInputs() {
        moveVecX = 0f
        moveVecY = 0f
        aimVecX = 0f
        aimVecY = 0f
        aimStickActive = false
        aimStickFiring = false
        pendingReleaseShotAngle = null
    }

    fun setMoveVector(dx: Float, dy: Float) {
        val mag = hypot(dx, dy)
        if (mag > 1f) {
            moveVecX = dx / mag
            moveVecY = dy / mag
        } else {
            moveVecX = dx
            moveVecY = dy
        }
    }

    fun setAimInput(dx: Float, dy: Float, isPressed: Boolean, released: Boolean) {
        val mag = hypot(dx, dy)
        if (isPressed) {
            aimStickActive = true
            if (mag > 0.14f) {
                aimVecX = dx / mag
                aimVecY = dy / mag
            }
            aimStickFiring = mag >= 0.42f
        } else if (released) {
            val state = _battleState.value
            val shotAngle = if (mag >= 0.20f) {
                atan2(dy, dx)
            } else {
                atan2(state.enemyY - state.playerY, state.enemyX - state.playerX)
            }
            pendingReleaseShotAngle = shotAngle
            aimStickActive = false
            aimStickFiring = false
            aimVecX = 0f
            aimVecY = 0f
        } else {
            aimStickActive = false
            aimStickFiring = false
            aimVecX = 0f
            aimVecY = 0f
        }
    }

    private fun recordOutgoingShot(proj: BattleProjectile) {
        outgoingShotsBuffer += RemoteShotData(
            shotId = nextShotSeq++,
            x = proj.x,
            y = proj.y,
            vx = proj.vx,
            vy = proj.vy,
            damage = proj.damage,
            radius = proj.radiusTiles,
            heavy = proj.isHeavy,
            lightning = proj.isLightning
        )
        while (outgoingShotsBuffer.size > 8) {
            outgoingShotsBuffer.removeAt(0)
        }
        forceImmediateSync = true
    }

    fun playBattleCard(cardIndex: Int) {
        val state = _battleState.value
        if (state.phase != BattlePhase.PLAYING) return
        val card = state.handCards.getOrNull(cardIndex) ?: return
        if (state.elixir < card.elixirCost) return
        val tank = state.playerTank ?: return
        val overchargeMult = if (state.playerOverchargeSec > 0f) 1.35f else 1f
        val baseDmg = (tank.damageAtLevel(state.playerLevel) * overchargeMult).roundToInt()
        val angle = state.playerTurretAngleRad
        val speed = EconomyRules.BASE_BOMB_SPEED_TILES_PER_SEC

        val newProjectiles = mutableListOf<BattleProjectile>()
        var newShield = state.playerShieldHp
        var newTurbo = state.playerTurboSec
        var newHp = state.playerHp
        var addedShots = 0
        var newFloating: FloatingBattleText? = null

        when (card.effect) {
            BattleCardEffect.HEAVY_BOMB -> {
                val p = BattleProjectile(
                    id = nextEntityId++,
                    x = state.playerX + cos(angle) * 0.85f,
                    y = state.playerY + sin(angle) * 0.85f,
                    vx = cos(angle) * speed * 0.92f,
                    vy = sin(angle) * speed * 0.92f,
                    fromPlayer = true,
                    damage = (baseDmg * 1.8f).roundToInt(),
                    radiusTiles = 0.62f,
                    isHeavy = true
                )
                newProjectiles += p
                recordOutgoingShot(p)
                addedShots = 1
            }
            BattleCardEffect.TRIPLE_BURST -> {
                val offsets = listOf(-0.22f, 0f, 0.22f)
                offsets.forEach { dAngle ->
                    val a = angle + dAngle
                    val p = BattleProjectile(
                        id = nextEntityId++,
                        x = state.playerX + cos(a) * 0.85f,
                        y = state.playerY + sin(a) * 0.85f,
                        vx = cos(a) * speed,
                        vy = sin(a) * speed,
                        fromPlayer = true,
                        damage = (baseDmg * 0.65f).roundToInt()
                    )
                    newProjectiles += p
                    recordOutgoingShot(p)
                }
                addedShots = 3
            }
            BattleCardEffect.ARMOR_SHIELD -> {
                newShield = 900
                forceImmediateSync = true
                newFloating = FloatingBattleText(
                    id = nextEntityId++,
                    x = state.playerX,
                    y = state.playerY - 1.1f,
                    text = "ESCUDO +900",
                    colorHex = 0xFF38BDF8,
                    remainingSec = 1.0f
                )
            }
            BattleCardEffect.TURBO_TRACKS -> {
                newTurbo = 4.5f
                forceImmediateSync = true
                newFloating = FloatingBattleText(
                    id = nextEntityId++,
                    x = state.playerX,
                    y = state.playerY - 1.1f,
                    text = "TURBO ACTIVO",
                    colorHex = 0xFFE879F9,
                    remainingSec = 1.0f
                )
            }
            BattleCardEffect.CENTELLA_BOLT -> {
                val p = BattleProjectile(
                    id = nextEntityId++,
                    x = state.playerX + cos(angle) * 0.85f,
                    y = state.playerY + sin(angle) * 0.85f,
                    vx = cos(angle) * 14.0f,
                    vy = sin(angle) * 14.0f,
                    fromPlayer = true,
                    damage = (baseDmg * 2.2f).roundToInt(),
                    radiusTiles = 0.50f,
                    isLightning = true
                )
                newProjectiles += p
                recordOutgoingShot(p)
                addedShots = 1
            }
            BattleCardEffect.REPAIR_KIT -> {
                val heal = (state.playerMaxHp * 0.22f).roundToInt()
                newHp = min(state.playerMaxHp, state.playerHp + heal)
                forceImmediateSync = true
                newFloating = FloatingBattleText(
                    id = nextEntityId++,
                    x = state.playerX,
                    y = state.playerY - 1.1f,
                    text = "+$heal HP",
                    colorHex = 0xFF22C55E,
                    remainingSec = 1.1f
                )
            }
        }

        val currentHand = state.handCards.toMutableList()
        val replacement = state.nextCard ?: GameCatalog.battleDeck.first()
        currentHand[cardIndex] = replacement
        val usedIds = currentHand.map { it.id }.toSet()
        val nextPool = GameCatalog.battleDeck.filter { it.id !in usedIds }
        val newNext = if (nextPool.isNotEmpty()) nextPool[Random.nextInt(nextPool.size)] else GameCatalog.battleDeck.first()

        _battleState.update { cur ->
            cur.copy(
                elixir = (cur.elixir - card.elixirCost).coerceAtLeast(0f),
                handCards = currentHand,
                nextCard = newNext,
                projectiles = cur.projectiles + newProjectiles,
                playerShieldHp = newShield,
                playerTurboSec = newTurbo,
                playerHp = newHp,
                playerRecoilSec = if (addedShots > 0) 0.18f else cur.playerRecoilSec,
                matchShotsFired = cur.matchShotsFired + addedShots,
                matchCardsPlayed = cur.matchCardsPlayed + 1,
                floatingTexts = if (newFloating != null) cur.floatingTexts + newFloating else cur.floatingTexts
            )
        }
    }

    /**
     * Smooth Circle-vs-AABB collision with corner push-out sliding so tanks NEVER get wedged on wall corners.
     */
    private fun resolveTankWallCollision(
        cx: Float,
        cy: Float,
        dx: Float,
        dy: Float,
        radius: Float,
        walls: List<MapWall>
    ): Pair<Float, Float> {
        var nx = cx + dx
        var ny = cy + dy
        val maxW = EconomyRules.MAP_WIDTH_TILES.toFloat()
        val maxH = EconomyRules.MAP_HEIGHT_TILES.toFloat()

        repeat(2) {
            for (w in walls) {
                if (w.hp <= 0) continue
                val closestX = nx.coerceIn(w.left, w.right)
                val closestY = ny.coerceIn(w.top, w.bottom)
                val distX = nx - closestX
                val distY = ny - closestY
                val distSq = distX * distX + distY * distY
                if (distSq < radius * radius) {
                    val dist = kotlin.math.sqrt(distSq)
                    if (dist > 0.0001f) {
                        val push = radius - dist
                        nx += (distX / dist) * push
                        ny += (distY / dist) * push
                    } else {
                        val toLeft = abs(nx - w.left)
                        val toRight = abs(w.right - nx)
                        val toTop = abs(ny - w.top)
                        val toBottom = abs(w.bottom - ny)
                        val m = minOf(toLeft, toRight, toTop, toBottom)
                        when (m) {
                            toLeft -> nx = w.left - radius
                            toRight -> nx = w.right + radius
                            toTop -> ny = w.top - radius
                            else -> ny = w.bottom + radius
                        }
                    }
                }
            }
            nx = nx.coerceIn(radius + 0.18f, maxW - radius - 0.18f)
            ny = ny.coerceIn(radius + 0.18f, maxH - radius - 0.18f)
        }
        return nx to ny
    }

    private fun launchPvpBattleLoop(matchId: String, isHost: Boolean) {
        battleLoopJob?.cancel()
        battleLoopJob = viewModelScope.launch {
            var supplySpawnTimer = 5.5f
            var stormTickTimer = 0.85f
            var localStunSec = 0f
            var lastSyncSentMs = 0L
            var introForceSent = false
            var finishSubmitted = false
            val tankRadius = 0.55f
            val dt = 0.033f

            while (true) {
                delay(33L)
                val cur = _battleState.value
                if (cur.phase == BattlePhase.IDLE || cur.phase == BattlePhase.FINISHED) break

                val nowMs = System.currentTimeMillis()
                val match = activeMatchDoc

                if (cur.phase == BattlePhase.VS_INTRO) {
                    val rem = cur.introCountdownSec - dt
                    if (rem <= 0f && !introForceSent) {
                        introForceSent = true
                        launch {
                            onlineRepo.markReadyAndStartIfReady(matchId, isHost = isHost, forceStart = true)
                        }
                    }
                    _battleState.update { it.copy(introCountdownSec = rem.coerceAtLeast(0f)) }
                    continue
                }

                val playerTank = cur.playerTank ?: break
                val startedAtMs = match?.startedAt?.toDate()?.time
                    ?: playingStartedLocalMs.takeIf { it > 0L }
                    ?: nowMs
                val elapsedMatchSec = ((nowMs - startedAtMs).coerceAtLeast(0L) / 1000f)
                val nextTime = (EconomyRules.MATCH_DURATION_SECONDS - elapsedMatchSec)
                    .coerceIn(0f, EconomyRules.MATCH_DURATION_SECONDS.toFloat())

                val doubleElixir = nextTime <= 30f
                val modeElixirMult = cur.battleMode.elixirMultiplier
                val elixirRate = (if (doubleElixir) 1.9f else 1.0f) * modeElixirMult
                var nextElixir = (cur.elixir + elixirRate * dt).coerceAtMost(cur.maxElixir)

                // Shrinking Survival Fire Zone (synchronized from match clock)
                val stormStart = cur.battleMode.stormStartRemainingSec
                val stormActive = nextTime <= stormStart
                val shrinkFraction = if (stormActive) {
                    ((stormStart - nextTime) / (stormStart - 12f).coerceAtLeast(20f)).coerceIn(0f, 1f)
                } else 0f
                val safeZone = SafeZoneBounds(
                    minX = 0f + shrinkFraction * 8.5f,
                    minY = 0f + shrinkFraction * 4.0f,
                    maxX = EconomyRules.MAP_WIDTH_TILES - shrinkFraction * 8.5f,
                    maxY = EconomyRules.MAP_HEIGHT_TILES - shrinkFraction * 4.0f
                )

                val walls = cur.walls.map { it.copy() }.toMutableList()
                val pickups = cur.pickups.toMutableList()
                val newFloating = cur.floatingTexts
                    .map { it.copy(y = it.y - 0.9f * dt, remainingSec = it.remainingSec - dt) }
                    .filter { it.remainingSec > 0f }
                    .toMutableList()

                localStunSec = (localStunSec - dt).coerceAtLeast(0f)

                // 1. Local Player Blue-Joystick movement (blocked briefly if hit by Centella stun)
                val turboMult = if (cur.playerTurboSec > 0f) 1.75f else 1f
                val playerSpeed = if (localStunSec > 0f) 0f else playerTank.speedTilesPerSec * turboMult
                val (nextPlayerX, nextPlayerY) = resolveTankWallCollision(
                    cx = cur.playerX,
                    cy = cur.playerY,
                    dx = moveVecX * playerSpeed * dt,
                    dy = moveVecY * playerSpeed * dt,
                    radius = tankRadius,
                    walls = walls
                )

                val nextPlayerChassisAngle = if (hypot(moveVecX, moveVecY) > 0.14f && localStunSec <= 0f) {
                    atan2(moveVecY, moveVecX)
                } else {
                    cur.playerChassisAngleRad
                }

                // 2. Smoothly interpolate real opponent pose from latest Firestore MatchPlayerStateDoc
                val remote = remotePlayerDoc
                var nextEnemyX = cur.enemyX
                var nextEnemyY = cur.enemyY
                var nextEnemyChassisAngle = cur.enemyChassisAngleRad
                var nextEnemyTurretAngle = cur.enemyTurretAngleRad
                if (remote != null) {
                    val lerpFactor = 0.34f
                    nextEnemyX = cur.enemyX + (remote.x.toFloat() - cur.enemyX) * lerpFactor
                    nextEnemyY = cur.enemyY + (remote.y.toFloat() - cur.enemyY) * lerpFactor
                    nextEnemyChassisAngle = remote.chassisAngle.toFloat()
                    nextEnemyTurretAngle = remote.turretAngle.toFloat()
                }

                // Tank-vs-Tank separation
                var finalPlayerX = nextPlayerX
                var finalPlayerY = nextPlayerY
                val sepDx = finalPlayerX - nextEnemyX
                val sepDy = finalPlayerY - nextEnemyY
                val sepDist = hypot(sepDx, sepDy)
                val minTankSep = tankRadius * 2.05f
                if (sepDist in 0.001f..minTankSep) {
                    val push = (minTankSep - sepDist) * 0.65f
                    val ux = sepDx / sepDist
                    val uy = sepDy / sepDist
                    val pRes = resolveTankWallCollision(finalPlayerX, finalPlayerY, ux * push, uy * push, tankRadius, walls)
                    finalPlayerX = pRes.first
                    finalPlayerY = pRes.second
                }

                // Player Turret Angle: manual Red Joystick if active, else smoothly faces real opponent
                val playerTurretAngle = if (aimStickActive && hypot(aimVecX, aimVecY) > 0.14f) {
                    atan2(aimVecY, aimVecX)
                } else {
                    atan2(nextEnemyY - finalPlayerY, nextEnemyX - finalPlayerX)
                }

                // 3. Host spawns supply crates on SUPPLY_PADs (synced to Guest via arenaPickups)
                if (isHost) {
                    supplySpawnTimer -= dt
                    if (supplySpawnTimer <= 0f) {
                        supplySpawnTimer = 9.5f
                        val pads = cur.spawnPoints.filter { it.kind == SpawnKind.SUPPLY_PAD }
                        val freePads = pads.filter { pad -> pickups.none { it.spawnId == pad.id } }
                        if (freePads.isNotEmpty() && pickups.size < 3) {
                            val chosen = freePads[Random.nextInt(freePads.size)]
                            val kind = SupplyKind.entries[Random.nextInt(SupplyKind.entries.size)]
                            pickups += SupplyPickup(
                                id = nextEntityId++,
                                spawnId = chosen.id,
                                x = chosen.x,
                                y = chosen.y,
                                kind = kind
                            )
                            forceImmediateSync = true
                        }
                    }
                }

                // Cooldowns & timers
                var nextFireCd = (cur.fireCooldownSec - dt).coerceAtLeast(0f)
                val nextTurbo = (cur.playerTurboSec - dt).coerceAtLeast(0f)
                var nextOvercharge = (cur.playerOverchargeSec - dt).coerceAtLeast(0f)
                val nextPlayerRecoil = (cur.playerRecoilSec - dt).coerceAtLeast(0f)
                val nextEnemyRecoil = (cur.enemyRecoilSec - dt).coerceAtLeast(0f)
                val nextEnemyStun = (cur.enemyStunSec - dt).coerceAtLeast(0f)

                var playerHp = cur.playerHp
                var playerShield = cur.playerShieldHp

                // Pickup collection by local player
                val remainingPickups = mutableListOf<SupplyPickup>()
                for (p in pickups) {
                    if (p.id in localClaimedPickupIds) continue
                    val dPlayer = hypot(finalPlayerX - p.x, finalPlayerY - p.y)
                    if (dPlayer <= 1.20f) {
                        localClaimedPickupIds.add(p.id)
                        forceImmediateSync = true
                        when (p.kind) {
                            SupplyKind.MEDKIT -> playerHp = min(cur.playerMaxHp, playerHp + 450)
                            SupplyKind.ELIXIR -> nextElixir = (nextElixir + 2.5f).coerceAtMost(cur.maxElixir)
                            SupplyKind.OVERCHARGE -> nextOvercharge = 5.5f
                        }
                        newFloating += FloatingBattleText(
                            id = nextEntityId++,
                            x = finalPlayerX,
                            y = finalPlayerY - 1.0f,
                            text = p.kind.label,
                            colorHex = 0xFF22C55E,
                            remainingSec = 1.0f
                        )
                    } else {
                        remainingPickups += p
                    }
                }

                // Survival Fire Zone Burn Damage (each player simulates burn damage authoritatively on their own tank)
                if (stormActive) {
                    stormTickTimer -= dt
                    if (stormTickTimer <= 0f) {
                        stormTickTimer = 0.85f
                        if (finalPlayerX < safeZone.minX || finalPlayerX > safeZone.maxX ||
                            finalPlayerY < safeZone.minY || finalPlayerY > safeZone.maxY
                        ) {
                            playerHp = (playerHp - 110).coerceAtLeast(0)
                            forceImmediateSync = true
                            newFloating += FloatingBattleText(
                                id = nextEntityId++,
                                x = finalPlayerX,
                                y = finalPlayerY - 1.1f,
                                text = "-110 FUEGO",
                                colorHex = 0xFFFF6B00,
                                remainingSec = 0.7f
                            )
                        }
                    }
                }

                val spawnedProjectiles = mutableListOf<BattleProjectile>()
                var addedPlayerShots = 0

                // Red Joystick Player Firing
                val releaseAngle = pendingReleaseShotAngle
                pendingReleaseShotAngle = null
                val effectivePlayerShotAngle = when {
                    localStunSec > 0f -> null
                    releaseAngle != null && nextFireCd <= 0f -> releaseAngle
                    aimStickFiring && nextFireCd <= 0f -> playerTurretAngle
                    else -> null
                }
                var updatedPlayerRecoil = nextPlayerRecoil
                if (effectivePlayerShotAngle != null) {
                    nextFireCd = if (nextTurbo > 0f) 0.34f else 0.56f
                    updatedPlayerRecoil = 0.16f
                    val overMult = if (nextOvercharge > 0f) 1.35f else 1f
                    val dmg = (playerTank.damageAtLevel(cur.playerLevel) * overMult).roundToInt()
                    val proj = BattleProjectile(
                        id = nextEntityId++,
                        x = finalPlayerX + cos(effectivePlayerShotAngle) * 0.85f,
                        y = finalPlayerY + sin(effectivePlayerShotAngle) * 0.85f,
                        vx = cos(effectivePlayerShotAngle) * EconomyRules.BASE_BOMB_SPEED_TILES_PER_SEC,
                        vy = sin(effectivePlayerShotAngle) * EconomyRules.BASE_BOMB_SPEED_TILES_PER_SEC,
                        fromPlayer = true,
                        damage = dmg
                    )
                    spawnedProjectiles += proj
                    recordOutgoingShot(proj)
                    addedPlayerShots++
                }

                // Sub-stepped Projectile Physics & Hitboxes
                val survivingProjectiles = mutableListOf<BattleProjectile>()
                val newExplosions = cur.explosions
                    .map { it.copy(remainingSec = it.remainingSec - dt) }
                    .filter { it.remainingSec > 0f }
                    .toMutableList()

                var damageDealtDelta = 0
                var updatedEnemyStun = nextEnemyStun
                val allProjectiles = cur.projectiles + spawnedProjectiles

                for (proj in allProjectiles) {
                    var px = proj.x
                    var py = proj.y
                    var consumed = false
                    val subSteps = 2
                    val subDt = dt / subSteps

                    for (step in 0 until subSteps) {
                        px += proj.vx * subDt
                        py += proj.vy * subDt

                        if (px < 0f || px > EconomyRules.MAP_WIDTH_TILES || py < 0f || py > EconomyRules.MAP_HEIGHT_TILES) {
                            consumed = true
                            break
                        }

                        // Wall collision
                        for (i in walls.indices) {
                            val w = walls[i]
                            if (w.hp <= 0) continue
                            val cx = px.coerceIn(w.left, w.right)
                            val cy = py.coerceIn(w.top, w.bottom)
                            val wdx = px - cx
                            val wdy = py - cy
                            val wallHitR = proj.radiusTiles * 0.65f
                            if (wdx * wdx + wdy * wdy <= wallHitR * wallHitR) {
                                if (w.destructible) {
                                    walls[i] = w.copy(hp = (w.hp - proj.damage).coerceAtLeast(0))
                                    forceImmediateSync = true
                                }
                                consumed = true
                                newExplosions += BattleExplosion(
                                    id = nextEntityId++,
                                    x = px,
                                    y = py,
                                    radiusTiles = if (w.destructible) 0.90f else 0.70f,
                                    colorHex = if (w.destructible) 0xFFF59E0B else 0xFF94A3B8,
                                    remainingSec = 0.24f,
                                    totalSec = 0.24f
                                )
                                break
                            }
                        }
                        if (consumed) break

                        // Local player shot hitting Enemy Tank -> immediate visual/damage feedback
                        if (proj.fromPlayer && hypot(px - nextEnemyX, py - nextEnemyY) <= tankRadius + proj.radiusTiles * 0.85f) {
                            damageDealtDelta += proj.damage
                            if (proj.isLightning) {
                                updatedEnemyStun = 0.9f
                            }
                            newExplosions += BattleExplosion(
                                id = nextEntityId++,
                                x = px,
                                y = nextEnemyY,
                                radiusTiles = if (proj.isHeavy || proj.isLightning) 1.45f else 1.0f,
                                colorHex = if (proj.isLightning) 0xFF00D4FF else 0xFFFF6B00,
                                remainingSec = 0.34f,
                                totalSec = 0.34f
                            )
                            newFloating += FloatingBattleText(
                                id = nextEntityId++,
                                x = nextEnemyX,
                                y = nextEnemyY - 0.9f,
                                text = if (proj.isLightning) "-${proj.damage} CENTELLA" else "-${proj.damage}",
                                colorHex = if (proj.isLightning) 0xFF00D4FF else 0xFFFFC800,
                                remainingSec = 0.75f
                            )
                            consumed = true
                            break
                        }

                        // Remote opponent shot hitting Local Player Tank -> authoritative HP/shield reduction!
                        if (!proj.fromPlayer && hypot(px - finalPlayerX, py - finalPlayerY) <= tankRadius + proj.radiusTiles * 0.85f) {
                            var remainingDmg = proj.damage
                            if (playerShield > 0) {
                                val absorbed = min(playerShield, remainingDmg)
                                playerShield -= absorbed
                                remainingDmg -= absorbed
                            }
                            playerHp = (playerHp - remainingDmg).coerceAtLeast(0)
                            if (proj.isLightning) {
                                localStunSec = 0.9f
                            }
                            forceImmediateSync = true
                            newExplosions += BattleExplosion(
                                id = nextEntityId++,
                                x = px,
                                y = finalPlayerY,
                                radiusTiles = if (proj.isHeavy || proj.isLightning) 1.35f else 0.95f,
                                colorHex = 0xFFEF4444,
                                remainingSec = 0.32f,
                                totalSec = 0.32f
                            )
                            newFloating += FloatingBattleText(
                                id = nextEntityId++,
                                x = finalPlayerX,
                                y = finalPlayerY - 0.9f,
                                text = if (remainingDmg == 0) "BLOQUEADO" else "-$remainingDmg",
                                colorHex = if (remainingDmg == 0) 0xFF38BDF8 else 0xFFEF4444,
                                remainingSec = 0.75f
                            )
                            consumed = true
                            break
                        }
                    }

                    if (!consumed) {
                        survivingProjectiles += proj.copy(x = px, y = py)
                    }
                }

                // Opponent telemetry & disconnect timeout check
                val remoteSilentMs = nowMs - lastRemoteSeenMs
                val enemyHp = remote?.hp?.coerceIn(0, cur.enemyMaxHp) ?: cur.enemyHp
                val showLagWarning = remoteSilentMs > 5_000L
                val opponentDisconnected = remoteSilentMs > 18_000L

                val totalDmg = cur.matchDamageDealt + damageDealtDelta
                val totalShots = cur.matchShotsFired + addedPlayerShots

                // Throttled Firestore telemetry sync (~75ms cadence or immediate on shot/hit/pickup)
                val shouldPushSync = forceImmediateSync || (nowMs - lastSyncSentMs >= 75L)
                if (shouldPushSync) {
                    forceImmediateSync = false
                    lastSyncSentMs = nowMs
                    val wallMap = walls.filter { it.destructible }.associate { it.id to it.hp }
                    val pickupDtos = if (isHost) {
                        remainingPickups.take(3).map {
                            RemotePickupData(it.id, it.spawnId, it.x, it.y, it.kind.name)
                        }
                    } else {
                        emptyList()
                    }
                    val updatePayload = MatchPlayerStateDoc.toUpdateMap(
                        x = finalPlayerX,
                        y = finalPlayerY,
                        chassisAngle = nextPlayerChassisAngle,
                        turretAngle = effectivePlayerShotAngle ?: playerTurretAngle,
                        hp = playerHp,
                        shieldHp = playerShield,
                        turboActive = nextTurbo > 0f,
                        overchargeActive = nextOvercharge > 0f,
                        recentShots = outgoingShotsBuffer.toList(),
                        claimedPickupIds = localClaimedPickupIds.toList(),
                        wallHps = wallMap,
                        arenaPickups = pickupDtos,
                        reportedDamageDealt = totalDmg
                    )
                    launch {
                        onlineRepo.publishPlayerState(matchId, userId, updatePayload)
                    }
                }

                // End-of-match determination (HP <= 0, Timer == 0:00, or Opponent Disconnect)
                val enemyDied = remote != null && enemyHp <= 0
                val playerDied = playerHp <= 0
                val timeUp = nextTime <= 0f
                val matchEnded = !finishSubmitted && (playerDied || enemyDied || timeUp || opponentDisconnected)

                if (matchEnded && match != null) {
                    finishSubmitted = true
                    val enemyUid = if (isHost) match.guestUid else match.hostUid
                    val playerRatio = playerHp.toFloat() / cur.playerMaxHp.coerceAtLeast(1)
                    val enemyRatio = enemyHp.toFloat() / cur.enemyMaxHp.coerceAtLeast(1)

                    val (winnerUid, forfeitUid) = when {
                        opponentDisconnected -> userId to enemyUid
                        enemyDied && !playerDied -> userId to null
                        playerDied && !enemyDied -> enemyUid to null
                        playerRatio > enemyRatio -> userId to null
                        playerRatio < enemyRatio -> enemyUid to null
                        else -> "DRAW" to null
                    }

                    launch {
                        onlineRepo.finishMatch(
                            matchId = matchId,
                            winnerUid = winnerUid,
                            forfeitByUid = forfeitUid
                        )
                    }
                }

                _battleState.update {
                    it.copy(
                        timeRemainingSec = nextTime,
                        elixir = nextElixir,
                        isDoubleElixir = doubleElixir,
                        playerX = finalPlayerX,
                        playerY = finalPlayerY,
                        playerChassisAngleRad = nextPlayerChassisAngle,
                        playerTurretAngleRad = playerTurretAngle,
                        playerIsAiming = aimStickActive,
                        playerHp = playerHp,
                        playerShieldHp = playerShield,
                        playerTurboSec = nextTurbo,
                        playerOverchargeSec = nextOvercharge,
                        playerRecoilSec = updatedPlayerRecoil,
                        enemyX = nextEnemyX,
                        enemyY = nextEnemyY,
                        enemyChassisAngleRad = nextEnemyChassisAngle,
                        enemyTurretAngleRad = nextEnemyTurretAngle,
                        enemyHp = enemyHp,
                        enemyStunSec = updatedEnemyStun,
                        enemyRecoilSec = nextEnemyRecoil,
                        opponentConnectionWarning = showLagWarning,
                        fireCooldownSec = nextFireCd,
                        walls = walls,
                        pickups = remainingPickups,
                        safeZone = safeZone,
                        stormActive = stormActive,
                        projectiles = survivingProjectiles,
                        explosions = newExplosions,
                        floatingTexts = newFloating,
                        matchDamageDealt = totalDmg,
                        matchShotsFired = totalShots
                    )
                }
            }
        }
    }

    private suspend fun applyMatchRewards(
        outcome: MatchOutcome,
        durationUsedSec: Int,
        damageDealt: Int,
        shotsFired: Int,
        cardsPlayed: Int,
        reasonLabel: String? = null
    ): MatchRewardSummary {
        var bombasEarned = 0
        var gemasEarned = 0
        var fcEarned = 0
        var gemsCapped = false
        var fcCapped = false

        updateProfileEverywhere { cur ->
            val passMult = if (cur.hasBattlePass) 1.2f else 1.0f
            val baseBombas = if (outcome == MatchOutcome.VICTORY) EconomyRules.WIN_REWARD_BOMBAS else EconomyRules.LOSS_REWARD_BOMBAS
            val baseGems = if (outcome == MatchOutcome.VICTORY) EconomyRules.WIN_REWARD_GEMS else EconomyRules.LOSS_REWARD_GEMS
            val baseFc = if (outcome == MatchOutcome.VICTORY) EconomyRules.WIN_REWARD_FC else EconomyRules.LOSS_REWARD_FC

            bombasEarned = (baseBombas * passMult).roundToInt()
            val desiredGems = (baseGems * passMult).roundToInt()
            val desiredFc = baseFc

            val roomGems = (EconomyRules.MAX_DAILY_MATCH_GEMS - cur.dailyMatchGemsEarned).coerceAtLeast(0)
            gemasEarned = min(desiredGems, roomGems)
            gemsCapped = gemasEarned < desiredGems

            val roomFc = (EconomyRules.MAX_DAILY_FC - cur.dailyFcEarned).coerceAtLeast(0)
            fcEarned = min(desiredFc, roomFc)
            fcCapped = fcEarned < desiredFc

            cur.copy(
                bombas = cur.bombas + bombasEarned,
                gemas = cur.gemas + gemasEarned,
                fichasCentella = cur.fichasCentella + fcEarned,
                dailyMatchGemsEarned = cur.dailyMatchGemsEarned + gemasEarned,
                dailyFcEarned = cur.dailyFcEarned + fcEarned,
                totalWins = cur.totalWins + if (outcome == MatchOutcome.VICTORY) 1 else 0,
                totalMatches = cur.totalMatches + 1,
                totalShotsFired = cur.totalShotsFired + shotsFired,
                totalDamageDealt = cur.totalDamageDealt + damageDealt,
                totalCardsPlayed = cur.totalCardsPlayed + cardsPlayed
            )
        }

        return MatchRewardSummary(
            outcome = outcome,
            durationUsedSec = durationUsedSec,
            damageDealt = damageDealt,
            shotsFired = shotsFired,
            bombasEarned = bombasEarned,
            gemasEarned = gemasEarned,
            fcEarned = fcEarned,
            gemsCappedByDailyLimit = gemsCapped,
            fcCappedByDailyLimit = fcCapped,
            reasonLabel = reasonLabel
        )
    }

    override fun onCleared() {
        super.onCleared()
        cancelAllBattleJobs()
        profileObserverJob?.cancel()
    }
}
