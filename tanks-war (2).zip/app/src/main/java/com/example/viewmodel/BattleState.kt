package com.example.viewmodel

import com.example.model.BattleCard
import com.example.model.BattleMode
import com.example.model.EconomyRules
import com.example.model.TankDefinition

enum class BattlePhase {
    IDLE,
    MATCHMAKING,
    VS_INTRO,
    PLAYING,
    FINISHED
}

enum class MatchOutcome {
    VICTORY,
    DEFEAT,
    DRAW
}

enum class SpawnKind {
    PLAYER_BASE,
    ENEMY_BASE,
    SUPPLY_PAD
}

data class MapSpawnPoint(
    val id: String,
    val x: Float,
    val y: Float,
    val kind: SpawnKind
)

data class MapWall(
    val id: String,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val destructible: Boolean,
    val hp: Int,
    val maxHp: Int
)

enum class SupplyKind(val label: String) {
    MEDKIT("+450 HP"),
    ELIXIR("+2.5 ELIXIR"),
    OVERCHARGE("DAÑO x1.35")
}

data class SupplyPickup(
    val id: Long,
    val spawnId: String,
    val x: Float,
    val y: Float,
    val kind: SupplyKind
)

data class SafeZoneBounds(
    val minX: Float = 0f,
    val minY: Float = 0f,
    val maxX: Float = EconomyRules.MAP_WIDTH_TILES.toFloat(),
    val maxY: Float = EconomyRules.MAP_HEIGHT_TILES.toFloat()
)

data class BattleProjectile(
    val id: Long,
    val x: Float,
    val y: Float,
    val vx: Float,
    val vy: Float,
    val fromPlayer: Boolean,
    val damage: Int,
    val radiusTiles: Float = 0.40f,
    val isHeavy: Boolean = false,
    val isLightning: Boolean = false
)

data class BattleExplosion(
    val id: Long,
    val x: Float,
    val y: Float,
    val radiusTiles: Float,
    val colorHex: Long,
    val remainingSec: Float,
    val totalSec: Float
)

data class FloatingBattleText(
    val id: Long,
    val x: Float,
    val y: Float,
    val text: String,
    val colorHex: Long,
    val remainingSec: Float
)

data class MatchRewardSummary(
    val outcome: MatchOutcome,
    val durationUsedSec: Int,
    val damageDealt: Int,
    val shotsFired: Int,
    val bombasEarned: Int,
    val gemasEarned: Int,
    val fcEarned: Int,
    val gemsCappedByDailyLimit: Boolean,
    val fcCappedByDailyLimit: Boolean,
    val reasonLabel: String? = null
)

object SurvivalMapSpec {
    val spawnPoints: List<MapSpawnPoint> = listOf(
        MapSpawnPoint(id = "spawn_player", x = 2.4f, y = 7.5f, kind = SpawnKind.PLAYER_BASE),
        MapSpawnPoint(id = "spawn_enemy", x = 27.6f, y = 7.5f, kind = SpawnKind.ENEMY_BASE),
        MapSpawnPoint(id = "supply_north", x = 15.0f, y = 2.2f, kind = SpawnKind.SUPPLY_PAD),
        MapSpawnPoint(id = "supply_center", x = 15.0f, y = 7.5f, kind = SpawnKind.SUPPLY_PAD),
        MapSpawnPoint(id = "supply_south", x = 15.0f, y = 12.8f, kind = SpawnKind.SUPPLY_PAD)
    )

    // Wide tactical lanes (>= 2.0 tiles clearance everywhere) so tanks maneuver cleanly
    fun createInitialWalls(): List<MapWall> = listOf(
        // West Base Cover Pillars (Indestructible Concrete/Steel)
        MapWall("w_west_top", left = 5.2f, top = 2.3f, right = 6.3f, bottom = 4.6f, destructible = false, hp = 99999, maxHp = 99999),
        MapWall("w_west_bot", left = 5.2f, top = 10.4f, right = 6.3f, bottom = 12.7f, destructible = false, hp = 99999, maxHp = 99999),

        // East Base Cover Pillars (Indestructible Concrete/Steel)
        MapWall("w_east_top", left = 23.7f, top = 2.3f, right = 24.8f, bottom = 4.6f, destructible = false, hp = 99999, maxHp = 99999),
        MapWall("w_east_bot", left = 23.7f, top = 10.4f, right = 24.8f, bottom = 12.7f, destructible = false, hp = 99999, maxHp = 99999),

        // Mid-Arena Tactical Bunkers (Indestructible)
        MapWall("w_mid_nw", left = 10.3f, top = 3.8f, right = 12.1f, bottom = 4.9f, destructible = false, hp = 99999, maxHp = 99999),
        MapWall("w_mid_sw", left = 10.3f, top = 10.1f, right = 12.1f, bottom = 11.2f, destructible = false, hp = 99999, maxHp = 99999),
        MapWall("w_mid_ne", left = 17.9f, top = 3.8f, right = 19.7f, bottom = 4.9f, destructible = false, hp = 99999, maxHp = 99999),
        MapWall("w_mid_se", left = 17.9f, top = 10.1f, right = 19.7f, bottom = 11.2f, destructible = false, hp = 99999, maxHp = 99999),

        // Central Ring Pillars flanking central Supply Pad (15, 7.5)
        MapWall("w_center_n", left = 14.2f, top = 4.5f, right = 15.8f, bottom = 5.4f, destructible = false, hp = 99999, maxHp = 99999),
        MapWall("w_center_s", left = 14.2f, top = 9.6f, right = 15.8f, bottom = 10.5f, destructible = false, hp = 99999, maxHp = 99999),

        // Destructible Brick/Crate Barricades (can be blasted open!)
        MapWall("b_west_gate", left = 8.4f, top = 6.5f, right = 9.4f, bottom = 8.5f, destructible = true, hp = 1100, maxHp = 1100),
        MapWall("b_east_gate", left = 20.6f, top = 6.5f, right = 21.6f, bottom = 8.5f, destructible = true, hp = 1100, maxHp = 1100),
        MapWall("b_north_lane", left = 11.4f, top = 1.0f, right = 13.0f, bottom = 2.0f, destructible = true, hp = 900, maxHp = 900),
        MapWall("b_south_lane", left = 17.0f, top = 13.0f, right = 18.6f, bottom = 14.0f, destructible = true, hp = 900, maxHp = 900)
    )
}

data class BattleUiState(
    val phase: BattlePhase = BattlePhase.IDLE,
    val battleMode: BattleMode = BattleMode.SUPERVIVENCIA_3D,
    val matchId: String? = null,
    val isHost: Boolean = true,
    val playerDisplayName: String = "Comandante",
    val enemyDisplayName: String = "Rival en línea",
    val matchmakingElapsedSec: Int = 0,
    val matchmakingStatusText: String = "Buscando rival en línea...",
    val opponentConnectionWarning: Boolean = false,
    val introCountdownSec: Float = 2.0f,
    val timeRemainingSec: Float = EconomyRules.MATCH_DURATION_SECONDS.toFloat(),
    val playerTank: TankDefinition? = null,
    val playerLevel: Int = 1,
    val enemyTank: TankDefinition? = null,
    val enemyLevel: Int = 1,
    val playerX: Float = 2.4f,
    val playerY: Float = 7.5f,
    val playerChassisAngleRad: Float = 0f,
    val playerTurretAngleRad: Float = 0f,
    val playerIsAiming: Boolean = false,
    val playerHp: Int = 2250,
    val playerMaxHp: Int = 2250,
    val playerShieldHp: Int = 0,
    val playerTurboSec: Float = 0f,
    val playerOverchargeSec: Float = 0f,
    val playerRecoilSec: Float = 0f,
    val enemyX: Float = 27.6f,
    val enemyY: Float = 7.5f,
    val enemyChassisAngleRad: Float = Math.PI.toFloat(),
    val enemyTurretAngleRad: Float = Math.PI.toFloat(),
    val enemyHp: Int = 3000,
    val enemyMaxHp: Int = 3000,
    val enemyShieldHp: Int = 0,
    val enemyTurboActive: Boolean = false,
    val enemyOverchargeActive: Boolean = false,
    val enemyStunSec: Float = 0f,
    val enemyRecoilSec: Float = 0f,
    val elixir: Float = 5.0f,
    val maxElixir: Float = 10f,
    val isDoubleElixir: Boolean = false,
    val handCards: List<BattleCard> = emptyList(),
    val nextCard: BattleCard? = null,
    val fireCooldownSec: Float = 0f,
    val spawnPoints: List<MapSpawnPoint> = SurvivalMapSpec.spawnPoints,
    val walls: List<MapWall> = SurvivalMapSpec.createInitialWalls(),
    val pickups: List<SupplyPickup> = emptyList(),
    val safeZone: SafeZoneBounds = SafeZoneBounds(),
    val stormActive: Boolean = false,
    val projectiles: List<BattleProjectile> = emptyList(),
    val explosions: List<BattleExplosion> = emptyList(),
    val floatingTexts: List<FloatingBattleText> = emptyList(),
    val matchDamageDealt: Int = 0,
    val matchShotsFired: Int = 0,
    val matchCardsPlayed: Int = 0,
    val rewardSummary: MatchRewardSummary? = null
)
