package com.example

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ads.AdMobRewardedManager
import com.example.billing.PlayBillingManager
import com.example.data.GameCatalog
import com.example.data.UserProfileMapper
import com.example.legal.LegalConsentPrefs
import com.example.model.AppTab
import com.example.model.BattleMode
import com.example.model.EconomyRules
import com.example.model.ShopPackKind
import com.example.ui.components.SubScreenTopBar
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.BattleScreen
import com.example.ui.screens.CompanyIntroScreen
import com.example.ui.screens.CrateResultDialog
import com.example.ui.screens.DailyLimitsDialog
import com.example.ui.screens.GameModesDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LegalConsentScreen
import com.example.ui.screens.MissionsScreen
import com.example.ui.screens.RarityProbabilitiesDialog
import com.example.ui.screens.SettingsDialog
import com.example.ui.screens.ShopScreen
import com.example.ui.screens.TanksScreen
import com.example.ui.screens.signOutFromTanksWar
import com.example.ui.theme.ArcadeBluePanel
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TanksWarTheme
import com.example.viewmodel.GameViewModel
import com.example.viewmodel.GameViewModelFactory
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {

    private lateinit var adManager: AdMobRewardedManager
    private lateinit var billingManager: PlayBillingManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        adManager = AdMobRewardedManager(applicationContext)
        billingManager = PlayBillingManager(applicationContext)
        setContent {
            TanksWarTheme {
                var legalAccepted by rememberSaveable {
                    mutableStateOf(LegalConsentPrefs.isAccepted(applicationContext))
                }
                var showCompanyIntro by rememberSaveable { mutableStateOf(true) }

                LaunchedEffect(legalAccepted) {
                    if (legalAccepted) {
                        adManager.initializeAndPreload()
                        billingManager.initializeAndConnect()
                    }
                }

                if (!legalAccepted) {
                    LegalConsentScreen(
                        onAccepted = {
                            LegalConsentPrefs.setAccepted(applicationContext, true)
                            legalAccepted = true
                        },
                        onDeclineExit = {
                            finishAffinity()
                        }
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize()) {
                        TanksWarAuthGate(
                            adManager = adManager,
                            billingManager = billingManager
                        )
                        AnimatedVisibility(
                            visible = showCompanyIntro,
                            exit = fadeOut(animationSpec = tween(durationMillis = 360))
                        ) {
                            CompanyIntroScreen(
                                onFinished = { showCompanyIntro = false }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::billingManager.isInitialized && LegalConsentPrefs.isAccepted(applicationContext)) {
            billingManager.queryAndProcessPurchases()
        }
    }

    override fun onDestroy() {
        if (::billingManager.isInitialized) {
            billingManager.endConnection()
        }
        super.onDestroy()
    }
}

@Composable
private fun TanksWarAuthGate(
    adManager: AdMobRewardedManager,
    billingManager: PlayBillingManager
) {
    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    val user = currentUser
    if (user == null) {
        AuthScreen(
            onAuthSuccess = { currentUser = Firebase.auth.currentUser }
        )
    } else {
        val context = LocalContext.current
        val displayName = UserProfileMapper.sanitizeDisplayName(
            user.displayName ?: user.email?.substringBefore("@")
        )
        key(user.uid) {
            val vm: GameViewModel = viewModel(
                key = user.uid,
                factory = GameViewModelFactory(
                    context = context,
                    userId = user.uid,
                    displayName = displayName
                )
            )
            TanksWarApp(
                viewModel = vm,
                adManager = adManager,
                billingManager = billingManager,
                playerDisplayName = displayName,
                playerEmail = user.email
            )
        }
    }
}

@Composable
fun TanksWarApp(
    viewModel: GameViewModel,
    adManager: AdMobRewardedManager,
    billingManager: PlayBillingManager,
    playerDisplayName: String,
    playerEmail: String?
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val snapshot by viewModel.snapshot.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val selectedTankId by viewModel.selectedTankId.collectAsStateWithLifecycle()
    val battleState by viewModel.battleState.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
    val crateResult by viewModel.crateResult.collectAsStateWithLifecycle()
    val adStatus by adManager.status.collectAsStateWithLifecycle()
    val adStatusMessage by adManager.statusMessage.collectAsStateWithLifecycle()
    val billingStatus by billingManager.connectionState.collectAsStateWithLifecycle()
    val billingStatusMessage by billingManager.statusMessage.collectAsStateWithLifecycle()
    val playFormattedPrices by billingManager.formattedPrices.collectAsStateWithLifecycle()

    DisposableEffect(viewModel, billingManager) {
        billingManager.attachPurchaseHandler(
            onGrant = { productId, qty, _ ->
                viewModel.grantVerifiedPlayPurchase(productId, qty)
            },
            onMessage = { msg -> viewModel.showToast(msg) }
        )
        onDispose {
            billingManager.detachPurchaseHandler()
        }
    }

    var showSettings by remember { mutableStateOf(false) }
    var showProbabilities by remember { mutableStateOf(false) }
    var showDailyLimits by remember { mutableStateOf(false) }
    var showModes by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(toastMessage) {
        val msg = toastMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        viewModel.dismissToast()
    }

    LaunchedEffect(currentTab) {
        if (currentTab == AppTab.SHOP) {
            adManager.preloadIfNeeded()
            billingManager.queryProductDetails()
        }
    }

    if (currentTab != AppTab.HOME && currentTab != AppTab.BATTLE) {
        BackHandler {
            viewModel.selectTab(AppTab.HOME)
        }
    }

    val isMondayAvailable = viewModel.isMondayTodayOrSimulated()
    val isWeeklyClaimed = viewModel.isWeeklyOfferClaimedThisWeek()

    val shopBadgeCount = if (snapshot.dailyAdsWatched < EconomyRules.MAX_DAILY_ADS) 1 else 0
    val claimableMissionsCount = GameCatalog.missions.count { m ->
        m.id !in snapshot.claimedMissionIds && viewModel.missionProgress(m, snapshot) >= m.target
    }
    val nextMission = GameCatalog.missions.firstOrNull { it.id !in snapshot.claimedMissionIds }
        ?: GameCatalog.missions.firstOrNull()
    val nextMissionProgress = nextMission?.let { viewModel.missionProgress(it, snapshot) } ?: 0

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = ArcadeBluePanel,
                    contentColor = GoldPrimary
                )
            }
        },
        topBar = {
            if (currentTab != AppTab.HOME && currentTab != AppTab.BATTLE) {
                SubScreenTopBar(
                    currentTab = currentTab,
                    snapshot = snapshot,
                    onBackHome = { viewModel.selectTab(AppTab.HOME) },
                    onOpenSettings = { showSettings = true }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppTab.HOME -> {
                    HomeScreen(
                        snapshot = snapshot,
                        shopBadgeCount = shopBadgeCount,
                        missionsBadgeCount = claimableMissionsCount,
                        nextMission = nextMission,
                        nextMissionProgress = nextMissionProgress,
                        onStartBattle = { viewModel.startNewBattle() },
                        onOpenTanks = { viewModel.selectTab(AppTab.TANKS) },
                        onOpenShop = { viewModel.selectTab(AppTab.SHOP) },
                        onOpenMissions = { viewModel.selectTab(AppTab.MISSIONS) },
                        onOpenCrate = { viewModel.openTankCrate() },
                        onOpenProbabilities = { showProbabilities = true },
                        onOpenDailyLimits = { showDailyLimits = true },
                        onOpenModes = { showModes = true },
                        onOpenSettings = { showSettings = true }
                    )
                }
                AppTab.TANKS -> TanksScreen(
                    snapshot = snapshot,
                    selectedTankId = selectedTankId,
                    onSelectTank = { viewModel.selectTankForPreview(it) },
                    onEquipTank = { viewModel.equipTank(it) },
                    onUnlockTank = { viewModel.unlockTank(it) },
                    onUpgradeTank = { viewModel.upgradeTank(it) },
                    onOpenCrate = { viewModel.openTankCrate() },
                    onOpenProbabilities = { showProbabilities = true }
                )
                AppTab.BATTLE -> BattleScreen(
                    battleState = battleState,
                    onSkipIntro = { viewModel.skipVsIntro() },
                    onMoveVector = { dx, dy -> viewModel.setMoveVector(dx, dy) },
                    onAimInput = { dx, dy, pressed, released ->
                        viewModel.setAimInput(dx, dy, pressed, released)
                    },
                    onPlayCard = { viewModel.playBattleCard(it) },
                    onRematch = { viewModel.startNewBattle() },
                    onExitBattle = { viewModel.exitBattleToHome() }
                )
                AppTab.SHOP -> ShopScreen(
                    snapshot = snapshot,
                    isMondayAvailable = isMondayAvailable,
                    isWeeklyClaimedThisWeek = isWeeklyClaimed,
                    adStatus = adStatus,
                    adStatusMessage = adStatusMessage,
                    billingStatus = billingStatus,
                    billingStatusMessage = billingStatusMessage,
                    playFormattedPrices = playFormattedPrices,
                    onWatchAdClick = { pack ->
                        if (!viewModel.canWatchOptionalAdToday()) {
                            viewModel.showToast("Has alcanzado el límite de 4 anuncios hoy. ¡Vuelve mañana!")
                        } else {
                            val activity = context as? Activity
                            if (activity == null) {
                                viewModel.showToast("No se pudo abrir el anuncio desde este contexto")
                            } else {
                                adManager.showRewardedAd(
                                    activity = activity,
                                    onRewardEarned = { viewModel.grantRewardedAdPack(pack) },
                                    onClosedWithoutReward = {
                                        viewModel.showToast("Anuncio cerrado antes de completarse: sin recompensa")
                                    },
                                    onFailedToShow = { msg -> viewModel.showToast(msg) }
                                )
                            }
                        }
                    },
                    onPackClick = { pack ->
                        when (pack.kind) {
                            ShopPackKind.BOMBS_FOR_GEMS -> viewModel.buyGemBombPack(pack)
                            ShopPackKind.BOMBS_FOR_EUR,
                            ShopPackKind.MONDAY_WEEKLY_FC -> {
                                if (viewModel.canStartPlayPurchase(pack)) {
                                    val activity = context as? Activity
                                    if (activity == null) {
                                        viewModel.showToast("No se pudo iniciar Google Play desde este contexto")
                                    } else {
                                        billingManager.launchPurchase(
                                            activity = activity,
                                            productId = pack.id,
                                            obfuscatedAccountId = viewModel.userId,
                                            onError = { msg -> viewModel.showToast(msg) }
                                        )
                                    }
                                }
                            }
                            ShopPackKind.OPTIONAL_AD -> Unit
                        }
                    },
                    onToggleSimulateMonday = { viewModel.toggleSimulateMonday(it) }
                )
                AppTab.MISSIONS -> MissionsScreen(
                    snapshot = snapshot,
                    progressProvider = { viewModel.missionProgress(it, snapshot) },
                    onClaimMission = { viewModel.claimMission(it) },
                    onUnlockBattlePass = { viewModel.unlockBattlePass() },
                    onClaimPassTier = { viewModel.claimPassTier(it) }
                )
            }
        }
    }

    crateResult?.let { result ->
        CrateResultDialog(
            result = result,
            onDismiss = { viewModel.dismissCrateResult() }
        )
    }

    if (showProbabilities) {
        RarityProbabilitiesDialog(onDismiss = { showProbabilities = false })
    }

    if (showDailyLimits) {
        DailyLimitsDialog(
            snapshot = snapshot,
            onDismiss = { showDailyLimits = false }
        )
    }

    if (showModes) {
        GameModesDialog(
            selectedMode = BattleMode.fromId(snapshot.selectedModeId),
            onSelectMode = { viewModel.selectBattleMode(it) },
            onDismiss = { showModes = false }
        )
    }

    if (showSettings) {
        SettingsDialog(
            snapshot = snapshot,
            playerDisplayName = playerDisplayName,
            playerEmail = playerEmail,
            isRealMondayOrSimulated = isMondayAvailable,
            onToggleSimulateMonday = { viewModel.toggleSimulateMonday(it) },
            onToggleSound = { viewModel.toggleSound(it) },
            onResetDailyLimits = { viewModel.resetDailyLimitsForTesting() },
            onResetAllProgress = { viewModel.resetAllProgress() },
            onSignOut = {
                signOutFromTanksWar(
                    credentialManager = credentialManager,
                    scope = scope,
                    onBeforeFirebaseSignOut = { viewModel.cleanupBeforeSignOut() }
                )
            },
            onDismiss = { showSettings = false }
        )
    }
}
