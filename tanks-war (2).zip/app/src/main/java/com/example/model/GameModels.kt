package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.RarityCentella
import com.example.ui.theme.RarityEpica
import com.example.ui.theme.RarityEspecial
import com.example.ui.theme.RarityLegendaria
import com.example.ui.theme.RarityMitica
import com.example.ui.theme.RarityStandard
import com.squareup.moshi.JsonClass
import kotlin.math.pow
import kotlin.math.roundToInt

enum class AppTab(val label: String) {
    HOME("Inicio"),
    TANKS("Tanques"),
    BATTLE("¡Batalla!"),
    SHOP("Tienda"),
    MISSIONS("Misiones")
}

enum class CurrencyType(val symbol: String, val displayName: String) {
    BOMBAS("b", "Bombas"),
    GEMAS("g", "Gemas"),
    FICHAS_CENTELLA("fc", "Fichas Centella")
}

enum class TankRarity(
    val shortCode: String,
    val displayName: String,
    val probabilityPercent: Double,
    val speedRangeLabel: String,
    val hpRangeLabel: String,
    val costRangeLabel: String,
    val accentColor: Color
) {
    ESTANDAR(
        shortCode = "Est",
        displayName = "Estándar",
        probabilityPercent = 50.0,
        speedRangeLabel = "1,5 cas/seg",
        hpRangeLabel = "1800-2000",
        costRangeLabel = "Inicial / Botín",
        accentColor = RarityStandard
    ),
    ESPECIAL(
        shortCode = "Esp",
        displayName = "Especial",
        probabilityPercent = 2.5,
        speedRangeLabel = "1-2 cas/seg",
        hpRangeLabel = "2000-2500",
        costRangeLabel = "1000 g",
        accentColor = RarityEspecial
    ),
    EPICA(
        shortCode = "Ep",
        displayName = "Épica",
        probabilityPercent = 7.5,
        speedRangeLabel = "2-3 cas/seg",
        hpRangeLabel = "2600-3500",
        costRangeLabel = "2000-2750 g",
        accentColor = RarityEpica
    ),
    MITICA(
        shortCode = "Mi",
        displayName = "Mítica",
        probabilityPercent = 10.0,
        speedRangeLabel = "3-5 cas/seg",
        hpRangeLabel = "3500-4000",
        costRangeLabel = "5000 g",
        accentColor = RarityMitica
    ),
    LEGENDARIA(
        shortCode = "Leg",
        displayName = "Legendaria",
        probabilityPercent = 13.0,
        speedRangeLabel = "5 cas/seg",
        hpRangeLabel = "4000-5000",
        costRangeLabel = "6000-7000 g",
        accentColor = RarityLegendaria
    ),
    CENTELLA(
        shortCode = "Cent",
        displayName = "Centella",
        probabilityPercent = 17.0,
        speedRangeLabel = "7 cas/seg",
        hpRangeLabel = "7000-8500",
        costRangeLabel = "5000-7000 fc",
        accentColor = RarityCentella
    )
}

enum class TankHullStyle {
    CLASSIC_T34,
    HEAVY_KV2,
    PANZER_FAST,
    CENTAURO_DUAL,
    SOVEREIGN_GOLD,
    CENTELLA_VOLT
}

data class TankDefinition(
    val id: String,
    val name: String,
    val subtitle: String,
    val rarity: TankRarity,
    val speedTilesPerSec: Float,
    val baseHp: Int,
    val baseDamage: Int = 500,
    val unlockCurrency: CurrencyType,
    val unlockCost: Int,
    val hullStyle: TankHullStyle,
    val primaryColorHex: Long,
    val secondaryColorHex: Long,
    val unlockedByDefault: Boolean = false
) {
    fun hpAtLevel(level: Int): Int {
        val clamped = level.coerceIn(1, EconomyRules.MAX_TANK_LEVEL)
        return (baseHp * (1f + (clamped - 1) * 0.08f)).roundToInt()
    }

    fun damageAtLevel(level: Int): Int {
        val clamped = level.coerceIn(1, EconomyRules.MAX_TANK_LEVEL)
        return (baseDamage * (1f + (clamped - 1) * 0.08f)).roundToInt()
    }
}

enum class BattleCardEffect {
    HEAVY_BOMB,
    TRIPLE_BURST,
    ARMOR_SHIELD,
    TURBO_TRACKS,
    CENTELLA_BOLT,
    REPAIR_KIT
}

data class BattleCard(
    val id: String,
    val name: String,
    val description: String,
    val elixirCost: Int,
    val effect: BattleCardEffect,
    val badgeColor: Color
)

data class MissionDefinition(
    val id: String,
    val title: String,
    val description: String,
    val target: Int,
    val rewardGems: Int,
    val rewardFc: Int,
    val progressType: MissionProgressType
)

enum class MissionProgressType {
    WINS,
    SHOTS_FIRED,
    DAMAGE_DEALT,
    CARDS_PLAYED,
    UPGRADES_DONE,
    OPTIONAL_ADS_WATCHED
}

enum class ShopPackKind {
    OPTIONAL_AD,
    BOMBS_FOR_GEMS,
    BOMBS_FOR_EUR,
    MONDAY_WEEKLY_FC
}

data class ShopPackDefinition(
    val id: String,
    val title: String,
    val subtitle: String,
    val rewardLabel: String,
    val priceLabel: String,
    val kind: ShopPackKind,
    val bombsGranted: Int = 0,
    val gemsGranted: Int = 0,
    val fcGranted: Int = 0,
    val gemCost: Int = 0,
    val highlighted: Boolean = false
)

object EconomyRules {
    const val MAP_WIDTH_TILES = 30
    const val MAP_HEIGHT_TILES = 15
    const val MATCH_DURATION_SECONDS = 120
    const val BASE_BOMB_SPEED_TILES_PER_SEC = 7.5f
    const val BASE_BOMB_DAMAGE = 500

    const val MAX_TANK_LEVEL = 10
    const val UPGRADE_BASE_COST_BOMBAS = 50
    const val UPGRADE_SCALING_FACTOR = 1.5

    const val MAX_DAILY_FC = 100
    const val MAX_DAILY_MATCH_GEMS = 400
    const val MAX_DAILY_BONUS_GEMS = 100
    const val MAX_DAILY_ADS = 4

    const val WIN_REWARD_BOMBAS = 25
    const val WIN_REWARD_GEMS = 50
    const val WIN_REWARD_FC = 10

    const val LOSS_REWARD_BOMBAS = 7
    const val LOSS_REWARD_GEMS = 15
    const val LOSS_REWARD_FC = 3

    const val CRATE_COST_GEMAS = 150
    const val BATTLE_PASS_COST_GEMS = 1500
    const val MONDAY_OFFER_FC = 150

    fun upgradeCostBombas(currentLevel: Int): Int {
        if (currentLevel >= MAX_TANK_LEVEL) return 0
        val exponent = (currentLevel - 1).coerceAtLeast(0)
        return (UPGRADE_BASE_COST_BOMBAS * UPGRADE_SCALING_FACTOR.pow(exponent.toDouble())).roundToInt()
    }
}

enum class BattleMode(
    val id: String,
    val title: String,
    val subtitle: String,
    val badge: String,
    val elixirMultiplier: Float,
    val stormStartRemainingSec: Float
) {
    SUPERVIVENCIA_3D(
        id = "supervivencia_3d",
        title = "SUPERVIVENCIA 3D",
        subtitle = "Mapa 30x15 | Zona Fuego | 2:00",
        badge = "1 vs 1",
        elixirMultiplier = 1.0f,
        stormStartRemainingSec = 75f
    ),
    DUELO_RELAMPAGO(
        id = "duelo_relampago",
        title = "DUELO RELÁMPAGO",
        subtitle = "Elixir x1.5 | Fuego Rápido | 30x15",
        badge = "TURBO",
        elixirMultiplier = 1.45f,
        stormStartRemainingSec = 95f
    );

    companion object {
        fun fromId(id: String?): BattleMode = entries.firstOrNull { it.id == id } ?: SUPERVIVENCIA_3D
    }
}

@JsonClass(generateAdapter = true)
data class GameStateSnapshot(
    val bombas: Int = 180,
    val gemas: Int = 450,
    val fichasCentella: Int = 35,
    val unlockedTankIds: List<String> = listOf("recluta_m4", "especialista_t34"),
    val tankLevels: Map<String, Int> = mapOf("recluta_m4" to 1, "especialista_t34" to 1),
    val activeTankId: String = "especialista_t34",
    val selectedModeId: String = BattleMode.SUPERVIVENCIA_3D.id,
    val dailyDateKey: String = "",
    val dailyFcEarned: Int = 0,
    val dailyMatchGemsEarned: Int = 0,
    val dailyBonusGemsEarned: Int = 0,
    val dailyAdsWatched: Int = 0,
    val weeklyOfferClaimedWeekKey: String? = null,
    val simulateMondayForTesting: Boolean = false,
    val hasBattlePass: Boolean = false,
    val claimedPassTiers: List<Int> = emptyList(),
    val totalWins: Int = 0,
    val totalMatches: Int = 0,
    val totalShotsFired: Int = 0,
    val totalDamageDealt: Int = 0,
    val totalCardsPlayed: Int = 0,
    val totalUpgradesDone: Int = 0,
    val totalAdsWatchedAllTime: Int = 0,
    val claimedMissionIds: List<String> = emptyList(),
    val soundEnabled: Boolean = true,
    val lastCratePullSummary: String? = null
)
