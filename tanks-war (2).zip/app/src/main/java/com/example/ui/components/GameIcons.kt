package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ArcadeBlueBright
import com.example.ui.theme.CentellaCyan
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GreenAction
import com.example.ui.theme.GreenActionDeep
import com.example.ui.theme.OutlineDark
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Custom cartoon/arcade Tank silhouette icon (replaces generic car icon).
 */
@Composable
fun TankArcadeIcon(modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val stroke = w * 0.065f

        // Cannon barrel
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFF93C5FD), Color(0xFF3B82F6), Color(0xFF1D4ED8))),
            topLeft = Offset(w * 0.50f, h * 0.25f),
            size = Size(w * 0.42f, h * 0.14f),
            cornerRadius = CornerRadius(w * 0.05f, w * 0.05f)
        )
        drawRoundRect(
            color = OutlineDark,
            topLeft = Offset(w * 0.50f, h * 0.25f),
            size = Size(w * 0.42f, h * 0.14f),
            cornerRadius = CornerRadius(w * 0.05f, w * 0.05f),
            style = Stroke(width = stroke)
        )
        // Muzzle tip
        drawRoundRect(
            color = Color(0xFF1E3A8A),
            topLeft = Offset(w * 0.84f, h * 0.22f),
            size = Size(w * 0.11f, h * 0.20f),
            cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
        )
        drawRoundRect(
            color = OutlineDark,
            topLeft = Offset(w * 0.84f, h * 0.22f),
            size = Size(w * 0.11f, h * 0.20f),
            cornerRadius = CornerRadius(w * 0.04f, w * 0.04f),
            style = Stroke(width = stroke * 0.85f)
        )

        // Turret dome
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFFBFDBFE), Color(0xFF3B82F6), Color(0xFF1E40AF))),
            topLeft = Offset(w * 0.22f, h * 0.18f),
            size = Size(w * 0.42f, h * 0.27f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f)
        )
        drawRoundRect(
            color = OutlineDark,
            topLeft = Offset(w * 0.22f, h * 0.18f),
            size = Size(w * 0.42f, h * 0.27f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f),
            style = Stroke(width = stroke)
        )

        // Armored Hull
        val hull = Path().apply {
            moveTo(w * 0.14f, h * 0.42f)
            lineTo(w * 0.78f, h * 0.42f)
            lineTo(w * 0.88f, h * 0.60f)
            lineTo(w * 0.10f, h * 0.60f)
            close()
        }
        drawPath(
            path = hull,
            brush = Brush.verticalGradient(listOf(Color(0xFF60A5FA), ArcadeBlueBright, Color(0xFF1E3A8A)))
        )
        drawPath(path = hull, color = OutlineDark, style = Stroke(width = stroke, join = StrokeJoin.Round))

        // Heavy Treads
        drawRoundRect(
            color = Color(0xFF334155),
            topLeft = Offset(w * 0.08f, h * 0.58f),
            size = Size(w * 0.84f, h * 0.24f),
            cornerRadius = CornerRadius(h * 0.12f, h * 0.12f)
        )
        drawRoundRect(
            color = OutlineDark,
            topLeft = Offset(w * 0.08f, h * 0.58f),
            size = Size(w * 0.84f, h * 0.24f),
            cornerRadius = CornerRadius(h * 0.12f, h * 0.12f),
            style = Stroke(width = stroke)
        )

        // 4 Track Wheels
        for (i in 0..3) {
            val wx = w * (0.20f + i * 0.20f)
            val wy = h * 0.70f
            drawCircle(color = Color(0xFF94A3B8), radius = h * 0.068f, center = Offset(wx, wy))
            drawCircle(color = OutlineDark, radius = h * 0.068f, center = Offset(wx, wy), style = Stroke(width = stroke * 0.6f))
        }
    }
}

/**
 * Custom arcade market awning Shop icon.
 */
@Composable
fun ShopArcadeIcon(modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val stroke = w * 0.06f

        // Store base box
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFFFEF3C7), Color(0xFFFDE68A))),
            topLeft = Offset(w * 0.16f, h * 0.42f),
            size = Size(w * 0.68f, h * 0.46f),
            cornerRadius = CornerRadius(w * 0.06f, w * 0.06f)
        )
        drawRoundRect(
            color = OutlineDark,
            topLeft = Offset(w * 0.16f, h * 0.42f),
            size = Size(w * 0.68f, h * 0.46f),
            cornerRadius = CornerRadius(w * 0.06f, w * 0.06f),
            style = Stroke(width = stroke)
        )

        // Window / Counter display
        drawRoundRect(
            color = Color(0xFF0EA5E9),
            topLeft = Offset(w * 0.25f, h * 0.54f),
            size = Size(w * 0.50f, h * 0.22f),
            cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
        )
        drawRoundRect(
            color = OutlineDark,
            topLeft = Offset(w * 0.25f, h * 0.54f),
            size = Size(w * 0.50f, h * 0.22f),
            cornerRadius = CornerRadius(w * 0.04f, w * 0.04f),
            style = Stroke(width = stroke * 0.7f)
        )

        // Awning stripes
        val stripeCount = 4
        val awningLeft = w * 0.10f
        val awningWidth = w * 0.80f
        val stripeW = awningWidth / stripeCount
        for (i in 0 until stripeCount) {
            val sx = awningLeft + i * stripeW
            val stripeColor = if (i % 2 == 0) CrimsonDanger else GoldPrimary
            drawRoundRect(
                color = stripeColor,
                topLeft = Offset(sx, h * 0.14f),
                size = Size(stripeW, h * 0.30f),
                cornerRadius = CornerRadius(w * 0.05f, w * 0.05f)
            )
            drawRoundRect(
                color = OutlineDark,
                topLeft = Offset(sx, h * 0.14f),
                size = Size(stripeW, h * 0.30f),
                cornerRadius = CornerRadius(w * 0.05f, w * 0.05f),
                style = Stroke(width = stroke * 0.85f)
            )
        }
    }
}

/**
 * Custom arcade Mission badge/scroll with checkmark & gold star.
 */
@Composable
fun MissionsArcadeIcon(modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val stroke = w * 0.065f

        // Board body
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(GreenAction, GreenActionDeep)),
            topLeft = Offset(w * 0.16f, h * 0.18f),
            size = Size(w * 0.68f, h * 0.72f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f)
        )
        drawRoundRect(
            color = OutlineDark,
            topLeft = Offset(w * 0.16f, h * 0.18f),
            size = Size(w * 0.68f, h * 0.72f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f),
            style = Stroke(width = stroke)
        )

        // Gold top clip
        drawRoundRect(
            color = GoldPrimary,
            topLeft = Offset(w * 0.33f, h * 0.08f),
            size = Size(w * 0.34f, h * 0.16f),
            cornerRadius = CornerRadius(w * 0.06f, w * 0.06f)
        )
        drawRoundRect(
            color = OutlineDark,
            topLeft = Offset(w * 0.33f, h * 0.08f),
            size = Size(w * 0.34f, h * 0.16f),
            cornerRadius = CornerRadius(w * 0.06f, w * 0.06f),
            style = Stroke(width = stroke * 0.85f)
        )

        // Crisp checkmark
        val check = Path().apply {
            moveTo(w * 0.30f, h * 0.56f)
            lineTo(w * 0.45f, h * 0.70f)
            lineTo(w * 0.70f, h * 0.40f)
        }
        drawPath(
            path = check,
            color = Color.White,
            style = Stroke(width = w * 0.11f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

/**
 * Golden angled War Pass ticket icon.
 */
@Composable
fun WarPassArcadeIcon(modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val stroke = w * 0.06f
        rotate(-10f) {
            drawRoundRect(
                brush = Brush.linearGradient(listOf(Color(0xFFFEF08A), GoldPrimary, GoldDeep)),
                topLeft = Offset(w * 0.08f, h * 0.24f),
                size = Size(w * 0.84f, h * 0.52f),
                cornerRadius = CornerRadius(w * 0.10f, w * 0.10f)
            )
            drawRoundRect(
                color = OutlineDark,
                topLeft = Offset(w * 0.08f, h * 0.24f),
                size = Size(w * 0.84f, h * 0.52f),
                cornerRadius = CornerRadius(w * 0.10f, w * 0.10f),
                style = Stroke(width = stroke)
            )
            drawStar(center = Offset(w * 0.42f, h * 0.50f), outerR = w * 0.16f, innerR = w * 0.07f, color = Color(0xFF7C2D12))
            drawLine(
                color = OutlineDark,
                start = Offset(w * 0.68f, h * 0.28f),
                end = Offset(w * 0.68f, h * 0.72f),
                strokeWidth = stroke * 0.8f
            )
        }
    }
}

/**
 * Custom arcade Crate chest icon (clean stylized wooden+gold tank crate).
 */
@Composable
fun CrateArcadeIcon(modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val stroke = w * 0.065f

        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFFF59E0B), Color(0xFFB45309))),
            topLeft = Offset(w * 0.12f, h * 0.18f),
            size = Size(w * 0.76f, h * 0.68f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f)
        )
        drawRoundRect(
            color = GoldPrimary,
            topLeft = Offset(w * 0.12f, h * 0.18f),
            size = Size(w * 0.76f, h * 0.24f),
            cornerRadius = CornerRadius(w * 0.10f, w * 0.10f)
        )
        // Iron strap & clasp
        drawRect(color = Color(0xFF334155), topLeft = Offset(w * 0.14f, h * 0.40f), size = Size(w * 0.72f, h * 0.11f))
        drawRoundRect(
            color = GoldPrimary,
            topLeft = Offset(w * 0.42f, h * 0.36f),
            size = Size(w * 0.16f, h * 0.20f),
            cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
        )
        drawRoundRect(
            color = OutlineDark,
            topLeft = Offset(w * 0.42f, h * 0.36f),
            size = Size(w * 0.16f, h * 0.20f),
            cornerRadius = CornerRadius(w * 0.04f, w * 0.04f),
            style = Stroke(width = stroke * 0.75f)
        )
        drawRoundRect(
            color = OutlineDark,
            topLeft = Offset(w * 0.12f, h * 0.18f),
            size = Size(w * 0.76f, h * 0.68f),
            cornerRadius = CornerRadius(w * 0.12f, w * 0.12f),
            style = Stroke(width = stroke)
        )
    }
}

/**
 * Custom arcade Dice / Probabilities icon.
 */
@Composable
fun ProbabilitiesArcadeIcon(modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val stroke = w * 0.065f
        rotate(-8f) {
            drawRoundRect(
                brush = Brush.linearGradient(listOf(Color(0xFFA5F3FC), CentellaCyan, Color(0xFF0284C7))),
                topLeft = Offset(w * 0.16f, h * 0.16f),
                size = Size(w * 0.68f, h * 0.68f),
                cornerRadius = CornerRadius(w * 0.15f, w * 0.15f)
            )
            drawRoundRect(
                color = OutlineDark,
                topLeft = Offset(w * 0.16f, h * 0.16f),
                size = Size(w * 0.68f, h * 0.68f),
                cornerRadius = CornerRadius(w * 0.15f, w * 0.15f),
                style = Stroke(width = stroke)
            )
            val pipR = w * 0.068f
            drawCircle(Color.White, radius = pipR, center = Offset(w * 0.34f, h * 0.34f))
            drawCircle(Color.White, radius = pipR, center = Offset(w * 0.66f, h * 0.66f))
            drawCircle(GoldPrimary, radius = pipR * 1.05f, center = Offset(w * 0.50f, h * 0.50f))
            drawCircle(Color.White, radius = pipR, center = Offset(w * 0.66f, h * 0.34f))
            drawCircle(Color.White, radius = pipR, center = Offset(w * 0.34f, h * 0.66f))
        }
    }
}

/**
 * Custom arcade Daily Limits / Gauge Chart icon.
 */
@Composable
fun LimitsArcadeIcon(modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val stroke = w * 0.06f

        // Base plate
        drawRoundRect(
            color = Color(0xFF1E3A8A),
            topLeft = Offset(w * 0.12f, h * 0.16f),
            size = Size(w * 0.76f, h * 0.68f),
            cornerRadius = CornerRadius(w * 0.14f, w * 0.14f)
        )
        drawRoundRect(
            color = OutlineDark,
            topLeft = Offset(w * 0.12f, h * 0.16f),
            size = Size(w * 0.76f, h * 0.68f),
            cornerRadius = CornerRadius(w * 0.14f, w * 0.14f),
            style = Stroke(width = stroke)
        )
        val bars = listOf(
            Triple(0.24f, 0.44f, CentellaCyan),
            Triple(0.43f, 0.28f, GoldPrimary),
            Triple(0.62f, 0.36f, GreenAction)
        )
        bars.forEach { (bx, topY, col) ->
            drawRoundRect(
                color = col,
                topLeft = Offset(w * bx, h * topY),
                size = Size(w * 0.14f, h * (0.74f - topY)),
                cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
            )
            drawRoundRect(
                color = OutlineDark,
                topLeft = Offset(w * bx, h * topY),
                size = Size(w * 0.14f, h * (0.74f - topY)),
                cornerRadius = CornerRadius(w * 0.04f, w * 0.04f),
                style = Stroke(width = stroke * 0.75f)
            )
        }
    }
}

/**
 * Chunky Brawl-style golden trophy cup icon.
 */
@Composable
fun TrophyArcadeIcon(modifier: Modifier = Modifier.size(22.dp)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val stroke = w * 0.07f

        // Handles
        drawCircle(color = GoldDeep, radius = w * 0.14f, center = Offset(w * 0.22f, h * 0.36f), style = Stroke(width = stroke * 1.2f))
        drawCircle(color = GoldDeep, radius = w * 0.14f, center = Offset(w * 0.78f, h * 0.36f), style = Stroke(width = stroke * 1.2f))

        // Cup bowl
        val cup = Path().apply {
            moveTo(w * 0.24f, h * 0.16f)
            lineTo(w * 0.76f, h * 0.16f)
            lineTo(w * 0.66f, h * 0.56f)
            lineTo(w * 0.34f, h * 0.56f)
            close()
        }
        drawPath(cup, brush = Brush.verticalGradient(listOf(Color(0xFFFEF08A), GoldPrimary, GoldDeep)))
        drawPath(cup, color = OutlineDark, style = Stroke(width = stroke, join = StrokeJoin.Round))

        // Stem + Base
        drawRect(color = GoldDeep, topLeft = Offset(w * 0.43f, h * 0.56f), size = Size(w * 0.14f, h * 0.18f))
        drawRoundRect(
            color = GoldPrimary,
            topLeft = Offset(w * 0.28f, h * 0.72f),
            size = Size(w * 0.44f, h * 0.16f),
            cornerRadius = CornerRadius(w * 0.05f, w * 0.05f)
        )
        drawRoundRect(
            color = OutlineDark,
            topLeft = Offset(w * 0.28f, h * 0.72f),
            size = Size(w * 0.44f, h * 0.16f),
            cornerRadius = CornerRadius(w * 0.05f, w * 0.05f),
            style = Stroke(width = stroke * 0.85f)
        )
    }
}

/**
 * Custom metallic Settings gear icon.
 */
@Composable
fun SettingsArcadeIcon(modifier: Modifier = Modifier.size(22.dp)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val c = Offset(w * 0.5f, h * 0.5f)
        val stroke = w * 0.07f

        for (i in 0 until 8) {
            val angleDeg = i * 45f
            rotate(angleDeg, pivot = c) {
                drawRoundRect(
                    color = Color(0xFF94A3B8),
                    topLeft = Offset(c.x - w * 0.09f, h * 0.08f),
                    size = Size(w * 0.18f, h * 0.16f),
                    cornerRadius = CornerRadius(w * 0.04f, w * 0.04f)
                )
                drawRoundRect(
                    color = OutlineDark,
                    topLeft = Offset(c.x - w * 0.09f, h * 0.08f),
                    size = Size(w * 0.18f, h * 0.16f),
                    cornerRadius = CornerRadius(w * 0.04f, w * 0.04f),
                    style = Stroke(width = stroke * 0.75f)
                )
            }
        }
        drawCircle(
            brush = Brush.radialGradient(listOf(Color(0xFFE2E8F0), Color(0xFF94A3B8), Color(0xFF475569))),
            radius = w * 0.30f,
            center = c
        )
        drawCircle(color = OutlineDark, radius = w * 0.30f, center = c, style = Stroke(width = stroke))
        drawCircle(color = Color(0xFF0E2144), radius = w * 0.12f, center = c)
        drawCircle(color = OutlineDark, radius = w * 0.12f, center = c, style = Stroke(width = stroke * 0.7f))
    }
}

/**
 * Custom Mode emblem (flaming crosshair / artillery shield).
 */
@Composable
fun ModeSurvivalArcadeIcon(modifier: Modifier = Modifier.size(26.dp)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val c = Offset(w * 0.5f, h * 0.5f)
        val stroke = w * 0.07f

        drawCircle(
            brush = Brush.radialGradient(listOf(Color(0xFFFDE047), Color(0xFFF97316), Color(0xFFDC2626))),
            radius = w * 0.42f,
            center = c
        )
        drawCircle(color = OutlineDark, radius = w * 0.42f, center = c, style = Stroke(width = stroke))
        drawCircle(color = Color(0xFF1E293B), radius = w * 0.22f, center = c, style = Stroke(width = stroke * 0.9f))
        drawLine(OutlineDark, Offset(w * 0.5f, h * 0.12f), Offset(w * 0.5f, h * 0.88f), strokeWidth = stroke * 0.85f)
        drawLine(OutlineDark, Offset(w * 0.12f, h * 0.5f), Offset(w * 0.88f, h * 0.5f), strokeWidth = stroke * 0.85f)
        drawCircle(Color(0xFFFEF08A), radius = w * 0.09f, center = c)
    }
}

/**
 * Multi-bomb artwork for Shop bomb packs (scales richness by pack tier 0..4).
 */
@Composable
fun BombBundleArt(tier: Int, modifier: Modifier = Modifier.size(42.dp)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        fun drawMiniBomb(cx: Float, cy: Float, r: Float, goldRim: Boolean = false) {
            drawLine(
                color = Color(0xFFD97706),
                start = Offset(cx + r * 0.45f, cy - r * 0.70f),
                end = Offset(cx + r * 0.95f, cy - r * 1.15f),
                strokeWidth = r * 0.25f,
                cap = StrokeCap.Round
            )
            drawCircle(color = Color(0xFFFDE047), radius = r * 0.26f, center = Offset(cx + r * 0.95f, cy - r * 1.15f))
            drawCircle(
                brush = Brush.radialGradient(
                    colors = if (goldRim) listOf(GoldPrimary, Color(0xFF334155), Color(0xFF0F172A))
                    else listOf(Color(0xFF64748B), Color(0xFF1E293B), Color(0xFF090D16)),
                    center = Offset(cx - r * 0.28f, cy - r * 0.28f),
                    radius = r * 1.4f
                ),
                radius = r,
                center = Offset(cx, cy)
            )
            drawCircle(
                color = if (goldRim) GoldPrimary else OutlineDark,
                radius = r,
                center = Offset(cx, cy),
                style = Stroke(width = r * 0.22f)
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.58f),
                radius = r * 0.24f,
                center = Offset(cx - r * 0.34f, cy - r * 0.34f)
            )
        }

        when (tier) {
            0 -> drawMiniBomb(w * 0.46f, h * 0.58f, w * 0.28f)
            1 -> {
                drawMiniBomb(w * 0.34f, h * 0.62f, w * 0.22f)
                drawMiniBomb(w * 0.64f, h * 0.52f, w * 0.24f)
            }
            2 -> {
                drawMiniBomb(w * 0.30f, h * 0.66f, w * 0.20f)
                drawMiniBomb(w * 0.68f, h * 0.66f, w * 0.20f)
                drawMiniBomb(w * 0.49f, h * 0.42f, w * 0.22f)
            }
            3 -> {
                drawRoundRect(
                    color = Color(0xFF1E3A8A),
                    topLeft = Offset(w * 0.14f, h * 0.50f),
                    size = Size(w * 0.72f, h * 0.40f),
                    cornerRadius = CornerRadius(w * 0.08f, w * 0.08f)
                )
                drawMiniBomb(w * 0.34f, h * 0.46f, w * 0.19f)
                drawMiniBomb(w * 0.64f, h * 0.46f, w * 0.19f)
                drawMiniBomb(w * 0.49f, h * 0.34f, w * 0.21f, goldRim = true)
            }
            else -> {
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(GoldPrimary, GoldDeep)),
                    topLeft = Offset(w * 0.12f, h * 0.52f),
                    size = Size(w * 0.76f, h * 0.38f),
                    cornerRadius = CornerRadius(w * 0.10f, w * 0.10f)
                )
                drawRoundRect(
                    color = OutlineDark,
                    topLeft = Offset(w * 0.12f, h * 0.52f),
                    size = Size(w * 0.76f, h * 0.38f),
                    cornerRadius = CornerRadius(w * 0.10f, w * 0.10f),
                    style = Stroke(width = w * 0.05f)
                )
                drawMiniBomb(w * 0.28f, h * 0.48f, w * 0.18f, goldRim = true)
                drawMiniBomb(w * 0.70f, h * 0.48f, w * 0.18f, goldRim = true)
                drawMiniBomb(w * 0.49f, h * 0.34f, w * 0.23f, goldRim = true)
            }
        }
    }
}

private fun DrawScope.drawStar(center: Offset, outerR: Float, innerR: Float, color: Color) {
    val path = Path()
    for (i in 0 until 10) {
        val r = if (i % 2 == 0) outerR else innerR
        val angle = (i * 36f - 90f) * (PI.toFloat() / 180f)
        val x = center.x + cos(angle) * r
        val y = center.y + sin(angle) * r
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    drawPath(path, color = color)
}
