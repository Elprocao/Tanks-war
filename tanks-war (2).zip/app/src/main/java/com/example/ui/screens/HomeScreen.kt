package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.GameCatalog
import com.example.model.BattleMode
import com.example.model.EconomyRules
import com.example.model.GameStateSnapshot
import com.example.model.MissionDefinition
import com.example.ui.components.ArcadeButton
import com.example.ui.components.CrateArcadeIcon
import com.example.ui.components.LimitsArcadeIcon
import com.example.ui.components.LobbyTopBar
import com.example.ui.components.MissionsArcadeIcon
import com.example.ui.components.ModeSurvivalArcadeIcon
import com.example.ui.components.ProbabilitiesArcadeIcon
import com.example.ui.components.RarityPill
import com.example.ui.components.ShopArcadeIcon
import com.example.ui.components.TankArcadeIcon
import com.example.ui.components.TankPortraitArt
import com.example.ui.components.WarPassArcadeIcon
import com.example.ui.theme.ArcadeBlueBright
import com.example.ui.theme.ArcadeBlueCard
import com.example.ui.theme.ArcadeNavyDeep
import com.example.ui.theme.CentellaCyan
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GreenAction
import com.example.ui.theme.OutlineDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

/**
 * Horizontal Brawl Stars-inspired Lobby Screen using structured non-overlapping Column/Row rows:
 * - Top Row: LobbyTopBar (profile + trophy progress + crate | 3 currencies + settings)
 * - Middle Row: Left Rail (TIENDA, TANQUES) | Center Tank Showcase | Right Rail (CAJA, RAREZAS %, LÍMITES)
 * - Bottom Row: Left (MISIONES + PASE DE GUERRA) | Center-Space (MODOS DE JUEGO) | Far-Right (short ¡JUGAR!)
 */
@Composable
fun HomeScreen(
    snapshot: GameStateSnapshot,
    shopBadgeCount: Int,
    missionsBadgeCount: Int,
    nextMission: MissionDefinition?,
    nextMissionProgress: Int,
    onStartBattle: () -> Unit,
    onOpenTanks: () -> Unit,
    onOpenShop: () -> Unit,
    onOpenMissions: () -> Unit,
    onOpenCrate: () -> Unit,
    onOpenProbabilities: () -> Unit,
    onOpenDailyLimits: () -> Unit,
    onOpenModes: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeTank = GameCatalog.tankById(snapshot.activeTankId)
    val level = snapshot.tankLevels[activeTank.id] ?: 1
    val hp = activeTank.hpAtLevel(level)
    val dmg = activeTank.damageAtLevel(level)
    val unlockedCount = snapshot.unlockedTankIds.size
    val totalTanksCount = GameCatalog.tanks.size
    val selectedMode = BattleMode.fromId(snapshot.selectedModeId)
    val passClaimed = snapshot.claimedPassTiers.size
    val totalPassTiers = GameCatalog.passMilestones.size

    Box(modifier = modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.img_garage_bg_1795212977989),
            contentDescription = "Garaje Tanks War",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF0E2A5C).copy(alpha = 0.25f),
                            Color(0xFF071124).copy(alpha = 0.80f)
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // 1. TOP BAR (own row so it can NEVER overlap left/right rail buttons)
            LobbyTopBar(
                snapshot = snapshot,
                onOpenTanks = onOpenTanks,
                onOpenCrate = onOpenCrate,
                onOpenSettings = onOpenSettings
            )

            // 2. MIDDLE SHOWCASE & SIDE RAILS
            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // LEFT RAIL: Tienda & Tanques
                Column(
                    modifier = Modifier.fillMaxHeight(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.Start
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        LobbySideTileButton(
                            label = "TIENDA",
                            badgeCount = shopBadgeCount,
                            onClick = onOpenShop,
                            testTag = "nav_shop",
                            iconContent = { ShopArcadeIcon(Modifier.size(26.dp)) }
                        )
                        LobbySideTileButton(
                            label = "TANQUES",
                            badgeText = "$unlockedCount/$totalTanksCount",
                            onClick = onOpenTanks,
                            testTag = "home_tanks_button",
                            iconContent = { TankArcadeIcon(Modifier.size(28.dp)) }
                        )
                    }
                }

                // CENTER: Responsive Active Tank Showcase + Stats + Name
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(horizontal = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Surface(
                        color = ArcadeNavyDeep.copy(alpha = 0.92f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(2.dp, OutlineDark),
                        shadowElevation = 5.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                color = GoldPrimary,
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(1.5.dp, OutlineDark)
                            ) {
                                Text(
                                    text = "NV. $level",
                                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 10.sp),
                                    color = OutlineDark,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Favorite, contentDescription = null, tint = GreenAction, modifier = Modifier.size(13.dp))
                                Spacer(Modifier.width(2.dp))
                                Text("$hp", style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp), color = TextWhite)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocalFireDepartment, contentDescription = null, tint = CrimsonDanger, modifier = Modifier.size(13.dp))
                                Spacer(Modifier.width(2.dp))
                                Text("$dmg", style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp), color = TextWhite)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Speed, contentDescription = null, tint = CentellaCyan, modifier = Modifier.size(13.dp))
                                Spacer(Modifier.width(2.dp))
                                Text("${activeTank.speedTilesPerSec} c/s", style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp), color = TextWhite)
                            }
                        }
                    }

                    Spacer(Modifier.height(4.dp))

                    Box(
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .sizeIn(minWidth = 88.dp, minHeight = 88.dp, maxWidth = 148.dp, maxHeight = 148.dp)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(20.dp))
                            .clickable(onClick = onOpenTanks)
                    ) {
                        TankPortraitArt(
                            tank = activeTank,
                            cornerRadius = 20.dp,
                            borderWidth = 3.dp,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(Modifier.height(4.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        RarityPill(rarity = activeTank.rarity)
                        Text(
                            text = activeTank.name.uppercase(),
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 15.sp),
                            color = TextWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // RIGHT RAIL: Caja 150g, Rarezas %, Límites
                Column(
                    modifier = Modifier.fillMaxHeight(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.End
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        LobbySideTileButton(
                            label = "CAJA ${EconomyRules.CRATE_COST_GEMAS}g",
                            onClick = onOpenCrate,
                            testTag = "home_crate_button",
                            iconContent = { CrateArcadeIcon(Modifier.size(24.dp)) }
                        )
                        LobbySideTileButton(
                            label = "RAREZAS %",
                            onClick = onOpenProbabilities,
                            testTag = "home_probabilities_button",
                            iconContent = { ProbabilitiesArcadeIcon(Modifier.size(24.dp)) }
                        )
                        LobbySideTileButton(
                            label = "LÍMITES",
                            badgeText = "${snapshot.dailyFcEarned}/100",
                            onClick = onOpenDailyLimits,
                            testTag = "home_limits_button",
                            iconContent = { LimitsArcadeIcon(Modifier.size(24.dp)) }
                        )
                    }
                }
            }

            // 3. BOTTOM DOCK BAR:
            // Left: MISIONES + PASE DE GUERRA | Middle Space: MODOS DE JUEGO | Far Right: Short ¡JUGAR!
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.Start
            ) {
                // BOTTOM-LEFT: Misiones card (primary quest entry) + Pase de Guerra ticket
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(modifier = Modifier.testTag("nav_missions")) {
                        Surface(
                            modifier = Modifier
                                .width(154.dp)
                                .height(56.dp)
                                .clip(RoundedCornerShape(13.dp))
                                .clickable(onClick = onOpenMissions),
                            shape = RoundedCornerShape(13.dp),
                            color = ArcadeBlueCard.copy(alpha = 0.95f),
                            border = BorderStroke(2.5.dp, if (missionsBadgeCount > 0) GoldPrimary else OutlineDark),
                            shadowElevation = 7.dp
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(7.dp)
                            ) {
                                MissionsArcadeIcon(Modifier.size(26.dp))
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Text(
                                        text = "MISIONES",
                                        style = MaterialTheme.typography.titleSmall.copy(fontSize = 12.sp, fontWeight = FontWeight.ExtraBold),
                                        color = TextWhite,
                                        maxLines = 1
                                    )
                                    val target = (nextMission?.target ?: 1).coerceAtLeast(1)
                                    val curProg = nextMissionProgress.coerceAtMost(target)
                                    LinearProgressIndicator(
                                        progress = { (curProg.toFloat() / target).coerceIn(0f, 1f) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .border(1.dp, OutlineDark, RoundedCornerShape(3.dp)),
                                        color = GreenAction,
                                        trackColor = ArcadeNavyDeep
                                    )
                                    Text(
                                        text = if (missionsBadgeCount > 0) "$missionsBadgeCount listas para cobrar"
                                        else nextMission?.title ?: "Todas listas",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                        color = if (missionsBadgeCount > 0) GoldPrimary else TextMuted,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }

                        if (missionsBadgeCount > 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .size(18.dp)
                                    .clip(CircleShape)
                                    .background(CrimsonDanger)
                                    .border(1.5.dp, OutlineDark, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = missionsBadgeCount.toString(),
                                    color = TextWhite,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }

                    // Compact Gold Pase de Guerra ticket
                    Surface(
                        modifier = Modifier
                            .width(92.dp)
                            .height(56.dp)
                            .clip(RoundedCornerShape(13.dp))
                            .clickable(onClick = onOpenMissions)
                            .testTag("home_pass_banner"),
                        shape = RoundedCornerShape(13.dp),
                        color = GoldPrimary,
                        border = BorderStroke(2.5.dp, OutlineDark),
                        shadowElevation = 7.dp
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 6.dp, vertical = 5.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                WarPassArcadeIcon(Modifier.size(18.dp))
                                Text(
                                    text = "PASE",
                                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp, fontWeight = FontWeight.ExtraBold),
                                    color = OutlineDark
                                )
                            }
                            Text(
                                text = if (snapshot.hasBattlePass) "$passClaimed/$totalPassTiers hitos"
                                else "${EconomyRules.BATTLE_PASS_COST_GEMS} g",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp, fontWeight = FontWeight.Bold),
                                color = OutlineDark,
                                maxLines = 1
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                // BOTTOM-CENTER: MODOS DE JUEGO selector (sits in the middle space!)
                Surface(
                    modifier = Modifier
                        .widthIn(min = 176.dp, max = 214.dp)
                        .height(56.dp)
                        .clip(RoundedCornerShape(13.dp))
                        .clickable(onClick = onOpenModes)
                        .testTag("home_modes_button"),
                    shape = RoundedCornerShape(13.dp),
                    color = Color(0xFF10254D).copy(alpha = 0.96f),
                    border = BorderStroke(2.5.dp, CentellaCyan.copy(alpha = 0.85f)),
                    shadowElevation = 8.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 9.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ModeSurvivalArcadeIcon(Modifier.size(28.dp))
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(1.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "MODOS DE JUEGO",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.5.sp, fontWeight = FontWeight.Bold),
                                    color = CentellaCyan,
                                    maxLines = 1
                                )
                                Surface(
                                    color = GoldPrimary,
                                    shape = RoundedCornerShape(4.dp),
                                    border = BorderStroke(1.dp, OutlineDark)
                                ) {
                                    Text(
                                        text = selectedMode.badge,
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, fontWeight = FontWeight.ExtraBold),
                                        color = OutlineDark,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Text(
                                text = selectedMode.title,
                                style = MaterialTheme.typography.titleSmall.copy(fontSize = 12.sp, fontWeight = FontWeight.ExtraBold),
                                color = TextWhite,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = selectedMode.subtitle,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.5.sp),
                                color = GreenAction,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.weight(0.65f))

                // BOTTOM-RIGHT: Compact, short golden ¡JUGAR! button flush right
                ArcadeButton(
                    onClick = onStartBattle,
                    topColor = GoldPrimary,
                    bottomColor = GoldDeep,
                    contentColor = OutlineDark,
                    cornerRadius = 14.dp,
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                    modifier = Modifier
                        .width(128.dp)
                        .height(56.dp),
                    testTag = "home_battle_button"
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(3.dp))
                    Text(
                        text = "¡JUGAR!",
                        style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun LobbySideTileButton(
    label: String,
    onClick: () -> Unit,
    testTag: String,
    badgeCount: Int = 0,
    badgeText: String? = null,
    iconContent: @Composable () -> Unit
) {
    Box(modifier = Modifier.testTag(testTag)) {
        Surface(
            modifier = Modifier
                .width(84.dp)
                .clip(RoundedCornerShape(12.dp))
                .clickable(onClick = onClick),
            shape = RoundedCornerShape(12.dp),
            color = ArcadeBlueCard.copy(alpha = 0.94f),
            border = BorderStroke(2.dp, OutlineDark),
            shadowElevation = 6.dp
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                iconContent()
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp, fontWeight = FontWeight.ExtraBold),
                    color = TextWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        if (badgeCount > 0) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(CrimsonDanger)
                    .border(1.5.dp, OutlineDark, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = badgeCount.toString(),
                    color = TextWhite,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        } else if (badgeText != null) {
            Surface(
                color = ArcadeBlueBright,
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(1.dp, OutlineDark),
                modifier = Modifier.align(Alignment.TopEnd)
            ) {
                Text(
                    text = badgeText,
                    color = TextWhite,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                )
            }
        }
    }
}

@Composable
fun DailyLimitProgressRow(
    title: String,
    current: Int,
    max: Int,
    unit: String,
    barColor: Color,
    icon: @Composable () -> Unit
) {
    val progress = (current.toFloat() / max.coerceAtLeast(1)).coerceIn(0f, 1f)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                icon()
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = title, style = MaterialTheme.typography.bodyMedium, color = TextWhite)
            }
            Text(
                text = "$current / $max $unit",
                style = MaterialTheme.typography.labelLarge.copy(fontSize = 13.sp),
                color = if (current >= max) GoldPrimary else barColor
            )
        }
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(9.dp)
                .clip(RoundedCornerShape(5.dp))
                .border(1.5.dp, OutlineDark, RoundedCornerShape(5.dp)),
            color = barColor,
            trackColor = ArcadeNavyDeep
        )
    }
}
