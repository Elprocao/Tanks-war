package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.legal.LegalConfig
import com.example.legal.openExternalLegalUrl
import com.example.legal.openSupportEmail
import com.example.ui.components.ArcadeButton
import com.example.ui.theme.ArcadeBlueBright
import com.example.ui.theme.ArcadeBlueCard
import com.example.ui.theme.ArcadeBluePanel
import com.example.ui.theme.ArcadeNavyDeep
import com.example.ui.theme.CentellaCyan
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GreenAction
import com.example.ui.theme.GreenActionDeep
import com.example.ui.theme.OutlineDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun LegalConsentScreen(
    onAccepted: () -> Unit,
    onDeclineExit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var acceptedPrivacyAndTerms by rememberSaveable { mutableStateOf(false) }
    var acceptedDataAndAds by rememberSaveable { mutableStateOf(false) }
    var acceptedDeletionPolicy by rememberSaveable { mutableStateOf(false) }

    val allAccepted = acceptedPrivacyAndTerms && acceptedDataAndAds && acceptedDeletionPolicy

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF030712),
                        ArcadeNavyDeep,
                        Color(0xFF09142B)
                    )
                )
            )
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .windowInsetsPadding(WindowInsets.displayCutout)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 860.dp),
            shape = RoundedCornerShape(22.dp),
            color = ArcadeBluePanel.copy(alpha = 0.97f),
            border = BorderStroke(3.dp, GoldPrimary),
            shadowElevation = 16.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left column: Legal Documents & Support
                Column(
                    modifier = Modifier.weight(0.47f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Gavel,
                            contentDescription = "Documentos Legales",
                            tint = GoldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "TANKS WAR - UTILITY APPS",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                            color = GoldPrimary
                        )
                    }

                    Text(
                        text = "Antes de entrar al juego (incluso antes de la animación inicial), revisa y acepta los documentos legales y condiciones de servicio:",
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                        color = TextWhite
                    )

                    LegalDocumentLinkCard(
                        title = "Política de Privacidad",
                        subtitle = "Uso de cuenta Google, Firebase y AdMob",
                        icon = Icons.Default.PrivacyTip,
                        accentColor = CentellaCyan,
                        testTag = "open_privacy_policy_button",
                        onClick = { openExternalLegalUrl(context, LegalConfig.PRIVACY_POLICY_URL) }
                    )

                    LegalDocumentLinkCard(
                        title = "Términos y Condiciones (ToS)",
                        subtitle = "Reglas de uso, multijugador y economía",
                        icon = Icons.Default.Description,
                        accentColor = GoldPrimary,
                        testTag = "open_tos_button",
                        onClick = { openExternalLegalUrl(context, LegalConfig.TERMS_OF_SERVICE_URL) }
                    )

                    LegalDocumentLinkCard(
                        title = "Eliminación de Cuenta y Datos",
                        subtitle = "Cómo solicitar el borrado completo",
                        icon = Icons.Default.DeleteOutline,
                        accentColor = ArcadeBlueBright,
                        testTag = "open_data_deletion_button",
                        onClick = { openExternalLegalUrl(context, LegalConfig.DATA_DELETION_URL) }
                    )

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { openSupportEmail(context) }
                            .minimumInteractiveComponentSize()
                            .testTag("support_email_button"),
                        shape = RoundedCornerShape(10.dp),
                        color = ArcadeNavyDeep,
                        border = BorderStroke(1.dp, Color(0xFF335599))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Email,
                                contentDescription = "Correo de soporte",
                                tint = CentellaCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Contacto: ${LegalConfig.SUPPORT_EMAIL}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }
                    }
                }

                // Right column: Mandatory Checkboxes & Accept / Exit actions
                Column(
                    modifier = Modifier.weight(0.53f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = CentellaCyan,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.5.dp, OutlineDark)
                    ) {
                        Text(
                            text = "ACEPTACIÓN OBLIGATORIA PARA ACCEDER",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                            color = OutlineDark,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    ConsentCheckboxRow(
                        checked = acceptedPrivacyAndTerms,
                        onCheckedChange = { acceptedPrivacyAndTerms = it },
                        text = "He leído y acepto la Política de Privacidad y los Términos y Condiciones de Uso (ToS) de Utility Apps.",
                        testTag = "checkbox_privacy_tos"
                    )

                    ConsentCheckboxRow(
                        checked = acceptedDataAndAds,
                        onCheckedChange = { acceptedDataAndAds = it },
                        text = "Acepto la autenticación con Google, el guardado en la nube y juego online 1v1 en Firebase, así como los anuncios recompensados opcionales de Google AdMob.",
                        testTag = "checkbox_data_ads"
                    )

                    ConsentCheckboxRow(
                        checked = acceptedDeletionPolicy,
                        onCheckedChange = { acceptedDeletionPolicy = it },
                        text = "Confirmo que conozco la Política de Eliminación de Datos y el canal oficial ${LegalConfig.SUPPORT_EMAIL}.",
                        testTag = "checkbox_deletion_policy"
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ArcadeButton(
                            onClick = {
                                acceptedPrivacyAndTerms = true
                                acceptedDataAndAds = true
                                acceptedDeletionPolicy = true
                            },
                            topColor = ArcadeBlueBright,
                            bottomColor = Color(0xFF1E40AF),
                            contentColor = TextWhite,
                            modifier = Modifier.weight(0.42f),
                            testTag = "select_all_legal_button"
                        ) {
                            Text(
                                text = "MARCAR TODO",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold)
                            )
                        }

                        ArcadeButton(
                            onClick = onDeclineExit,
                            topColor = CrimsonDanger,
                            bottomColor = Color(0xFF991B1B),
                            contentColor = TextWhite,
                            modifier = Modifier.weight(0.28f),
                            testTag = "decline_legal_exit_button"
                        ) {
                            Text(
                                text = "SALIR",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold)
                            )
                        }
                    }

                    ArcadeButton(
                        onClick = onAccepted,
                        enabled = allAccepted,
                        topColor = GreenAction,
                        bottomColor = GreenActionDeep,
                        contentColor = TextWhite,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "accept_legal_continue_button"
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = if (allAccepted) "ACEPTAR TODO Y ENTRAR" else "MARCA TODAS LAS CASILLAS PARA ENTRAR",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.ExtraBold)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LegalDocumentLinkCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .minimumInteractiveComponentSize()
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        color = ArcadeBlueCard,
        border = BorderStroke(1.5.dp, accentColor.copy(alpha = 0.8f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = accentColor,
                modifier = Modifier.size(22.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = TextWhite
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                    color = TextMuted
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                contentDescription = "Abrir $title",
                tint = accentColor,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun ConsentCheckboxRow(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    text: String,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onCheckedChange(!checked) }
            .minimumInteractiveComponentSize()
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        color = if (checked) ArcadeBlueCard else ArcadeNavyDeep,
        border = BorderStroke(1.5.dp, if (checked) GreenAction else Color(0xFF335599))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Checkbox(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = CheckboxDefaults.colors(
                    checkedColor = GreenAction,
                    uncheckedColor = TextMuted,
                    checkmarkColor = TextWhite
                )
            )
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp, lineHeight = 16.sp),
                color = TextWhite,
                modifier = Modifier.weight(1f)
            )
        }
    }
}
