package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.GameCatalog
import com.example.model.EconomyRules
import com.example.model.GameStateSnapshot
import com.example.model.MissionDefinition
import com.example.ui.components.ArcadeButton
import com.example.ui.components.BrawlSectionRibbon
import com.example.ui.components.CentellaCoinIcon
import com.example.ui.components.GemIcon
import com.example.ui.components.TrophyArcadeIcon
import com.example.ui.components.WarPassArcadeIcon
import com.example.ui.theme.ArcadeBlueCard
import com.example.ui.theme.ArcadeBluePanel
import com.example.ui.theme.ArcadeNavy
import com.example.ui.theme.ArcadeNavyDeep
import com.example.ui.theme.CentellaCyan
import com.example.ui.theme.GemGreen
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GreenAction
import com.example.ui.theme.GreenActionDeep
import com.example.ui.theme.OutlineDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun MissionsScreen(
    snapshot: GameStateSnapshot,
    progressProvider: (MissionDefinition) -> Int,
    onClaimMission: (MissionDefinition) -> Unit,
    onUnlockBattlePass: () -> Unit,
    onClaimPassTier: (GameCatalog.PassTierReward) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.img_tank_shop_bg_1795213539157),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(ArcadeNavyDeep.copy(alpha = 0.84f))
        )

        // Landscape Two-Pane Split: Left Battle Pass (43%) | Right Missions (57%)
        Row(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .windowInsetsPadding(WindowInsets.displayCutout)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // LEFT PANE: Battle Pass (1500 g)
            Surface(
                modifier = Modifier
                    .weight(0.43f)
                    .fillMaxHeight(),
                shape = RoundedCornerShape(18.dp),
                color = ArcadeBluePanel.copy(alpha = 0.96f),
                border = BorderStroke(2.5.dp, GoldPrimary),
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            WarPassArcadeIcon(Modifier.size(30.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = "PASE DE GUERRA",
                                    style = MaterialTheme.typography.titleLarge.copy(fontSize = 16.sp),
                                    color = GoldPrimary
                                )
                                Text(
                                    text = if (snapshot.hasBattlePass) "+20% Bombas y Gemas activo"
                                    else "Hitos y +20% botín por ${EconomyRules.BATTLE_PASS_COST_GEMS} g",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                                    color = TextWhite
                                )
                            }
                        }

                        if (snapshot.hasBattlePass) {
                            Surface(
                                color = GreenActionDeep,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.5.dp, OutlineDark)
                            ) {
                                Text(
                                    text = "ACTIVO",
                                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                                    color = TextWhite,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        } else {
                            ArcadeButton(
                                onClick = onUnlockBattlePass,
                                enabled = snapshot.gemas >= EconomyRules.BATTLE_PASS_COST_GEMS,
                                topColor = GoldPrimary,
                                bottomColor = GoldDeep,
                                contentColor = OutlineDark,
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                testTag = "unlock_pass_button"
                            ) {
                                GemIcon(Modifier.size(14.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("${EconomyRules.BATTLE_PASS_COST_GEMS} g", style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp))
                            }
                        }
                    }

                    GameCatalog.passMilestones.forEach { tier ->
                        val claimed = tier.tier in snapshot.claimedPassTiers
                        val ready = snapshot.hasBattlePass && snapshot.totalWins >= tier.winsRequired && !claimed
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = ArcadeNavy,
                            border = BorderStroke(1.5.dp, if (ready) GoldPrimary else OutlineDark)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Hito ${tier.tier} - ${tier.winsRequired} Vic. (${snapshot.totalWins}/${tier.winsRequired})",
                                        style = MaterialTheme.typography.titleMedium.copy(fontSize = 12.sp),
                                        color = TextWhite
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("+${tier.bombs} b", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                        Text("+${tier.gems} g", style = MaterialTheme.typography.labelSmall, color = GemGreen)
                                        Text("+${tier.fc} fc", style = MaterialTheme.typography.labelSmall, color = CentellaCyan)
                                    }
                                }
                                ArcadeButton(
                                    onClick = { onClaimPassTier(tier) },
                                    enabled = ready,
                                    topColor = if (claimed) Color(0xFF334155) else GreenAction,
                                    bottomColor = if (claimed) Color(0xFF1E293B) else GreenActionDeep,
                                    contentColor = TextWhite,
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp)
                                ) {
                                    Text(
                                        text = when {
                                            claimed -> "LISTO"
                                            ready -> "RECLAMAR"
                                            else -> "BLOQ."
                                        },
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // RIGHT PANE: Combat Missions
            Column(
                modifier = Modifier
                    .weight(0.57f)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TrophyArcadeIcon(Modifier.size(24.dp))
                    BrawlSectionRibbon(
                        title = "MISIONES DE COMBATE (200-2000 g | 1-5 fc)",
                        accentColor = Color(0xFFD97706)
                    )
                }

                GameCatalog.missions.forEach { mission ->
                    val progress = progressProvider(mission).coerceAtMost(mission.target)
                    val claimed = mission.id in snapshot.claimedMissionIds
                    val completed = progress >= mission.target
                    val pct = (progress.toFloat() / mission.target.coerceAtLeast(1)).coerceIn(0f, 1f)

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = ArcadeBlueCard.copy(alpha = 0.96f),
                        border = BorderStroke(2.dp, if (completed && !claimed) GoldPrimary else OutlineDark)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = mission.title,
                                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp),
                                    color = TextWhite,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = mission.description,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                                    color = TextMuted,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                LinearProgressIndicator(
                                    progress = { pct },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .border(1.dp, OutlineDark, RoundedCornerShape(4.dp)),
                                    color = if (completed) GreenAction else GoldPrimary,
                                    trackColor = ArcadeNavyDeep
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = "$progress / ${mission.target}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextWhite
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        GemIcon(Modifier.size(13.dp))
                                        Spacer(Modifier.width(3.dp))
                                        Text("+${mission.rewardGems} g", style = MaterialTheme.typography.labelSmall, color = GemGreen)
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        CentellaCoinIcon(Modifier.size(13.dp))
                                        Spacer(Modifier.width(3.dp))
                                        Text("+${mission.rewardFc} fc", style = MaterialTheme.typography.labelSmall, color = CentellaCyan)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            if (claimed) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 6.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = "Reclamada", tint = GreenAction)
                                    Spacer(Modifier.width(4.dp))
                                    Text("HECHO", style = MaterialTheme.typography.labelSmall, color = GreenAction)
                                }
                            } else {
                                ArcadeButton(
                                    onClick = { onClaimMission(mission) },
                                    enabled = completed,
                                    topColor = GreenAction,
                                    bottomColor = GreenActionDeep,
                                    contentColor = TextWhite,
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                    testTag = "claim_mission_${mission.id}"
                                ) {
                                    Text(
                                        text = if (completed) "RECLAMAR" else "EN CURSO",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
