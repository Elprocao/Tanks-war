package com.example.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.TankDefinition
import com.example.model.TankHullStyle
import com.example.model.TankRarity
import com.example.ui.theme.CentellaCyan
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.OutlineDark
import kotlin.math.PI

@DrawableRes
fun tankDrawableRes(tank: TankDefinition): Int {
    return when (tank.rarity) {
        TankRarity.ESTANDAR -> R.drawable.img_tank_estandar_1795212996649
        TankRarity.ESPECIAL -> R.drawable.img_tank_especial_1795212979194
        TankRarity.EPICA -> R.drawable.img_tank_epico_1795212998016
        TankRarity.MITICA -> R.drawable.img_tank_mitico_1795212999591
        TankRarity.LEGENDARIA -> R.drawable.img_tank_legendario_1795212999374
        TankRarity.CENTELLA -> R.drawable.img_tank_centella_1795212999436
    }
}

fun tankBackdropColor(rarity: TankRarity): Color {
    return when (rarity) {
        TankRarity.ESTANDAR -> Color(0xFF1E293B)
        TankRarity.ESPECIAL -> Color(0xFF132B54)
        TankRarity.EPICA -> Color(0xFF2D144E)
        TankRarity.MITICA -> Color(0xFF4C0B22)
        TankRarity.LEGENDARIA -> Color(0xFF452406)
        TankRarity.CENTELLA -> Color(0xFF083344)
    }
}

@Composable
fun TankPortraitArt(
    tank: TankDefinition,
    modifier: Modifier = Modifier,
    facingRight: Boolean = true,
    cornerRadius: Dp = 14.dp,
    borderWidth: Dp = 2.5.dp,
    showRarityGlow: Boolean = true
) {
    val bgColor = tankBackdropColor(tank.rarity)
    val shape = RoundedCornerShape(cornerRadius)
    Surface(
        modifier = modifier,
        shape = shape,
        color = bgColor,
        border = BorderStroke(borderWidth, OutlineDark),
        shadowElevation = 6.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            tank.rarity.accentColor.copy(alpha = if (showRarityGlow) 0.35f else 0.12f),
                            bgColor
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = tankDrawableRes(tank)),
                contentDescription = tank.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(shape)
                    .graphicsLayer {
                        scaleX = if (facingRight) 1f else -1f
                    }
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(2.dp)
                    .border(1.5.dp, tank.rarity.accentColor.copy(alpha = 0.7f), RoundedCornerShape(cornerRadius - 2.dp))
            )
        }
    }
}

/**
 * 3D-extruded top-down cartoon tank renderer with independent chassis and turret rotation,
 * bevel depth shading, tread cleats, hatch, and muzzle recoil.
 * Angle 0 rad points Right (+X).
 */
fun DrawScope.drawTopDown3DTank(
    tank: TankDefinition,
    centerX: Float,
    centerY: Float,
    tileSize: Float,
    chassisAngleRad: Float,
    turretAngleRad: Float,
    recoilTiles: Float,
    isPlayer: Boolean,
    hasShield: Boolean,
    isTurbo: Boolean,
    isOvercharged: Boolean,
    isStunned: Boolean
) {
    val primary = Color(tank.primaryColorHex)
    val secondary = Color(tank.secondaryColorHex)
    val darker = Color(
        red = (primary.red * 0.62f).coerceIn(0f, 1f),
        green = (primary.green * 0.62f).coerceIn(0f, 1f),
        blue = (primary.blue * 0.62f).coerceIn(0f, 1f),
        alpha = 1f
    )
    val bodyLen = tileSize * 1.65f
    val bodyWid = tileSize * 1.32f
    val chassisDeg = (chassisAngleRad * 180f / PI.toFloat())
    val turretDeg = (turretAngleRad * 180f / PI.toFloat())

    // Team ring indicator beneath tank for instant top-down readability
    val ringColor = if (isPlayer) Color(0xFF38BDF8) else Color(0xFFEF4444)
    drawCircle(
        color = ringColor.copy(alpha = 0.25f),
        radius = tileSize * 0.96f,
        center = Offset(centerX, centerY)
    )
    drawCircle(
        color = ringColor.copy(alpha = 0.85f),
        radius = tileSize * 0.96f,
        center = Offset(centerX, centerY),
        style = Stroke(width = 2.5f)
    )

    // Elevated 3D ground drop shadow (sunlit from top-left)
    drawCircle(
        color = Color.Black.copy(alpha = 0.36f),
        radius = tileSize * 0.86f,
        center = Offset(centerX + tileSize * 0.14f, centerY + tileSize * 0.18f)
    )

    if (isTurbo) {
        drawCircle(
            color = Color(0xFFE879F9).copy(alpha = 0.42f),
            radius = tileSize * 1.12f,
            center = Offset(centerX, centerY)
        )
    }
    if (isOvercharged) {
        drawCircle(
            color = GoldPrimary.copy(alpha = 0.36f),
            radius = tileSize * 1.06f,
            center = Offset(centerX, centerY),
            style = Stroke(width = 3f)
        )
    }

    // 1. CHASSIS & 3D TREADS (rotated to chassisAngleRad)
    rotate(degrees = chassisDeg, pivot = Offset(centerX, centerY)) {
        val treadThickness = bodyWid * 0.24f
        val treadLen = bodyLen * 1.04f

        // Left & Right 3D treads
        listOf(-bodyWid * 0.50f, bodyWid * 0.50f - treadThickness).forEach { ty ->
            // Lower 3D side extrusion
            drawRoundRect(
                color = Color(0xFF0F172A),
                topLeft = Offset(centerX - treadLen / 2f + 2f, centerY + ty + 3f),
                size = Size(treadLen, treadThickness),
                cornerRadius = CornerRadius(5f, 5f)
            )
            // Upper tread face
            drawRoundRect(
                color = Color(0xFF334155),
                topLeft = Offset(centerX - treadLen / 2f, centerY + ty),
                size = Size(treadLen, treadThickness),
                cornerRadius = CornerRadius(5f, 5f)
            )
            // Tread cleats
            val cleats = 5
            for (i in 0 until cleats) {
                val cx = centerX - treadLen * 0.40f + i * (treadLen * 0.20f)
                drawLine(
                    color = Color(0xFF64748B),
                    start = Offset(cx, centerY + ty + 2f),
                    end = Offset(cx, centerY + ty + treadThickness - 2f),
                    strokeWidth = 2f
                )
            }
            drawRoundRect(
                color = OutlineDark,
                topLeft = Offset(centerX - treadLen / 2f, centerY + ty),
                size = Size(treadLen, treadThickness),
                cornerRadius = CornerRadius(5f, 5f),
                style = Stroke(width = 2.2f)
            )
        }

        // Hull 3D base extrusion (gives top-down 3D block thickness)
        val hullW = bodyLen * 0.88f
        val hullH = bodyWid * 0.72f
        drawRoundRect(
            color = darker,
            topLeft = Offset(centerX - hullW / 2f + 2f, centerY - hullH / 2f + 4f),
            size = Size(hullW, hullH),
            cornerRadius = CornerRadius(7f, 7f)
        )
        // Hull upper armored deck
        drawRoundRect(
            brush = Brush.linearGradient(
                colors = listOf(secondary, primary),
                start = Offset(centerX - hullW / 2f, centerY - hullH / 2f),
                end = Offset(centerX + hullW / 2f, centerY + hullH / 2f)
            ),
            topLeft = Offset(centerX - hullW / 2f, centerY - hullH / 2f),
            size = Size(hullW, hullH),
            cornerRadius = CornerRadius(7f, 7f)
        )
        // Rear engine louver vents
        drawRoundRect(
            color = darker,
            topLeft = Offset(centerX - hullW * 0.42f, centerY - hullH * 0.34f),
            size = Size(hullW * 0.20f, hullH * 0.68f),
            cornerRadius = CornerRadius(3f, 3f)
        )
        // Front glacis plate bevel
        drawRoundRect(
            color = Color.White.copy(alpha = 0.22f),
            topLeft = Offset(centerX + hullW * 0.26f, centerY - hullH * 0.36f),
            size = Size(hullW * 0.16f, hullH * 0.72f),
            cornerRadius = CornerRadius(3f, 3f)
        )
        drawRoundRect(
            color = OutlineDark,
            topLeft = Offset(centerX - hullW / 2f, centerY - hullH / 2f),
            size = Size(hullW, hullH),
            cornerRadius = CornerRadius(7f, 7f),
            style = Stroke(width = 2.5f)
        )
    }

    // 2. ELEVATED 3D TURRET & CANNON (rotated to turretAngleRad)
    rotate(degrees = turretDeg, pivot = Offset(centerX, centerY)) {
        val recoilPx = recoilTiles * tileSize
        val barrelLen = tileSize * 0.96f
        val barrelWid = if (tank.hullStyle == TankHullStyle.HEAVY_KV2) tileSize * 0.30f else tileSize * 0.22f
        val barrelStartX = centerX + tileSize * 0.12f - recoilPx

        if (tank.hullStyle == TankHullStyle.CENTAURO_DUAL) {
            listOf(-barrelWid * 0.75f, barrelWid * 0.15f).forEach { by ->
                drawRoundRect(
                    color = Color(0xFF475569),
                    topLeft = Offset(barrelStartX, centerY + by),
                    size = Size(barrelLen, barrelWid * 0.65f),
                    cornerRadius = CornerRadius(3f, 3f)
                )
                drawRoundRect(
                    color = OutlineDark,
                    topLeft = Offset(barrelStartX, centerY + by),
                    size = Size(barrelLen, barrelWid * 0.65f),
                    cornerRadius = CornerRadius(3f, 3f),
                    style = Stroke(width = 2f)
                )
            }
        } else {
            // Barrel drop shadow
            drawRoundRect(
                color = Color.Black.copy(alpha = 0.35f),
                topLeft = Offset(barrelStartX + 2f, centerY - barrelWid / 2f + 3f),
                size = Size(barrelLen, barrelWid),
                cornerRadius = CornerRadius(4f, 4f)
            )
            // Cylindrical 3D barrel gradient
            drawRoundRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF94A3B8), Color(0xFF475569), Color(0xFF1E293B)),
                    startY = centerY - barrelWid / 2f,
                    endY = centerY + barrelWid / 2f
                ),
                topLeft = Offset(barrelStartX, centerY - barrelWid / 2f),
                size = Size(barrelLen, barrelWid),
                cornerRadius = CornerRadius(4f, 4f)
            )
            // Muzzle brake tip
            drawRoundRect(
                color = if (tank.rarity == TankRarity.CENTELLA) CentellaCyan else Color(0xFF1E293B),
                topLeft = Offset(barrelStartX + barrelLen - tileSize * 0.16f, centerY - barrelWid * 0.65f),
                size = Size(tileSize * 0.18f, barrelWid * 1.3f),
                cornerRadius = CornerRadius(3f, 3f)
            )
            drawRoundRect(
                color = OutlineDark,
                topLeft = Offset(barrelStartX, centerY - barrelWid / 2f),
                size = Size(barrelLen, barrelWid),
                cornerRadius = CornerRadius(4f, 4f),
                style = Stroke(width = 2.2f)
            )
        }

        // Turret 3D dome shadow & body
        val turretR = tileSize * 0.46f
        drawCircle(
            color = darker,
            radius = turretR,
            center = Offset(centerX + 2f, centerY + 3.5f)
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.35f), secondary, primary),
                center = Offset(centerX - turretR * 0.25f, centerY - turretR * 0.25f),
                radius = turretR * 1.4f
            ),
            radius = turretR,
            center = Offset(centerX, centerY)
        )
        drawCircle(
            color = OutlineDark,
            radius = turretR,
            center = Offset(centerX, centerY),
            style = Stroke(width = 2.5f)
        )
        // Commander cupola hatch
        drawCircle(
            color = secondary,
            radius = turretR * 0.42f,
            center = Offset(centerX - turretR * 0.20f, centerY)
        )
        drawCircle(
            color = OutlineDark,
            radius = turretR * 0.42f,
            center = Offset(centerX - turretR * 0.20f, centerY),
            style = Stroke(width = 1.8f)
        )
    }

    // Shield bubble
    if (hasShield) {
        drawCircle(
            color = Color(0xFF38BDF8).copy(alpha = 0.26f),
            radius = tileSize * 1.15f,
            center = Offset(centerX, centerY)
        )
        drawCircle(
            color = Color(0xFF38BDF8),
            radius = tileSize * 1.15f,
            center = Offset(centerX, centerY),
            style = Stroke(width = 3f)
        )
    }

    // Stun indicator
    if (isStunned) {
        val bolt = Path().apply {
            moveTo(centerX + 4f, centerY - tileSize * 0.9f)
            lineTo(centerX - 6f, centerY - tileSize * 0.45f)
            lineTo(centerX + 2f, centerY - tileSize * 0.45f)
            lineTo(centerX - 4f, centerY - tileSize * 0.05f)
        }
        drawPath(path = bolt, color = CentellaCyan, style = Stroke(width = 3.2f))
    }
}
