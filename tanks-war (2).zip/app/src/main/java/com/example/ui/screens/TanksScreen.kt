package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.GameCatalog
import com.example.model.EconomyRules
import com.example.model.GameStateSnapshot
import com.example.model.TankDefinition
import com.example.model.TankRarity
import com.example.ui.components.ArcadeButton
import com.example.ui.components.BombIcon
import com.example.ui.components.BrawlSectionRibbon
import com.example.ui.components.CrateArcadeIcon
import com.example.ui.components.ProbabilitiesArcadeIcon
import com.example.ui.components.RarityPill
import com.example.ui.components.TankPortraitArt
import com.example.ui.theme.ArcadeBlueBright
import com.example.ui.theme.ArcadeBlueCard
import com.example.ui.theme.ArcadeBluePanel
import com.example.ui.theme.ArcadeNavy
import com.example.ui.theme.ArcadeNavyDeep
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GreenAction
import com.example.ui.theme.GreenActionDeep
import com.example.ui.theme.OutlineDark
import com.example.ui.theme.TextWhite

@Composable
fun TanksScreen(
    snapshot: GameStateSnapshot,
    selectedTankId: String,
    onSelectTank: (String) -> Unit,
    onEquipTank: (String) -> Unit,
    onUnlockTank: (TankDefinition) -> Unit,
    onUpgradeTank: (TankDefinition) -> Unit,
    onOpenCrate: () -> Unit,
    onOpenProbabilities: () -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedTank = GameCatalog.tankById(selectedTankId)
    val isUnlocked = selectedTank.id in snapshot.unlockedTankIds
    val isActive = selectedTank.id == snapshot.activeTankId
    val level = snapshot.tankLevels[selectedTank.id] ?: 1
    val upgradeCost = EconomyRules.upgradeCostBombas(level)

    val orderedRarities = listOf(
        TankRarity.ESPECIAL,
        TankRarity.EPICA,
        TankRarity.MITICA,
        TankRarity.LEGENDARIA,
        TankRarity.CENTELLA,
        TankRarity.ESTANDAR
    )

    Box(modifier = modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.img_garage_bg_1795212977989),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(ArcadeNavyDeep.copy(alpha = 0.82f))
        )

        // Landscape Two-Pane Split: Left Spotlight (38%) | Right Scrollable Tank Grid (62%)
        Row(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .windowInsetsPadding(WindowInsets.displayCutout)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // LEFT PANE: Selected Tank Spotlight & Actions
            Surface(
                modifier = Modifier
                    .weight(0.39f)
                    .fillMaxHeight(),
                shape = RoundedCornerShape(18.dp),
                color = ArcadeBluePanel.copy(alpha = 0.96f),
                border = BorderStroke(2.5.dp, OutlineDark),
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(modifier = Modifier.size(92.dp)) {
                                TankPortraitArt(
                                    tank = selectedTank,
                                    cornerRadius = 14.dp,
                                    borderWidth = 2.5.dp,
                                    modifier = Modifier.fillMaxSize()
                                )
                                if (!isUnlocked) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(4.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color.Black.copy(alpha = 0.78f))
                                            .padding(3.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Lock,
                                            contentDescription = "Bloqueado",
                                            tint = GoldPrimary,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                RarityPill(rarity = selectedTank.rarity)
                                Text(
                                    text = selectedTank.name.uppercase(),
                                    style = MaterialTheme.typography.titleLarge.copy(fontSize = 16.sp),
                                    color = TextWhite,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = if (isUnlocked) "Nivel $level / ${EconomyRules.MAX_TANK_LEVEL}"
                                    else "Coste: ${selectedTank.unlockCost} ${selectedTank.unlockCurrency.symbol}",
                                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp),
                                    color = GoldPrimary
                                )
                                Text(
                                    text = "HP: ${selectedTank.hpAtLevel(level)} | Daño: ${selectedTank.damageAtLevel(level)}",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                                    color = TextWhite
                                )
                                Text(
                                    text = "Vel: ${selectedTank.speedTilesPerSec} cas/s",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                                    color = Color(0xFF93C5FD)
                                )
                            }
                        }

                        if (isUnlocked) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                ArcadeButton(
                                    onClick = { onUpgradeTank(selectedTank) },
                                    enabled = level < EconomyRules.MAX_TANK_LEVEL,
                                    topColor = GreenAction,
                                    bottomColor = GreenActionDeep,
                                    contentColor = TextWhite,
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 9.dp),
                                    modifier = Modifier.weight(1.1f),
                                    testTag = "upgrade_tank_button"
                                ) {
                                    if (level >= EconomyRules.MAX_TANK_LEVEL) {
                                        Text("MAX (10)", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                    } else {
                                        Icon(Icons.Default.ArrowUpward, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text("$upgradeCost", style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp))
                                        Spacer(modifier = Modifier.width(2.dp))
                                        BombIcon(Modifier.size(14.dp))
                                    }
                                }

                                ArcadeButton(
                                    onClick = { onEquipTank(selectedTank.id) },
                                    enabled = !isActive,
                                    topColor = if (isActive) Color(0xFF475569) else GoldPrimary,
                                    bottomColor = if (isActive) Color(0xFF334155) else GoldDeep,
                                    contentColor = if (isActive) TextWhite else OutlineDark,
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 9.dp),
                                    modifier = Modifier.weight(0.9f),
                                    testTag = "equip_tank_button"
                                ) {
                                    if (isActive) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text("ACTIVO", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                    } else {
                                        Text("EQUIPAR", style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp))
                                    }
                                }
                            }
                        } else {
                            ArcadeButton(
                                onClick = { onUnlockTank(selectedTank) },
                                topColor = GoldPrimary,
                                bottomColor = GoldDeep,
                                contentColor = OutlineDark,
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "unlock_tank_button"
                            ) {
                                Text(
                                    text = "DESBLOQUEAR (${selectedTank.unlockCost} ${selectedTank.unlockCurrency.symbol})",
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ArcadeButton(
                            onClick = onOpenCrate,
                            topColor = ArcadeBlueBright,
                            bottomColor = Color(0xFF1E40AF),
                            contentColor = TextWhite,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 9.dp),
                            modifier = Modifier.weight(1f),
                            testTag = "open_crate_button"
                        ) {
                            CrateArcadeIcon(Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(5.dp))
                            Text("CAJA (${EconomyRules.CRATE_COST_GEMAS}g)", style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp))
                        }

                        ArcadeButton(
                            onClick = onOpenProbabilities,
                            topColor = Color(0xFF334155),
                            bottomColor = Color(0xFF1E293B),
                            contentColor = GoldPrimary,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 9.dp),
                            testTag = "probabilities_button"
                        ) {
                            ProbabilitiesArcadeIcon(Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("%", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }

            // RIGHT PANE: Scrollable Collection by Rarity
            Column(
                modifier = Modifier
                    .weight(0.61f)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                orderedRarities.forEach { rarity ->
                    val tanksInRarity = GameCatalog.tanks.filter { it.rarity == rarity }
                    if (tanksInRarity.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                BrawlSectionRibbon(
                                    title = "${rarity.displayName.uppercase()} (${rarity.shortCode}) - ${rarity.probabilityPercent}%",
                                    accentColor = rarity.accentColor
                                )
                                Text(
                                    text = "${rarity.speedRangeLabel} | ${rarity.hpRangeLabel} HP",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextWhite
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                tanksInRarity.forEachIndexed { idx, tank ->
                                    val owned = tank.id in snapshot.unlockedTankIds
                                    val active = tank.id == snapshot.activeTankId
                                    val selected = tank.id == selectedTankId
                                    val tLevel = snapshot.tankLevels[tank.id] ?: 1

                                    TankCollectionCard(
                                        tank = tank,
                                        owned = owned,
                                        active = active,
                                        selected = selected,
                                        level = tLevel,
                                        facingRight = idx % 2 == 0,
                                        onClick = { onSelectTank(tank.id) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TankCollectionCard(
    tank: TankDefinition,
    owned: Boolean,
    active: Boolean,
    selected: Boolean,
    level: Int,
    facingRight: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = when {
        selected -> GoldPrimary
        active -> GreenAction
        else -> OutlineDark
    }
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag("tank_card_${tank.id}"),
        shape = RoundedCornerShape(14.dp),
        color = if (owned) ArcadeBlueCard else ArcadeNavy,
        border = BorderStroke(if (selected) 3.dp else 2.dp, borderColor),
        shadowElevation = if (selected) 8.dp else 3.dp
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(modifier = Modifier.size(64.dp)) {
                TankPortraitArt(
                    tank = tank,
                    facingRight = facingRight,
                    cornerRadius = 10.dp,
                    borderWidth = 2.dp,
                    modifier = Modifier.fillMaxSize()
                )
                if (!owned) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.Black.copy(alpha = 0.42f))
                    )
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Bloqueado",
                        tint = GoldPrimary,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(4.dp)
                            .size(14.dp)
                    )
                }
                if (active) {
                    Surface(
                        color = GoldPrimary,
                        shape = RoundedCornerShape(5.dp),
                        border = BorderStroke(1.dp, OutlineDark),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(3.dp)
                    ) {
                        Text(
                            text = "ACTIVO",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, fontWeight = FontWeight.ExtraBold),
                            color = OutlineDark,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = tank.name,
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp),
                    color = TextWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Surface(
                    color = if (owned) GreenActionDeep else ArcadeBluePanel,
                    shape = RoundedCornerShape(7.dp),
                    border = BorderStroke(1.5.dp, OutlineDark)
                ) {
                    Text(
                        text = if (owned) "Nv. $level / 10" else "${tank.unlockCost} ${tank.unlockCurrency.symbol}",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                        color = TextWhite,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}
