package com.example.ui.screens

import android.graphics.Paint
import android.graphics.Typeface
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.BattleCard
import com.example.model.EconomyRules
import com.example.ui.components.ArcadeButton
import com.example.ui.components.BombIcon
import com.example.ui.components.CentellaCoinIcon
import com.example.ui.components.GemIcon
import com.example.ui.components.TankPortraitArt
import com.example.ui.components.drawTopDown3DTank
import com.example.ui.theme.ArcadeBlueBright
import com.example.ui.theme.ArcadeBlueCard
import com.example.ui.theme.ArcadeBluePanel
import com.example.ui.theme.ArcadeNavy
import com.example.ui.theme.ArcadeNavyDeep
import com.example.ui.theme.CentellaCyan
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.CrimsonDeep
import com.example.ui.theme.ElixirPurple
import com.example.ui.theme.GemGreen
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GreenAction
import com.example.ui.theme.GreenActionDeep
import com.example.ui.theme.OutlineDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.BattlePhase
import com.example.viewmodel.BattleUiState
import com.example.viewmodel.MatchOutcome
import com.example.viewmodel.SafeZoneBounds
import com.example.viewmodel.SpawnKind
import com.example.viewmodel.SupplyKind
import java.util.Locale
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

@Composable
fun BattleScreen(
    battleState: BattleUiState,
    onSkipIntro: () -> Unit,
    onMoveVector: (Float, Float) -> Unit,
    onAimInput: (dx: Float, dy: Float, isPressed: Boolean, released: Boolean) -> Unit,
    onPlayCard: (Int) -> Unit,
    onRematch: () -> Unit,
    onExitBattle: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onExitBattle()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(ArcadeNavy, ArcadeNavyDeep))
            )
    ) {
        when (battleState.phase) {
            BattlePhase.MATCHMAKING -> MatchmakingContent(
                battleState = battleState,
                onCancel = onExitBattle
            )
            BattlePhase.VS_INTRO -> VsIntroContent(
                battleState = battleState,
                onSkipIntro = onSkipIntro,
                onExit = onExitBattle
            )
            BattlePhase.PLAYING -> PlayingArenaContent(
                battleState = battleState,
                onMoveVector = onMoveVector,
                onAimInput = onAimInput,
                onPlayCard = onPlayCard,
                onExit = onExitBattle
            )
            BattlePhase.FINISHED -> MatchResultContent(
                battleState = battleState,
                onRematch = onRematch,
                onExit = onExitBattle
            )
            BattlePhase.IDLE -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    ArcadeButton(
                        onClick = onRematch,
                        topColor = GoldPrimary,
                        bottomColor = GoldDeep
                    ) {
                        Text("BUSCAR PARTIDA 1 VS 1", style = MaterialTheme.typography.headlineMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun MatchmakingContent(
    battleState: BattleUiState,
    onCancel: () -> Unit
) {
    val playerTank = battleState.playerTank
    val mins = battleState.matchmakingElapsedSec / 60
    val secs = battleState.matchmakingElapsedSec % 60
    val elapsedLabel = String.format(Locale.US, "%02d:%02d", mins, secs)

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.img_survival_map_1795213539757),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(ArcadeNavyDeep.copy(alpha = 0.80f))
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .windowInsetsPadding(WindowInsets.displayCutout)
                .padding(horizontal = 20.dp, vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 680.dp),
                shape = RoundedCornerShape(22.dp),
                color = ArcadeBluePanel.copy(alpha = 0.96f),
                border = BorderStroke(3.dp, CentellaCyan),
                shadowElevation = 12.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (playerTank != null) {
                            TankPortraitArt(
                                tank = playerTank,
                                facingRight = true,
                                cornerRadius = 16.dp,
                                borderWidth = 3.dp,
                                modifier = Modifier.size(124.dp)
                            )
                        }
                        Text(
                            text = "${playerTank?.name ?: "Tanque"} (Nv.${battleState.playerLevel})",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = CentellaCyan,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.5.dp, OutlineDark)
                            ) {
                                Text(
                                    text = "EMPAREJAMIENTO ONLINE",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                                    color = OutlineDark,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                            Surface(
                                color = ArcadeNavyDeep,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.5.dp, GoldPrimary)
                            ) {
                                Text(
                                    text = elapsedLabel,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = GoldPrimary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Text(
                            text = "BUSCANDO RIVAL REAL...",
                            style = MaterialTheme.typography.headlineMedium,
                            color = GoldPrimary
                        )
                        Text(
                            text = battleState.matchmakingStatusText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextWhite
                        )
                        Text(
                            text = "Modo: ${battleState.battleMode.title} | Jugador: ${battleState.playerDisplayName}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .border(1.dp, OutlineDark, RoundedCornerShape(4.dp)),
                            color = CentellaCyan,
                            trackColor = ArcadeNavyDeep
                        )

                        ArcadeButton(
                            onClick = onCancel,
                            topColor = CrimsonDanger,
                            bottomColor = CrimsonDeep,
                            contentColor = TextWhite,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "cancel_matchmaking_button"
                        ) {
                            Text("CANCELAR BÚSQUEDA", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VsIntroContent(
    battleState: BattleUiState,
    onSkipIntro: () -> Unit,
    onExit: () -> Unit
) {
    val playerTank = battleState.playerTank
    val enemyTank = battleState.enemyTank

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.img_survival_map_1795213539757),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(ArcadeNavyDeep.copy(alpha = 0.74f))
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .windowInsetsPadding(WindowInsets.displayCutout)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 760.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = ArcadeBlueBright,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(2.5.dp, OutlineDark),
                    modifier = Modifier
                        .weight(1f)
                        .graphicsLayer { rotationZ = -1f }
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text(
                            text = "${if (battleState.isHost) "BASE OESTE" else "BASE ESTE"} - ${battleState.playerDisplayName}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFDBEAFE),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${playerTank?.name ?: "Tanque"} (Nv.${battleState.playerLevel})",
                            style = MaterialTheme.typography.titleLarge,
                            color = TextWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Surface(
                    color = CrimsonDanger,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(2.5.dp, OutlineDark),
                    modifier = Modifier
                        .weight(1f)
                        .graphicsLayer { rotationZ = 1f }
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "${if (battleState.isHost) "BASE ESTE" else "BASE OESTE"} - ${battleState.enemyDisplayName}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFFEE2E2),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${enemyTank?.name ?: "Rival"} (Nv.${battleState.enemyLevel})",
                            style = MaterialTheme.typography.titleLarge,
                            color = TextWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 700.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                if (playerTank != null) {
                    TankPortraitArt(
                        tank = playerTank,
                        facingRight = true,
                        cornerRadius = 18.dp,
                        borderWidth = 3.dp,
                        modifier = Modifier.size(136.dp)
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(
                        color = ArcadeNavyDeep,
                        shape = CircleShape,
                        border = BorderStroke(3.5.dp, GoldPrimary),
                        shadowElevation = 10.dp
                    ) {
                        Text(
                            text = "VS",
                            style = MaterialTheme.typography.displayLarge.copy(fontSize = 30.sp),
                            color = GoldPrimary,
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "¡PREPÁRATE! (${ceil(battleState.introCountdownSec).toInt().coerceAtLeast(1)})",
                        style = MaterialTheme.typography.titleLarge,
                        color = GoldPrimary
                    )
                }
                if (enemyTank != null) {
                    TankPortraitArt(
                        tank = enemyTank,
                        facingRight = false,
                        cornerRadius = 18.dp,
                        borderWidth = 3.dp,
                        modifier = Modifier.size(136.dp)
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 560.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ArcadeButton(
                    onClick = onExit,
                    topColor = Color(0xFF475569),
                    bottomColor = Color(0xFF1E293B),
                    contentColor = TextWhite,
                    modifier = Modifier.weight(0.35f)
                ) {
                    Text("SALIR", style = MaterialTheme.typography.labelLarge)
                }
                ArcadeButton(
                    onClick = onSkipIntro,
                    topColor = GoldPrimary,
                    bottomColor = GoldDeep,
                    contentColor = OutlineDark,
                    modifier = Modifier.weight(0.65f),
                    testTag = "skip_vs_button"
                ) {
                    Text("¡AL ATAQUE! (Mapa 30x15)", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

@Composable
private fun PlayingArenaContent(
    battleState: BattleUiState,
    onMoveVector: (Float, Float) -> Unit,
    onAimInput: (dx: Float, dy: Float, isPressed: Boolean, released: Boolean) -> Unit,
    onPlayCard: (Int) -> Unit,
    onExit: () -> Unit
) {
    val totalSec = ceil(battleState.timeRemainingSec).toInt().coerceAtLeast(0)
    val mins = totalSec / 60
    val secs = totalSec % 60
    val timerText = String.format(Locale.US, "%d:%02d", mins, secs)

    val textPaint = remember {
        Paint().apply {
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
    }
    val dashEffect = remember { PathEffect.dashPathEffect(floatArrayOf(10f, 7f), 0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "fireZoneAnim")
    val flamePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 950, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "flamePhase"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .windowInsetsPadding(WindowInsets.displayCutout)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // SLIM HORIZONTAL TOP HUD: Exit | Player HP | Timer + Zone/x2 | Enemy HP
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 920.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = onExit,
                modifier = Modifier
                    .size(38.dp)
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(10.dp))
                    .background(ArcadeBlueCard)
                    .border(2.dp, OutlineDark, RoundedCornerShape(10.dp))
                    .testTag("battle_exit_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Salir de la partida",
                    tint = TextWhite
                )
            }

            HealthHudBar(
                label = "TÚ: ${battleState.playerTank?.name ?: ""}",
                hp = battleState.playerHp,
                maxHp = battleState.playerMaxHp,
                shieldHp = battleState.playerShieldHp,
                barColor = GreenAction,
                modifier = Modifier.weight(1f)
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Surface(
                    color = if (totalSec <= 20) CrimsonDeep else ArcadeBluePanel,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(2.dp, if (totalSec <= 20) CrimsonDanger else GoldPrimary)
                ) {
                    Text(
                        text = timerText,
                        style = MaterialTheme.typography.titleLarge.copy(fontSize = 16.sp),
                        color = TextWhite,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
                if (battleState.stormActive) {
                    Surface(
                        color = Color(0xFF9A3412),
                        shape = RoundedCornerShape(9.dp),
                        border = BorderStroke(1.5.dp, Color(0xFFF97316))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(Modifier.width(3.dp))
                            Text(
                                text = "FUEGO",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = TextWhite
                            )
                        }
                    }
                }
                if (battleState.isDoubleElixir) {
                    Surface(
                        color = ElixirPurple,
                        shape = RoundedCornerShape(9.dp),
                        border = BorderStroke(1.5.dp, OutlineDark)
                    ) {
                        Text(
                            text = "x2",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = TextWhite,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            HealthHudBar(
                label = "${battleState.enemyDisplayName}: ${battleState.enemyTank?.name ?: ""}",
                hp = battleState.enemyHp,
                maxHp = battleState.enemyMaxHp,
                shieldHp = battleState.enemyShieldHp,
                barColor = CrimsonDanger,
                modifier = Modifier.weight(1f)
            )
        }

        if (battleState.opponentConnectionWarning) {
            Surface(
                color = CrimsonDeep,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.5.dp, GoldPrimary)
            ) {
                Text(
                    text = "Conexión inestable del rival: esperando respuesta en línea...",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = GoldPrimary,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 2.dp)
                )
            }
        }

        // CENTER: HUGE HORIZONTAL 30 x 15 TOP-DOWN 3D SURVIVAL ARENA
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 3.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxHeight()
                    .aspectRatio(2f, matchHeightConstraintsFirst = true),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(3.dp, OutlineDark),
                shadowElevation = 10.dp
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_survival_map_1795213539757),
                        contentDescription = "Mapa Supervivencia 3D 30x15",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val tileW = w / EconomyRules.MAP_WIDTH_TILES
                        val tileH = h / EconomyRules.MAP_HEIGHT_TILES
                        val tileSize = min(tileW, tileH)

                        drawRect(color = Color(0xFF0F172A).copy(alpha = 0.14f))

                        // 1. Tactical 30 x 15 grid overlay
                        for (c in 1 until EconomyRules.MAP_WIDTH_TILES) {
                            val gx = c * tileW
                            drawLine(
                                color = Color.White.copy(alpha = if (c % 5 == 0) 0.16f else 0.06f),
                                start = Offset(gx, 0f),
                                end = Offset(gx, h),
                                strokeWidth = if (c % 5 == 0) 1.3f else 0.7f
                            )
                        }
                        for (r in 1 until EconomyRules.MAP_HEIGHT_TILES) {
                            val gy = r * tileH
                            drawLine(
                                color = Color.White.copy(alpha = if (r % 5 == 0) 0.16f else 0.06f),
                                start = Offset(0f, gy),
                                end = Offset(w, gy),
                                strokeWidth = if (r % 5 == 0) 1.3f else 0.7f
                            )
                        }

                        // 2. Preset Spawn Points (Bases & Supply Pads)
                        battleState.spawnPoints.forEach { sp ->
                            val sx = sp.x * tileW
                            val sy = sp.y * tileH
                            when (sp.kind) {
                                SpawnKind.PLAYER_BASE -> {
                                    val r = tileSize * 1.25f
                                    drawCircle(color = ArcadeBlueBright.copy(alpha = 0.28f), radius = r, center = Offset(sx, sy))
                                    drawCircle(color = ArcadeBlueBright, radius = r, center = Offset(sx, sy), style = Stroke(width = 2.4f))
                                    drawCircle(color = Color(0xFF60A5FA), radius = r * 0.42f, center = Offset(sx, sy), style = Stroke(width = 1.8f))
                                }
                                SpawnKind.ENEMY_BASE -> {
                                    val r = tileSize * 1.25f
                                    drawCircle(color = CrimsonDanger.copy(alpha = 0.28f), radius = r, center = Offset(sx, sy))
                                    drawCircle(color = CrimsonDanger, radius = r, center = Offset(sx, sy), style = Stroke(width = 2.4f))
                                    drawCircle(color = Color(0xFFF87171), radius = r * 0.42f, center = Offset(sx, sy), style = Stroke(width = 1.8f))
                                }
                                SpawnKind.SUPPLY_PAD -> {
                                    val r = tileSize * 0.90f
                                    drawCircle(color = GoldPrimary.copy(alpha = 0.18f), radius = r, center = Offset(sx, sy))
                                    drawCircle(
                                        color = GoldPrimary.copy(alpha = 0.85f),
                                        radius = r,
                                        center = Offset(sx, sy),
                                        style = Stroke(width = 2.0f, pathEffect = dashEffect)
                                    )
                                    drawCircle(color = GoldPrimary.copy(alpha = 0.55f), radius = r * 0.26f, center = Offset(sx, sy))
                                }
                            }
                        }

                        // 3. Active Supply Pickups
                        battleState.pickups.forEach { pickup ->
                            val px = pickup.x * tileW
                            val py = pickup.y * tileH
                            val boxSize = tileSize * 0.98f
                            val half = boxSize / 2f
                            val crateColor = when (pickup.kind) {
                                SupplyKind.MEDKIT -> Color(0xFF22C55E)
                                SupplyKind.ELIXIR -> Color(0xFFA855F7)
                                SupplyKind.OVERCHARGE -> GoldPrimary
                            }
                            val crateSide = when (pickup.kind) {
                                SupplyKind.MEDKIT -> Color(0xFF15803D)
                                SupplyKind.ELIXIR -> Color(0xFF6B21A8)
                                SupplyKind.OVERCHARGE -> Color(0xFFB45309)
                            }
                            drawRoundRect(
                                color = Color.Black.copy(alpha = 0.40f),
                                topLeft = Offset(px - half + 3f, py - half + 5f),
                                size = Size(boxSize, boxSize),
                                cornerRadius = CornerRadius(6f, 6f)
                            )
                            drawRoundRect(
                                color = crateSide,
                                topLeft = Offset(px - half, py - half + tileSize * 0.14f),
                                size = Size(boxSize, boxSize),
                                cornerRadius = CornerRadius(6f, 6f)
                            )
                            drawRoundRect(
                                color = crateColor,
                                topLeft = Offset(px - half, py - half),
                                size = Size(boxSize, boxSize),
                                cornerRadius = CornerRadius(6f, 6f)
                            )
                            drawRoundRect(
                                color = OutlineDark,
                                topLeft = Offset(px - half, py - half),
                                size = Size(boxSize, boxSize),
                                cornerRadius = CornerRadius(6f, 6f),
                                style = Stroke(width = 2.0f)
                            )
                            when (pickup.kind) {
                                SupplyKind.MEDKIT -> {
                                    val arm = boxSize * 0.28f
                                    val thick = boxSize * 0.16f
                                    drawRect(color = Color.White, topLeft = Offset(px - arm, py - thick / 2f), size = Size(arm * 2f, thick))
                                    drawRect(color = Color.White, topLeft = Offset(px - thick / 2f, py - arm), size = Size(thick, arm * 2f))
                                }
                                SupplyKind.ELIXIR -> {
                                    drawCircle(color = Color.White, radius = boxSize * 0.22f, center = Offset(px, py))
                                }
                                SupplyKind.OVERCHARGE -> {
                                    drawCircle(color = OutlineDark, radius = boxSize * 0.24f, center = Offset(px, py))
                                    drawCircle(color = Color.White, radius = boxSize * 0.13f, center = Offset(px, py))
                                }
                            }
                        }

                        // 4. 3D-Extruded Map Walls
                        val wallDepthPx = tileSize * 0.26f
                        battleState.walls.forEach { wall ->
                            if (wall.hp > 0) {
                                val wl = wall.left * tileW
                                val wt = wall.top * tileH
                                val ww = (wall.right - wall.left) * tileW
                                val wh = (wall.bottom - wall.top) * tileH

                                drawRoundRect(
                                    color = Color.Black.copy(alpha = 0.42f),
                                    topLeft = Offset(wl + 3f, wt + wallDepthPx + 3f),
                                    size = Size(ww, wh),
                                    cornerRadius = CornerRadius(6f, 6f)
                                )

                                if (!wall.destructible) {
                                    drawRoundRect(
                                        color = Color(0xFF1E293B),
                                        topLeft = Offset(wl, wt),
                                        size = Size(ww, wh + wallDepthPx * 0.55f),
                                        cornerRadius = CornerRadius(6f, 6f)
                                    )
                                    val roofTop = wt - wallDepthPx * 0.42f
                                    drawRoundRect(
                                        brush = Brush.verticalGradient(
                                            colors = listOf(Color(0xFF94A3B8), Color(0xFF64748B))
                                        ),
                                        topLeft = Offset(wl, roofTop),
                                        size = Size(ww, wh),
                                        cornerRadius = CornerRadius(6f, 6f)
                                    )
                                    val inset = tileSize * 0.13f
                                    if (ww > inset * 2.4f && wh > inset * 2.4f) {
                                        drawRoundRect(
                                            color = Color(0xFF475569),
                                            topLeft = Offset(wl + inset, roofTop + inset),
                                            size = Size(ww - inset * 2f, wh - inset * 2f),
                                            cornerRadius = CornerRadius(4f, 4f)
                                        )
                                    }
                                    drawRoundRect(
                                        color = OutlineDark,
                                        topLeft = Offset(wl, roofTop),
                                        size = Size(ww, wh),
                                        cornerRadius = CornerRadius(6f, 6f),
                                        style = Stroke(width = 2.2f)
                                    )
                                } else {
                                    val roofTop = wt - wallDepthPx * 0.34f
                                    drawRoundRect(
                                        color = Color(0xFF78350F),
                                        topLeft = Offset(wl, wt),
                                        size = Size(ww, wh + wallDepthPx * 0.45f),
                                        cornerRadius = CornerRadius(6f, 6f)
                                    )
                                    drawRoundRect(
                                        brush = Brush.verticalGradient(
                                            colors = listOf(Color(0xFFF59E0B), Color(0xFFD97706))
                                        ),
                                        topLeft = Offset(wl, roofTop),
                                        size = Size(ww, wh),
                                        cornerRadius = CornerRadius(6f, 6f)
                                    )
                                    drawLine(
                                        color = Color(0xFF78350F).copy(alpha = 0.65f),
                                        start = Offset(wl + 4f, roofTop + 4f),
                                        end = Offset(wl + ww - 4f, roofTop + wh - 4f),
                                        strokeWidth = 2.2f
                                    )
                                    drawLine(
                                        color = Color(0xFF78350F).copy(alpha = 0.65f),
                                        start = Offset(wl + ww - 4f, roofTop + 4f),
                                        end = Offset(wl + 4f, roofTop + wh - 4f),
                                        strokeWidth = 2.2f
                                    )
                                    drawRoundRect(
                                        color = OutlineDark,
                                        topLeft = Offset(wl, roofTop),
                                        size = Size(ww, wh),
                                        cornerRadius = CornerRadius(6f, 6f),
                                        style = Stroke(width = 2.0f)
                                    )
                                    val hpRatio = (wall.hp.toFloat() / wall.maxHp.coerceAtLeast(1)).coerceIn(0f, 1f)
                                    if (hpRatio < 0.99f) {
                                        val barW = ww * 0.84f
                                        val barX = wl + (ww - barW) / 2f
                                        val barY = roofTop - 6f
                                        drawRect(color = OutlineDark, topLeft = Offset(barX, barY), size = Size(barW, 4.5f))
                                        drawRect(color = GoldPrimary, topLeft = Offset(barX + 1f, barY + 1f), size = Size((barW - 2f) * hpRatio, 2.5f))
                                    }
                                }
                            }
                        }

                        // 5. Aiming Sightline (Bright RED tactical laser when Red Joystick active, subtle cyan otherwise)
                        val pPx = battleState.playerX * tileW
                        val pPy = battleState.playerY * tileH
                        val sightLen = if (battleState.playerIsAiming) tileSize * 8.0f else tileSize * 3.8f
                        val sightEnd = Offset(
                            pPx + cos(battleState.playerTurretAngleRad) * sightLen,
                            pPy + sin(battleState.playerTurretAngleRad) * sightLen
                        )
                        drawLine(
                            color = if (battleState.playerIsAiming) CrimsonDanger.copy(alpha = 0.85f) else CentellaCyan.copy(alpha = 0.35f),
                            start = Offset(
                                pPx + cos(battleState.playerTurretAngleRad) * tileSize * 0.8f,
                                pPy + sin(battleState.playerTurretAngleRad) * tileSize * 0.8f
                            ),
                            end = sightEnd,
                            strokeWidth = if (battleState.playerIsAiming) 3.2f else 1.8f,
                            pathEffect = if (battleState.playerIsAiming) null else dashEffect
                        )
                        if (battleState.playerIsAiming) {
                            drawCircle(
                                color = CrimsonDanger.copy(alpha = 0.85f),
                                radius = tileSize * 0.28f,
                                center = sightEnd,
                                style = Stroke(width = 2.4f)
                            )
                        }

                        // 6. 3D Top-Down Enemy & Player Tanks
                        battleState.enemyTank?.let { enemy ->
                            drawTopDown3DTank(
                                tank = enemy,
                                centerX = battleState.enemyX * tileW,
                                centerY = battleState.enemyY * tileH,
                                tileSize = tileSize,
                                chassisAngleRad = battleState.enemyChassisAngleRad,
                                turretAngleRad = battleState.enemyTurretAngleRad,
                                recoilTiles = battleState.enemyRecoilSec * 1.4f,
                                isPlayer = false,
                                hasShield = battleState.enemyShieldHp > 0,
                                isTurbo = battleState.enemyTurboActive,
                                isOvercharged = battleState.enemyOverchargeActive,
                                isStunned = battleState.enemyStunSec > 0f
                            )
                        }

                        battleState.playerTank?.let { player ->
                            drawTopDown3DTank(
                                tank = player,
                                centerX = pPx,
                                centerY = pPy,
                                tileSize = tileSize,
                                chassisAngleRad = battleState.playerChassisAngleRad,
                                turretAngleRad = battleState.playerTurretAngleRad,
                                recoilTiles = battleState.playerRecoilSec * 1.4f,
                                isPlayer = true,
                                hasShield = battleState.playerShieldHp > 0,
                                isTurbo = battleState.playerTurboSec > 0f,
                                isOvercharged = battleState.playerOverchargeSec > 0f,
                                isStunned = false
                            )
                        }

                        // 7. Projectiles
                        battleState.projectiles.forEach { proj ->
                            val cx = proj.x * tileW
                            val cy = proj.y * tileH
                            val radius = proj.radiusTiles * tileSize * 0.92f
                            val color = when {
                                proj.isLightning -> CentellaCyan
                                proj.isHeavy -> Color(0xFFFF6B00)
                                proj.fromPlayer -> GoldPrimary
                                else -> CrimsonDanger
                            }
                            drawCircle(color = color.copy(alpha = 0.42f), radius = radius * 1.65f, center = Offset(cx, cy))
                            drawCircle(color = color, radius = radius, center = Offset(cx, cy))
                            drawCircle(color = Color.White.copy(alpha = 0.7f), radius = radius * 0.4f, center = Offset(cx - radius * 0.2f, cy - radius * 0.2f))
                            drawCircle(color = OutlineDark, radius = radius, center = Offset(cx, cy), style = Stroke(width = 2.2f))
                        }

                        // 8. Explosions
                        battleState.explosions.forEach { exp ->
                            val progress = 1f - (exp.remainingSec / exp.totalSec.coerceAtLeast(0.01f))
                            val cx = exp.x * tileW
                            val cy = exp.y * tileH
                            val radius = exp.radiusTiles * tileSize * (0.65f + progress * 0.85f)
                            val alpha = (1f - progress).coerceIn(0f, 1f)
                            drawCircle(
                                color = Color(exp.colorHex).copy(alpha = alpha * 0.62f),
                                radius = radius,
                                center = Offset(cx, cy)
                            )
                            drawCircle(
                                color = Color(0xFFFFFBEB).copy(alpha = alpha * 0.78f),
                                radius = radius * 0.45f,
                                center = Offset(cx, cy)
                            )
                        }

                        // 9. ANIMATED SURVIVAL FIRE ZONE
                        if (battleState.stormActive) {
                            drawAnimatedFireZone(
                                safeZone = battleState.safeZone,
                                w = w,
                                h = h,
                                tileW = tileW,
                                tileH = tileH,
                                tileSize = tileSize,
                                flamePhase = flamePhase
                            )
                        }

                        // 10. Floating Battle Texts
                        battleState.floatingTexts.forEach { ft ->
                            textPaint.color = Color(ft.colorHex).toArgb()
                            textPaint.textSize = (tileSize * 1.0f).coerceIn(20f, 36f)
                            drawContext.canvas.nativeCanvas.drawText(
                                ft.text,
                                ft.x * tileW,
                                ft.y * tileH,
                                textPaint
                            )
                        }
                    }
                }
            }
        }

        // BOTTOM TWIN-STICK CONTROLS:
        // LEFT: BLUE Movement Joystick | CENTER: Elixir + 4 Tactical Cards | RIGHT: RED Aim/Fire Joystick
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 920.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // BLUE JOYSTICK (Movement)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                TwinStickPad(
                    baseColor = ArcadeBluePanel,
                    ringColor = Color(0xFF60A5FA),
                    knobTopColor = Color(0xFF93C5FD),
                    knobMainColor = ArcadeBlueBright,
                    knobDeepColor = Color(0xFF1E40AF),
                    onStickUpdate = { dx, dy, isPressed, _ ->
                        if (isPressed) onMoveVector(dx, dy) else onMoveVector(0f, 0f)
                    },
                    modifier = Modifier
                        .size(88.dp)
                        .testTag("blue_move_joystick")
                )
                Text(
                    text = "MOVER",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.ExtraBold),
                    color = Color(0xFF93C5FD)
                )
            }

            // CENTER: Elixir Bar + 4 Cards
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = ArcadeBluePanel,
                    border = BorderStroke(1.5.dp, OutlineDark)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Bolt, contentDescription = null, tint = ElixirPurple, modifier = Modifier.size(15.dp))
                        Text(
                            text = "${battleState.elixir.toInt()}/10",
                            style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp),
                            color = TextWhite
                        )
                        LinearProgressIndicator(
                            progress = { (battleState.elixir / battleState.maxElixir).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .weight(1f)
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .border(1.dp, OutlineDark, RoundedCornerShape(4.dp)),
                            color = ElixirPurple,
                            trackColor = ArcadeNavyDeep
                        )
                        if (battleState.playerOverchargeSec > 0f) {
                            Text("x1.35", style = MaterialTheme.typography.labelSmall, color = GoldPrimary)
                        }
                        if (battleState.playerTurboSec > 0f) {
                            Text("TURBO", style = MaterialTheme.typography.labelSmall, color = Color(0xFFE879F9))
                        }
                        battleState.nextCard?.let { nxt ->
                            Text(
                                text = "Sig: ${nxt.name}",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = TextMuted,
                                maxLines = 1
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    battleState.handCards.forEachIndexed { idx, card ->
                        BattleCardButton(
                            card = card,
                            elixir = battleState.elixir,
                            onClick = { onPlayCard(idx) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("battle_card_$idx")
                        )
                    }
                }
            }

            // RED JOYSTICK (Aim & Shoot)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                TwinStickPad(
                    baseColor = Color(0xFF3F1219),
                    ringColor = Color(0xFFF87171),
                    knobTopColor = Color(0xFFFCA5A5),
                    knobMainColor = CrimsonDanger,
                    knobDeepColor = Color(0xFF991B1B),
                    onStickUpdate = { dx, dy, isPressed, released ->
                        onAimInput(dx, dy, isPressed, released)
                    },
                    modifier = Modifier
                        .size(88.dp)
                        .testTag("red_fire_joystick")
                )
                Text(
                    text = "DISPARAR",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.ExtraBold),
                    color = Color(0xFFFCA5A5)
                )
            }
        }
    }
}

private fun DrawScope.drawAnimatedFireZone(
    safeZone: SafeZoneBounds,
    w: Float,
    h: Float,
    tileW: Float,
    tileH: Float,
    tileSize: Float,
    flamePhase: Float
) {
    val szLeft = (safeZone.minX * tileW).coerceIn(0f, w)
    val szTop = (safeZone.minY * tileH).coerceIn(0f, h)
    val szRight = (safeZone.maxX * tileW).coerceIn(0f, w)
    val szBottom = (safeZone.maxY * tileH).coerceIn(0f, h)

    val pulse = 0.34f + 0.12f * sin(flamePhase * 2f)
    val outerFireGlow = Color(0xFFDC2626).copy(alpha = pulse)

    if (szTop > 0f) {
        drawRect(
            brush = Brush.verticalGradient(listOf(outerFireGlow, Color(0xFFEA580C).copy(alpha = pulse * 1.15f)), startY = 0f, endY = szTop),
            topLeft = Offset(0f, 0f),
            size = Size(w, szTop)
        )
    }
    if (szBottom < h) {
        drawRect(
            brush = Brush.verticalGradient(listOf(Color(0xFFEA580C).copy(alpha = pulse * 1.15f), outerFireGlow), startY = szBottom, endY = h),
            topLeft = Offset(0f, szBottom),
            size = Size(w, h - szBottom)
        )
    }
    if (szLeft > 0f && szBottom > szTop) {
        drawRect(
            brush = Brush.horizontalGradient(listOf(outerFireGlow, Color(0xFFEA580C).copy(alpha = pulse * 1.15f)), startX = 0f, endX = szLeft),
            topLeft = Offset(0f, szTop),
            size = Size(szLeft, szBottom - szTop)
        )
    }
    if (szRight < w && szBottom > szTop) {
        drawRect(
            brush = Brush.horizontalGradient(listOf(Color(0xFFEA580C).copy(alpha = pulse * 1.15f), outerFireGlow), startX = szRight, endX = w),
            topLeft = Offset(szRight, szTop),
            size = Size(w - szRight, szBottom - szTop)
        )
    }

    // Animated flame tongues along horizontal edges (top & bottom)
    val step = (tileSize * 0.68f).coerceAtLeast(10f)
    val flameDepth = tileSize * 0.85f
    var x = szLeft
    var idx = 0
    while (x <= szRight) {
        val wave1 = sin(flamePhase + idx * 0.9f)
        val wave2 = cos(flamePhase * 1.3f + idx * 1.1f)
        val fHeight = flameDepth * (0.72f + 0.36f * wave1)
        val sway = tileSize * 0.16f * wave2

        // Top fire edge (tongues reaching slightly inward/outward)
        if (szTop > 1f) {
            drawFlameTongue(
                baseX = x,
                baseY = szTop,
                tipX = x + sway,
                tipY = szTop + fHeight * 0.55f,
                width = step * 0.85f,
                horizontal = false
            )
        }
        // Bottom fire edge
        if (szBottom < h - 1f) {
            drawFlameTongue(
                baseX = x,
                baseY = szBottom,
                tipX = x - sway,
                tipY = szBottom - fHeight * 0.55f,
                width = step * 0.85f,
                horizontal = false
            )
        }
        // Floating embers outside zone
        if (idx % 2 == 0) {
            val sparkProg = ((flamePhase / (2f * PI.toFloat())) + idx * 0.17f) % 1f
            if (szTop > 4f) {
                drawCircle(
                    color = Color(0xFFFDE047).copy(alpha = (1f - sparkProg) * 0.85f),
                    radius = (tileSize * 0.11f) * (1f - sparkProg * 0.5f),
                    center = Offset(x + sway * 1.5f, szTop * (1f - sparkProg * 0.7f))
                )
            }
            if (szBottom < h - 4f) {
                drawCircle(
                    color = Color(0xFFFB923C).copy(alpha = (1f - sparkProg) * 0.85f),
                    radius = (tileSize * 0.11f) * (1f - sparkProg * 0.5f),
                    center = Offset(x - sway * 1.5f, szBottom + (h - szBottom) * sparkProg * 0.7f)
                )
            }
        }
        x += step
        idx++
    }

    // Animated flame tongues along vertical edges (left & right)
    var y = szTop
    var vIdx = 0
    while (y <= szBottom) {
        val wave = sin(flamePhase * 1.15f + vIdx * 0.95f)
        val sway = tileSize * 0.15f * cos(flamePhase + vIdx)
        val fDepth = flameDepth * (0.70f + 0.35f * wave)

        if (szLeft > 1f) {
            drawFlameTongue(
                baseX = szLeft,
                baseY = y,
                tipX = szLeft + fDepth * 0.55f,
                tipY = y + sway,
                width = step * 0.85f,
                horizontal = true
            )
        }
        if (szRight < w - 1f) {
            drawFlameTongue(
                baseX = szRight,
                baseY = y,
                tipX = szRight - fDepth * 0.55f,
                tipY = y - sway,
                width = step * 0.85f,
                horizontal = true
            )
        }
        y += step
        vIdx++
    }

    // Glowing fire perimeter line
    if (szRight > szLeft && szBottom > szTop) {
        drawRect(
            color = Color(0xFFFACC15).copy(alpha = 0.85f),
            topLeft = Offset(szLeft, szTop),
            size = Size(szRight - szLeft, szBottom - szTop),
            style = Stroke(width = 3.2f)
        )
    }
}

private fun DrawScope.drawFlameTongue(
    baseX: Float,
    baseY: Float,
    tipX: Float,
    tipY: Float,
    width: Float,
    horizontal: Boolean
) {
    val halfW = width * 0.5f
    val outer = Path().apply {
        if (horizontal) {
            moveTo(baseX, baseY - halfW)
            lineTo(tipX, tipY)
            lineTo(baseX, baseY + halfW)
        } else {
            moveTo(baseX - halfW, baseY)
            lineTo(tipX, tipY)
            lineTo(baseX + halfW, baseY)
        }
        close()
    }
    val inner = Path().apply {
        val midX = (baseX + tipX) * 0.55f
        val midY = (baseY + tipY) * 0.55f
        if (horizontal) {
            moveTo(baseX, baseY - halfW * 0.52f)
            lineTo(midX, midY)
            lineTo(baseX, baseY + halfW * 0.52f)
        } else {
            moveTo(baseX - halfW * 0.52f, baseY)
            lineTo(midX, midY)
            lineTo(baseX + halfW * 0.52f, baseY)
        }
        close()
    }
    drawPath(outer, color = Color(0xFFF97316).copy(alpha = 0.82f))
    drawPath(inner, color = Color(0xFFFDE047).copy(alpha = 0.90f))
}

@Composable
private fun TwinStickPad(
    baseColor: Color,
    ringColor: Color,
    knobTopColor: Color,
    knobMainColor: Color,
    knobDeepColor: Color,
    onStickUpdate: (dx: Float, dy: Float, isPressed: Boolean, released: Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var padSize by remember { mutableStateOf(IntSize.Zero) }
    var knobOffset by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier = modifier
            .onSizeChanged { padSize = it }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val cx = padSize.width / 2f
                    val cy = padSize.height / 2f
                    val maxR = (min(padSize.width, padSize.height) / 2f * 0.72f).coerceAtLeast(1f)

                    var lastNx = 0f
                    var lastNy = 0f

                    fun updateKnob(pos: Offset) {
                        val dx = pos.x - cx
                        val dy = pos.y - cy
                        val dist = hypot(dx, dy)
                        val clampedDist = min(dist, maxR)
                        lastNx = if (dist > 0.001f) (dx / dist) * (clampedDist / maxR) else 0f
                        lastNy = if (dist > 0.001f) (dy / dist) * (clampedDist / maxR) else 0f
                        knobOffset = Offset(lastNx * maxR, lastNy * maxR)
                        onStickUpdate(lastNx, lastNy, true, false)
                    }

                    updateKnob(down.position)
                    do {
                        val event = awaitPointerEvent()
                        val pointer = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!pointer.pressed) break
                        pointer.consume()
                        updateKnob(pointer.position)
                    } while (true)

                    knobOffset = Offset.Zero
                    onStickUpdate(lastNx, lastNy, false, true)
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val radius = min(size.width, size.height) / 2f
            val center = Offset(size.width / 2f, size.height / 2f)

            drawCircle(
                color = baseColor.copy(alpha = 0.90f),
                radius = radius - 2f,
                center = center
            )
            drawCircle(
                color = OutlineDark,
                radius = radius - 2f,
                center = center,
                style = Stroke(width = 3f)
            )
            drawCircle(
                color = ringColor.copy(alpha = 0.55f),
                radius = radius * 0.68f,
                center = center,
                style = Stroke(width = 2.2f)
            )

            val tickR = radius * 0.78f
            listOf(
                Offset(center.x, center.y - tickR),
                Offset(center.x, center.y + tickR),
                Offset(center.x - tickR, center.y),
                Offset(center.x + tickR, center.y)
            ).forEach { pt ->
                drawCircle(color = ringColor.copy(alpha = 0.75f), radius = 3.0f, center = pt)
            }

            val knobPos = center + knobOffset
            val knobR = radius * 0.39f
            drawCircle(
                color = Color.Black.copy(alpha = 0.38f),
                radius = knobR,
                center = Offset(knobPos.x + 2f, knobPos.y + 3f)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(knobTopColor, knobMainColor, knobDeepColor),
                    center = Offset(knobPos.x - knobR * 0.25f, knobPos.y - knobR * 0.25f),
                    radius = knobR * 1.4f
                ),
                radius = knobR,
                center = knobPos
            )
            drawCircle(
                color = OutlineDark,
                radius = knobR,
                center = knobPos,
                style = Stroke(width = 2.5f)
            )
        }
    }
}

@Composable
private fun HealthHudBar(
    label: String,
    hp: Int,
    maxHp: Int,
    shieldHp: Int,
    barColor: Color,
    modifier: Modifier = Modifier
) {
    val pct = (hp.toFloat() / maxHp.coerceAtLeast(1)).coerceIn(0f, 1f)
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(9.dp),
        color = ArcadeBluePanel,
        border = BorderStroke(2.dp, OutlineDark)
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                    color = TextWhite,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (shieldHp > 0) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = CentellaCyan, modifier = Modifier.size(11.dp))
                        Text("+$shieldHp ", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = CentellaCyan)
                    }
                    Text("$hp", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold), color = TextWhite)
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            LinearProgressIndicator(
                progress = { pct },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .border(1.dp, OutlineDark, RoundedCornerShape(4.dp)),
                color = barColor,
                trackColor = ArcadeNavyDeep
            )
        }
    }
}

@Composable
private fun BattleCardButton(
    card: BattleCard,
    elixir: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ready = elixir >= card.elixirCost
    Surface(
        modifier = modifier
            .height(54.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(enabled = ready, onClick = onClick),
        shape = RoundedCornerShape(10.dp),
        color = if (ready) ArcadeBlueCard else Color(0xFF111C33),
        border = BorderStroke(2.dp, if (ready) card.badgeColor else OutlineDark)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp, vertical = 3.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = if (ready) ElixirPurple else Color(0xFF334155),
                    shape = CircleShape,
                    border = BorderStroke(1.dp, OutlineDark)
                ) {
                    Text(
                        text = "${card.elixirCost}",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.ExtraBold),
                        color = TextWhite,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                    )
                }
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(card.badgeColor)
                )
            }
            Text(
                text = card.name,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                color = if (ready) TextWhite else TextMuted,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun MatchResultContent(
    battleState: BattleUiState,
    onRematch: () -> Unit,
    onExit: () -> Unit
) {
    val summary = battleState.rewardSummary
    val title = when (summary?.outcome) {
        MatchOutcome.VICTORY -> "¡VICTORIA!"
        MatchOutcome.DEFEAT -> "DERROTA"
        MatchOutcome.DRAW -> "EMPATE"
        null -> "FIN DE PARTIDA"
    }
    val accent = when (summary?.outcome) {
        MatchOutcome.VICTORY -> GoldPrimary
        MatchOutcome.DEFEAT -> CrimsonDanger
        else -> CentellaCyan
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.img_survival_map_1795213539757),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(ArcadeNavyDeep.copy(alpha = 0.82f))
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .windowInsetsPadding(WindowInsets.displayCutout)
                .padding(18.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 660.dp),
                shape = RoundedCornerShape(22.dp),
                color = ArcadeBluePanel,
                border = BorderStroke(3.dp, accent),
                shadowElevation = 12.dp
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Column(
                        modifier = Modifier.weight(0.45f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.EmojiEvents,
                            contentDescription = null,
                            tint = accent,
                            modifier = Modifier.size(54.dp)
                        )
                        Text(
                            text = title,
                            style = MaterialTheme.typography.displayLarge.copy(fontSize = 30.sp),
                            color = accent
                        )
                        if (summary != null) {
                            Text(
                                text = "vs ${battleState.enemyDisplayName}\nDuración: ${summary.durationUsedSec}s\nDaño: ${summary.damageDealt} | Disparos: ${summary.shotsFired}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextMuted,
                                textAlign = TextAlign.Center
                            )
                            if (!summary.reasonLabel.isNullOrBlank()) {
                                Text(
                                    text = summary.reasonLabel,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = CentellaCyan,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    Column(
                        modifier = Modifier.weight(0.55f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (summary != null) {
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                color = ArcadeNavyDeep,
                                border = BorderStroke(2.dp, OutlineDark)
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text("RECOMPENSAS OBTENIDAS", style = MaterialTheme.typography.labelLarge, color = TextWhite)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceEvenly
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            BombIcon(Modifier.size(20.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("+${summary.bombasEarned} b", style = MaterialTheme.typography.titleMedium, color = TextWhite)
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            GemIcon(Modifier.size(20.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("+${summary.gemasEarned} g", style = MaterialTheme.typography.titleMedium, color = GemGreen)
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            CentellaCoinIcon(Modifier.size(20.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("+${summary.fcEarned} fc", style = MaterialTheme.typography.titleMedium, color = CentellaCyan)
                                        }
                                    }
                                    if (summary.gemsCappedByDailyLimit || summary.fcCappedByDailyLimit) {
                                        Text(
                                            text = "Límite diario alcanzado en ${if (summary.fcCappedByDailyLimit) "Fichas Centella (100/día) " else ""}${if (summary.gemsCappedByDailyLimit) "Gemas batalla (400/día)" else ""}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = GoldPrimary,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            ArcadeButton(
                                onClick = onExit,
                                topColor = ArcadeBlueBright,
                                bottomColor = Color(0xFF1E40AF),
                                contentColor = TextWhite,
                                modifier = Modifier.weight(1f),
                                testTag = "result_home_button"
                            ) {
                                Text("INICIO", style = MaterialTheme.typography.labelLarge)
                            }
                            ArcadeButton(
                                onClick = onRematch,
                                topColor = GreenAction,
                                bottomColor = GreenActionDeep,
                                contentColor = TextWhite,
                                modifier = Modifier.weight(1f),
                                testTag = "result_rematch_button"
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("REVANCHA", style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                }
            }
        }
    }
}
