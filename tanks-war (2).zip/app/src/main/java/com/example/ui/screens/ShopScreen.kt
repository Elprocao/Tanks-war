package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.GameCatalog
import com.example.model.EconomyRules
import com.example.model.GameStateSnapshot
import com.example.model.ShopPackDefinition
import com.example.model.ShopPackKind
import com.example.ui.components.ArcadeButton
import com.example.ui.components.BombBundleArt
import com.example.ui.components.BombIcon
import com.example.ui.components.BrawlSectionRibbon
import com.example.ui.components.CentellaCoinIcon
import com.example.ui.components.CrateArcadeIcon
import com.example.ui.components.GemIcon
import com.example.ui.theme.ArcadeBlueBright
import com.example.ui.theme.ArcadeBlueCard
import com.example.ui.theme.ArcadeBluePanel
import com.example.ui.theme.ArcadeNavy
import com.example.ui.theme.ArcadeNavyDeep
import com.example.ui.theme.CentellaCyan
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GreenAction
import com.example.ui.theme.GreenActionDeep
import com.example.ui.theme.OutlineDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

import com.example.ads.RewardedAdStatus
import com.example.billing.BillingConnectionState

@Composable
fun ShopScreen(
    snapshot: GameStateSnapshot,
    isMondayAvailable: Boolean,
    isWeeklyClaimedThisWeek: Boolean,
    adStatus: RewardedAdStatus,
    adStatusMessage: String,
    billingStatus: BillingConnectionState,
    billingStatusMessage: String,
    playFormattedPrices: Map<String, String>,
    onWatchAdClick: (ShopPackDefinition) -> Unit,
    onPackClick: (ShopPackDefinition) -> Unit,
    onToggleSimulateMonday: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val adsRemaining = (EconomyRules.MAX_DAILY_ADS - snapshot.dailyAdsWatched).coerceAtLeast(0)
    val adPack = GameCatalog.shopPacks.first { it.kind == ShopPackKind.OPTIONAL_AD }
    val bombPacks = GameCatalog.shopPacks.filter {
        it.kind == ShopPackKind.BOMBS_FOR_GEMS || it.kind == ShopPackKind.BOMBS_FOR_EUR
    }
    val mondayPack = GameCatalog.shopPacks.first { it.kind == ShopPackKind.MONDAY_WEEKLY_FC }
    val mondayUnlocked = isMondayAvailable && !isWeeklyClaimedThisWeek

    Box(modifier = modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.img_tank_shop_bg_1795213539157),
            contentDescription = "Fondo Tienda Tanks War",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            ArcadeNavyDeep.copy(alpha = 0.76f),
                            ArcadeNavyDeep.copy(alpha = 0.90f)
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .windowInsetsPadding(WindowInsets.displayCutout)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            BrawlSectionRibbon(
                title = "OFERTAS DIARIAS Y SEMANALES",
                accentColor = Color(0xFFD97706)
            )

            // TOP ROW: Optional Daily AD (4/day) + Monday Weekly Offer (150 fc) side-by-side
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1. Optional Daily Rewarded AD Card
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    shape = RoundedCornerShape(16.dp),
                    color = ArcadeBluePanel.copy(alpha = 0.96f),
                    border = BorderStroke(2.5.dp, GoldPrimary),
                    shadowElevation = 8.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(ArcadeNavyDeep)
                                .border(2.dp, GoldPrimary, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            CrateArcadeIcon(Modifier.size(38.dp))
                        }

                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Surface(
                                color = GreenActionDeep,
                                shape = RoundedCornerShape(7.dp),
                                border = BorderStroke(1.dp, OutlineDark)
                            ) {
                                Text(
                                    text = "OPCIONAL | HOY: $adsRemaining/${EconomyRules.MAX_DAILY_ADS}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                                    color = TextWhite,
                                    maxLines = 1,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = adPack.title,
                                style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp),
                                color = TextWhite,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    BombIcon(Modifier.size(14.dp))
                                    Spacer(Modifier.width(3.dp))
                                    Text("+${adPack.bombsGranted}", style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp), color = TextWhite)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    GemIcon(Modifier.size(14.dp))
                                    Spacer(Modifier.width(3.dp))
                                    Text("+${adPack.gemsGranted}", style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp), color = TextWhite)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CentellaCoinIcon(Modifier.size(14.dp))
                                    Spacer(Modifier.width(3.dp))
                                    Text("+${adPack.fcGranted}", style = MaterialTheme.typography.labelLarge.copy(fontSize = 12.sp), color = TextWhite)
                                }
                            }
                            Text(
                                text = "AdMob: $adStatusMessage | Bonus hoy: ${snapshot.dailyBonusGemsEarned}/${EconomyRules.MAX_DAILY_BONUS_GEMS} g",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = if (adStatus == RewardedAdStatus.READY) CentellaCyan else TextMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        val adButtonText = when {
                            adsRemaining <= 0 -> "0/4"
                            adStatus == RewardedAdStatus.READY -> "VER AD"
                            adStatus == RewardedAdStatus.UNAVAILABLE -> "REINTENTAR"
                            else -> "CARGA..."
                        }

                        ArcadeButton(
                            onClick = { onWatchAdClick(adPack) },
                            enabled = adsRemaining > 0 && adStatus != RewardedAdStatus.SHOWING,
                            topColor = if (adStatus == RewardedAdStatus.READY) GoldPrimary else ArcadeBlueBright,
                            bottomColor = if (adStatus == RewardedAdStatus.READY) GoldDeep else Color(0xFF1E40AF),
                            contentColor = if (adStatus == RewardedAdStatus.READY) OutlineDark else TextWhite,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                            modifier = Modifier.width(96.dp),
                            testTag = "shop_ad_button"
                        ) {
                            Icon(Icons.Default.PlayCircle, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = adButtonText,
                                style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold),
                                maxLines = 1
                            )
                        }
                    }
                }

                // 7. Weekly Monday Offer: 150 fc for 1.99 €
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    shape = RoundedCornerShape(16.dp),
                    color = (if (mondayUnlocked) ArcadeBlueCard else ArcadeNavy).copy(alpha = 0.96f),
                    border = BorderStroke(2.5.dp, if (mondayUnlocked) CentellaCyan else OutlineDark),
                    shadowElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(ArcadeNavyDeep)
                                        .border(2.dp, CentellaCyan, RoundedCornerShape(10.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CentellaCoinIcon(Modifier.size(30.dp))
                                }
                                Column {
                                    Text(
                                        text = "OFERTA LUNES (1/sem)",
                                        style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.5.sp),
                                        color = CentellaCyan,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "150 Fichas Centella (150 fc)",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                                        color = TextWhite,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Spacer(Modifier.width(4.dp))
                            Surface(
                                color = when {
                                    isWeeklyClaimedThisWeek -> GreenActionDeep
                                    isMondayAvailable -> CentellaCyan
                                    else -> Color(0xFF334155)
                                },
                                shape = RoundedCornerShape(7.dp),
                                border = BorderStroke(1.dp, OutlineDark)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = when {
                                            isWeeklyClaimedThisWeek -> Icons.Default.Verified
                                            isMondayAvailable -> Icons.Default.CalendarToday
                                            else -> Icons.Default.Lock
                                        },
                                        contentDescription = null,
                                        tint = if (isMondayAvailable && !isWeeklyClaimedThisWeek) OutlineDark else TextWhite,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(Modifier.width(3.dp))
                                    Text(
                                        text = when {
                                            isWeeklyClaimedThisWeek -> "RECLAMADA"
                                            isMondayAvailable -> "LUNES"
                                            else -> "BLOQ."
                                        },
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                                        color = if (isMondayAvailable && !isWeeklyClaimedThisWeek) OutlineDark else TextWhite
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Simular Lunes",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Switch(
                                    checked = snapshot.simulateMondayForTesting,
                                    onCheckedChange = onToggleSimulateMonday,
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = OutlineDark,
                                        checkedTrackColor = CentellaCyan
                                    )
                                )
                            }

                            val mondayPrice = playFormattedPrices[mondayPack.id] ?: mondayPack.priceLabel
                            ArcadeButton(
                                onClick = { onPackClick(mondayPack) },
                                enabled = mondayUnlocked,
                                topColor = CentellaCyan,
                                bottomColor = Color(0xFF0369A1),
                                contentColor = OutlineDark,
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                modifier = Modifier.width(114.dp),
                                testTag = "shop_monday_offer_button"
                            ) {
                                Text(
                                    text = when {
                                        isWeeklyClaimedThisWeek -> "COMPRADA"
                                        !isMondayAvailable -> "BLOQUEADA"
                                        else -> mondayPrice
                                    },
                                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                BrawlSectionRibbon(
                    title = "PACKS DE BOMBAS",
                    accentColor = ArcadeBlueBright
                )
                Text(
                    text = billingStatusMessage,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                    color = if (billingStatus == BillingConnectionState.READY) CentellaCyan else TextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // 5 Bomb Packs in a clean horizontal 5-card grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                bombPacks.forEachIndexed { idx, pack ->
                    val dynamicPrice = if (pack.kind == ShopPackKind.BOMBS_FOR_EUR) {
                        playFormattedPrices[pack.id] ?: pack.priceLabel
                    } else {
                        pack.priceLabel
                    }
                    BombPackCard(
                        pack = pack,
                        displayedPrice = dynamicPrice,
                        bundleTier = idx,
                        canAffordGems = snapshot.gemas >= pack.gemCost,
                        onClick = { onPackClick(pack) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun BombPackCard(
    pack: ShopPackDefinition,
    displayedPrice: String,
    bundleTier: Int,
    canAffordGems: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isGemPack = pack.kind == ShopPackKind.BOMBS_FOR_GEMS
    val borderColor = if (pack.highlighted) GoldPrimary else OutlineDark

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = (if (pack.highlighted) Color(0xFF283F73) else ArcadeBlueCard).copy(alpha = 0.96f),
        border = BorderStroke(2.5.dp, borderColor),
        shadowElevation = 6.dp
    ) {
        Column(
            modifier = Modifier.padding(9.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = pack.title,
                style = MaterialTheme.typography.titleMedium.copy(fontSize = 12.sp, fontWeight = FontWeight.ExtraBold),
                color = if (pack.highlighted) GoldPrimary else TextWhite,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            BombBundleArt(tier = bundleTier, modifier = Modifier.size(44.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                BombIcon(Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "x${pack.bombsGranted}",
                    style = MaterialTheme.typography.titleLarge.copy(fontSize = 17.sp),
                    color = TextWhite
                )
            }

            Text(
                text = pack.subtitle,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                color = TextMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            ArcadeButton(
                onClick = onClick,
                enabled = !isGemPack || canAffordGems,
                topColor = if (isGemPack) GreenAction else ArcadeBlueBright,
                bottomColor = if (isGemPack) GreenActionDeep else Color(0xFF1E40AF),
                contentColor = TextWhite,
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp),
                modifier = Modifier.fillMaxWidth(),
                testTag = "shop_${pack.id}_button"
            ) {
                if (isGemPack) {
                    GemIcon(Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                }
                Text(
                    text = displayedPrice,
                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.5.sp),
                    maxLines = 1
                )
            }
        }
    }
}
