package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brawl Stars / Arcade Vibrant Palette
val ArcadeNavyDeep = Color(0xFF0A1428)
val ArcadeNavy = Color(0xFF10203F)
val ArcadeBluePanel = Color(0xFF193260)
val ArcadeBlueCard = Color(0xFF21407A)
val ArcadeBlueBright = Color(0xFF2563EB)
val ArcadeSkyAccent = Color(0xFF38BDF8)

val GoldPrimary = Color(0xFFFFC800)
val GoldDeep = Color(0xFFE68A00)
val GoldHighlight = Color(0xFFFFE566)

val GreenAction = Color(0xFF22C55E)
val GreenActionDeep = Color(0xFF15803D)
val GemGreen = Color(0xFF10E06A)
val CentellaCyan = Color(0xFF00D4FF)
val BombSlate = Color(0xFF334155)

val CrimsonDanger = Color(0xFFEF4444)
val CrimsonDeep = Color(0xFF991B1B)
val ElixirPurple = Color(0xFFD946EF)
val ElixirPurpleDeep = Color(0xFF86198F)

val SandLight = Color(0xFFE9C082)
val SandMid = Color(0xFFD9A760)
val SandDark = Color(0xFFB8813D)
val CanyonRock = Color(0xFF8C5230)

// Rarity Colors
val RarityStandard = Color(0xFF64748B)
val RarityEspecial = Color(0xFF2563EB)
val RarityEpica = Color(0xFF9333EA)
val RarityMitica = Color(0xFFE11D48)
val RarityLegendaria = Color(0xFFF59E0B)
val RarityCentella = Color(0xFF06B6D4)

val TextWhite = Color(0xFFF8FAFC)
val TextMuted = Color(0xFFCBD5E1)
val OutlineDark = Color(0xFF091122)
