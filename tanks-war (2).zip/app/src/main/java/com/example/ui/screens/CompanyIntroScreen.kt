package com.example.ui.screens

import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.view.Surface
import android.view.TextureView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import kotlinx.coroutines.delay

/**
 * Full-screen widescreen company logo intro video screen ("Utility Apps") shown at app launch
 * before entering the Tanks War lobby. Plays res/raw/utility_apps_intro.mp4 cleanly
 * centered on a dark futuristic background in landscape mode.
 */
@Composable
fun CompanyIntroScreen(
    onFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentOnFinished by rememberUpdatedState(onFinished)

    var videoAspectRatio by remember { mutableFloatStateOf(16f / 9f) }
    var isVideoReady by remember { mutableStateOf(false) }
    var completedOnce by remember { mutableStateOf(false) }

    fun triggerFinish() {
        if (!completedOnce) {
            completedOnce = true
            currentOnFinished()
        }
    }

    val mediaPlayerHolder = remember { arrayOfNulls<MediaPlayer>(1) }
    val surfaceHolder = remember { arrayOfNulls<Surface>(1) }

    // Safety fallback timeout in case a headless/test environment lacks hardware video decoding
    LaunchedEffect(Unit) {
        delay(6500L)
        triggerFinish()
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                mediaPlayerHolder[0]?.let { mp ->
                    if (mp.isPlaying) mp.stop()
                    mp.release()
                }
            } catch (_: Throwable) {
            } finally {
                mediaPlayerHolder[0] = null
            }
            try {
                surfaceHolder[0]?.release()
            } catch (_: Throwable) {
            } finally {
                surfaceHolder[0] = null
            }
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF030712)),
        contentAlignment = Alignment.Center
    ) {
        val screenRatio = if (maxHeight.value > 0f) maxWidth.value / maxHeight.value else 16f / 9f
        val videoContainerModifier = if (screenRatio > videoAspectRatio) {
            Modifier
                .fillMaxHeight()
                .aspectRatio(videoAspectRatio, matchHeightConstraintsFirst = true)
        } else {
            Modifier
                .fillMaxWidth()
                .aspectRatio(videoAspectRatio, matchHeightConstraintsFirst = false)
        }

        Box(
            modifier = videoContainerModifier,
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = if (isVideoReady) 1f else 0f },
                factory = { ctx ->
                    TextureView(ctx).apply {
                        isOpaque = false
                        surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                            override fun onSurfaceTextureAvailable(
                                surfaceTexture: SurfaceTexture,
                                width: Int,
                                height: Int
                            ) {
                                val surface = Surface(surfaceTexture)
                                surfaceHolder[0] = surface
                                val mp = MediaPlayer()
                                mediaPlayerHolder[0] = mp
                                try {
                                    val afd = context.resources.openRawResourceFd(R.raw.utility_apps_intro)
                                    mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                                    afd.close()
                                    mp.setSurface(surface)
                                    mp.setOnVideoSizeChangedListener { _, vw, vh ->
                                        if (vw > 0 && vh > 0) {
                                            videoAspectRatio = vw.toFloat() / vh.toFloat()
                                        }
                                    }
                                    mp.setOnInfoListener { _, what, _ ->
                                        if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) {
                                            isVideoReady = true
                                        }
                                        false
                                    }
                                    mp.setOnPreparedListener { player ->
                                        player.start()
                                        isVideoReady = true
                                    }
                                    mp.setOnCompletionListener {
                                        triggerFinish()
                                    }
                                    mp.setOnErrorListener { _, _, _ ->
                                        triggerFinish()
                                        true
                                    }
                                    mp.prepareAsync()
                                } catch (_: Throwable) {
                                    triggerFinish()
                                }
                            }

                            override fun onSurfaceTextureSizeChanged(
                                surfaceTexture: SurfaceTexture,
                                width: Int,
                                height: Int
                            ) = Unit

                            override fun onSurfaceTextureDestroyed(surfaceTexture: SurfaceTexture): Boolean {
                                try {
                                    mediaPlayerHolder[0]?.let { mp ->
                                        if (mp.isPlaying) mp.stop()
                                        mp.release()
                                    }
                                } catch (_: Throwable) {
                                } finally {
                                    mediaPlayerHolder[0] = null
                                }
                                try {
                                    surfaceHolder[0]?.release()
                                } catch (_: Throwable) {
                                } finally {
                                    surfaceHolder[0] = null
                                }
                                return true
                            }

                            override fun onSurfaceTextureUpdated(surfaceTexture: SurfaceTexture) {
                                if (!isVideoReady) isVideoReady = true
                            }
                        }
                    }
                }
            )
        }

        TextButton(
            onClick = { triggerFinish() },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .minimumInteractiveComponentSize()
                .testTag("skip_company_intro_button")
        ) {
            Text(
                text = "Saltar",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                ),
                color = Color(0xFFCBD5E1)
            )
        }
    }
}
