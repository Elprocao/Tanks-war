package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.legal.LegalConfig
import com.example.legal.openExternalLegalUrl
import com.example.legal.openSupportEmail
import com.example.model.BattleMode
import com.example.model.EconomyRules
import com.example.model.GameStateSnapshot
import com.example.model.TankRarity
import com.example.ui.components.ArcadeButton
import com.example.ui.components.BombIcon
import com.example.ui.components.CentellaCoinIcon
import com.example.ui.components.CrateArcadeIcon
import com.example.ui.components.GemIcon
import com.example.ui.components.LimitsArcadeIcon
import com.example.ui.components.ModeSurvivalArcadeIcon
import com.example.ui.components.ProbabilitiesArcadeIcon
import com.example.ui.components.RarityPill
import com.example.ui.components.SettingsArcadeIcon
import com.example.ui.components.TankPortraitArt
import com.example.ui.theme.ArcadeBlueBright
import com.example.ui.theme.ArcadeBlueCard
import com.example.ui.theme.ArcadeBluePanel
import com.example.ui.theme.ArcadeNavyDeep
import com.example.ui.theme.CentellaCyan
import com.example.ui.theme.CrimsonDanger
import com.example.ui.theme.GemGreen
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GreenAction
import com.example.ui.theme.GreenActionDeep
import com.example.ui.theme.OutlineDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.CrateOpeningResult

@Composable
fun CrateResultDialog(
    result: CrateOpeningResult,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.widthIn(max = 540.dp),
            shape = RoundedCornerShape(22.dp),
            color = ArcadeBluePanel,
            border = BorderStroke(3.dp, result.rarity.accentColor),
            shadowElevation = 12.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                TankPortraitArt(
                    tank = result.tank,
                    cornerRadius = 18.dp,
                    borderWidth = 3.dp,
                    modifier = Modifier.size(136.dp)
                )
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CrateArcadeIcon(Modifier.size(30.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("¡BOTÍN DE CAJA!", style = MaterialTheme.typography.titleLarge, color = GoldPrimary)
                    }
                    RarityPill(rarity = result.rarity)
                    Text(result.tank.name, style = MaterialTheme.typography.headlineMedium, color = TextWhite)
                    Text(
                        text = if (result.wasAlreadyOwned) {
                            "Ya tenías este tanque: +${result.bonusBombas} Bombas extra"
                        } else {
                            "¡Desbloqueado! +${result.bonusBombas} Bombas"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted
                    )
                    ArcadeButton(
                        onClick = onDismiss,
                        topColor = GoldPrimary,
                        bottomColor = GoldDeep,
                        contentColor = OutlineDark,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("¡GENIAL!", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }
}

@Composable
fun RarityProbabilitiesDialog(onDismiss: () -> Unit) {
    val rows = listOf(
        TankRarity.ESPECIAL,
        TankRarity.EPICA,
        TankRarity.MITICA,
        TankRarity.LEGENDARIA,
        TankRarity.CENTELLA,
        TankRarity.ESTANDAR
    )
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.widthIn(max = 580.dp),
            shape = RoundedCornerShape(20.dp),
            color = ArcadeBluePanel,
            border = BorderStroke(2.5.dp, GoldPrimary)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ProbabilitiesArcadeIcon(Modifier.size(26.dp))
                    Text(
                        text = "RAREZAS Y PROBABILIDADES (100%)",
                        style = MaterialTheme.typography.titleLarge,
                        color = GoldPrimary
                    )
                }
                Text(
                    text = "Bomba referencia: 7,5 cas/seg | Daño base: 500 | Mapa: 30x15",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMuted
                )
                rows.chunked(2).forEach { pair ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        pair.forEach { r ->
                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                color = ArcadeNavyDeep,
                                border = BorderStroke(1.5.dp, r.accentColor)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "${r.shortCode} - ${r.displayName}",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = r.accentColor
                                        )
                                        Text(
                                            text = "${r.probabilityPercent}%",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = TextWhite
                                        )
                                    }
                                    Text(
                                        text = "${r.speedRangeLabel} | ${r.hpRangeLabel} HP\nCoste: ${r.costRangeLabel}",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp),
                                        color = TextWhite
                                    )
                                }
                            }
                        }
                    }
                }
                ArcadeButton(
                    onClick = onDismiss,
                    topColor = ArcadeBlueBright,
                    bottomColor = Color(0xFF1E40AF),
                    contentColor = TextWhite,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("CERRAR", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
fun DailyLimitsDialog(
    snapshot: GameStateSnapshot,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.widthIn(max = 520.dp),
            shape = RoundedCornerShape(20.dp),
            color = ArcadeBluePanel,
            border = BorderStroke(2.5.dp, CentellaCyan)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LimitsArcadeIcon(Modifier.size(26.dp))
                        Text("LÍMITES DIARIOS Y ESTADÍSTICAS", style = MaterialTheme.typography.titleLarge, color = GoldPrimary)
                    }
                    Text("Vic: ${snapshot.totalWins} | Part: ${snapshot.totalMatches}", style = MaterialTheme.typography.labelSmall, color = TextWhite)
                }
                DailyLimitProgressRow(
                    title = "Fichas Centella hoy (máx. 100 fc/día)",
                    current = snapshot.dailyFcEarned,
                    max = EconomyRules.MAX_DAILY_FC,
                    unit = "fc",
                    barColor = CentellaCyan,
                    icon = { CentellaCoinIcon(Modifier.size(16.dp)) }
                )
                DailyLimitProgressRow(
                    title = "Gemas de batalla hoy (máx. 400 g/día)",
                    current = snapshot.dailyMatchGemsEarned,
                    max = EconomyRules.MAX_DAILY_MATCH_GEMS,
                    unit = "g",
                    barColor = GemGreen,
                    icon = { GemIcon(Modifier.size(16.dp)) }
                )
                DailyLimitProgressRow(
                    title = "Gemas bonus/anuncios hoy (máx. 100 g/día)",
                    current = snapshot.dailyBonusGemsEarned,
                    max = EconomyRules.MAX_DAILY_BONUS_GEMS,
                    unit = "g",
                    barColor = GoldPrimary,
                    icon = { Icon(Icons.Default.Bolt, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp)) }
                )
                Text(
                    text = "Anuncios opcionales vistos hoy: ${snapshot.dailyAdsWatched}/${EconomyRules.MAX_DAILY_ADS}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMuted
                )
                ArcadeButton(
                    onClick = onDismiss,
                    topColor = ArcadeBlueBright,
                    bottomColor = Color(0xFF1E40AF),
                    contentColor = TextWhite,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("CERRAR", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
fun SettingsDialog(
    snapshot: GameStateSnapshot,
    playerDisplayName: String,
    playerEmail: String?,
    isRealMondayOrSimulated: Boolean,
    onToggleSimulateMonday: (Boolean) -> Unit,
    onToggleSound: (Boolean) -> Unit,
    onResetDailyLimits: () -> Unit,
    onResetAllProgress: () -> Unit,
    onSignOut: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.widthIn(max = 540.dp),
            shape = RoundedCornerShape(20.dp),
            color = ArcadeBluePanel,
            border = BorderStroke(2.5.dp, GoldPrimary)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("AJUSTES Y CUENTA GOOGLE", style = MaterialTheme.typography.titleLarge, color = GoldPrimary)

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = ArcadeNavyDeep,
                    border = BorderStroke(1.5.dp, CentellaCyan)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(playerDisplayName, style = MaterialTheme.typography.titleMedium, color = TextWhite)
                            if (!playerEmail.isNullOrBlank()) {
                                Text(playerEmail, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            }
                        }
                        ArcadeButton(
                            onClick = {
                                onDismiss()
                                onSignOut()
                            },
                            topColor = CrimsonDanger,
                            bottomColor = Color(0xFF991B1B),
                            contentColor = TextWhite,
                            testTag = "sign_out_button"
                        ) {
                            Text("CERRAR SESIÓN", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Simular Lunes (Oferta Semanal)", style = MaterialTheme.typography.titleMedium, color = TextWhite)
                        Text(
                            text = if (isRealMondayOrSimulated) "Estado actual: Lunes activo (150 fc)" else "Estado actual: No es lunes",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CentellaCyan
                        )
                    }
                    Switch(
                        checked = snapshot.simulateMondayForTesting,
                        onCheckedChange = onToggleSimulateMonday
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Efectos visuales / sonido", style = MaterialTheme.typography.titleMedium, color = TextWhite)
                    Switch(
                        checked = snapshot.soundEnabled,
                        onCheckedChange = onToggleSound
                    )
                }

                HorizontalDivider(color = Color(0xFF335599))

                Text(
                    text = "Límites diarios: ${snapshot.dailyFcEarned}/${EconomyRules.MAX_DAILY_FC} fc | ${snapshot.dailyMatchGemsEarned}/${EconomyRules.MAX_DAILY_MATCH_GEMS} g batalla | ${snapshot.dailyAdsWatched}/${EconomyRules.MAX_DAILY_ADS} ADs",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMuted
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ArcadeButton(
                        onClick = onResetDailyLimits,
                        topColor = ArcadeBlueBright,
                        bottomColor = Color(0xFF1E40AF),
                        contentColor = TextWhite,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("REINICIAR LÍMITES", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                    }

                    ArcadeButton(
                        onClick = onResetAllProgress,
                        topColor = CrimsonDanger,
                        bottomColor = Color(0xFF991B1B),
                        contentColor = TextWhite,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("REINICIAR TODO", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                    }
                }

                HorizontalDivider(color = Color(0xFF335599))

                Text(
                    text = "LEGAL Y SOPORTE (${LegalConfig.DEVELOPER_NAME.uppercase()})",
                    style = MaterialTheme.typography.labelLarge,
                    color = GoldPrimary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ArcadeButton(
                        onClick = { openExternalLegalUrl(context, LegalConfig.PRIVACY_POLICY_URL) },
                        topColor = ArcadeBlueCard,
                        bottomColor = ArcadeNavyDeep,
                        contentColor = CentellaCyan,
                        modifier = Modifier.weight(1f),
                        testTag = "settings_privacy_button"
                    ) {
                        Text("PRIVACIDAD", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                    }
                    ArcadeButton(
                        onClick = { openExternalLegalUrl(context, LegalConfig.TERMS_OF_SERVICE_URL) },
                        topColor = ArcadeBlueCard,
                        bottomColor = ArcadeNavyDeep,
                        contentColor = CentellaCyan,
                        modifier = Modifier.weight(1f),
                        testTag = "settings_tos_button"
                    ) {
                        Text("TÉRMINOS (ToS)", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ArcadeButton(
                        onClick = { openExternalLegalUrl(context, LegalConfig.DATA_DELETION_URL) },
                        topColor = ArcadeBlueCard,
                        bottomColor = ArcadeNavyDeep,
                        contentColor = TextWhite,
                        modifier = Modifier.weight(1f),
                        testTag = "settings_data_deletion_button"
                    ) {
                        Text("ELIMINACIÓN DATOS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                    }
                    ArcadeButton(
                        onClick = { openSupportEmail(context) },
                        topColor = ArcadeBlueCard,
                        bottomColor = ArcadeNavyDeep,
                        contentColor = GoldPrimary,
                        modifier = Modifier.weight(1f),
                        testTag = "settings_support_email_button"
                    ) {
                        Text("SOPORTE EMAIL", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                    }
                }

                Text(
                    text = "Contacto oficial: ${LegalConfig.SUPPORT_EMAIL}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                    color = TextMuted
                )

                ArcadeButton(
                    onClick = onDismiss,
                    topColor = GoldPrimary,
                    bottomColor = GoldDeep,
                    contentColor = OutlineDark,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("LISTO", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
fun GameModesDialog(
    selectedMode: BattleMode,
    onSelectMode: (BattleMode) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.widthIn(max = 580.dp),
            shape = RoundedCornerShape(20.dp),
            color = ArcadeBluePanel,
            border = BorderStroke(2.5.dp, CentellaCyan),
            shadowElevation = 12.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ModeSurvivalArcadeIcon(Modifier.size(28.dp))
                    Text(
                        text = "MODOS DE JUEGO (ARENA 30x15)",
                        style = MaterialTheme.typography.titleLarge,
                        color = GoldPrimary
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    BattleMode.entries.forEach { mode ->
                        val isSelected = mode == selectedMode
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .clickable {
                                    onSelectMode(mode)
                                    onDismiss()
                                },
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSelected) ArcadeBlueCard else ArcadeNavyDeep,
                            border = BorderStroke(if (isSelected) 3.dp else 2.dp, if (isSelected) GoldPrimary else OutlineDark)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    ModeSurvivalArcadeIcon(Modifier.size(28.dp))
                                    Surface(
                                        color = if (isSelected) GoldPrimary else CentellaCyan,
                                        shape = RoundedCornerShape(6.dp),
                                        border = BorderStroke(1.5.dp, OutlineDark)
                                    ) {
                                        Text(
                                            text = if (isSelected) "ACTIVO" else mode.badge,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                                            color = OutlineDark,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = mode.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (isSelected) GoldPrimary else TextWhite
                                )
                                Text(
                                    text = mode.subtitle,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }

                ArcadeButton(
                    onClick = onDismiss,
                    topColor = ArcadeBlueBright,
                    bottomColor = Color(0xFF1E40AF),
                    contentColor = TextWhite,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("CERRAR", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}
