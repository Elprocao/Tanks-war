package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TanksWarColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = OutlineDark,
    primaryContainer = ArcadeBlueCard,
    onPrimaryContainer = TextWhite,
    secondary = ArcadeSkyAccent,
    onSecondary = OutlineDark,
    secondaryContainer = ArcadeBluePanel,
    onSecondaryContainer = TextWhite,
    tertiary = GreenAction,
    onTertiary = Color.White,
    background = ArcadeNavyDeep,
    onBackground = TextWhite,
    surface = ArcadeNavy,
    onSurface = TextWhite,
    surfaceVariant = ArcadeBluePanel,
    onSurfaceVariant = TextMuted,
    error = CrimsonDanger,
    onError = Color.White,
    outline = Color(0xFF335599)
)

@Composable
fun TanksWarTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TanksWarColorScheme,
        typography = TanksWarTypography,
        content = content
    )
}
