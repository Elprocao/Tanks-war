package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameCatalog
import com.example.model.AppTab
import com.example.model.GameStateSnapshot
import com.example.ui.theme.ArcadeBlueBright
import com.example.ui.theme.ArcadeBlueCard
import com.example.ui.theme.ArcadeNavyDeep
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.OutlineDark
import com.example.ui.theme.TextWhite

/**
 * Brawl-style Horizontal Lobby Top HUD (placed inside HomeScreen Column so it NEVER overlaps side rails):
 * Top-Left: Active tank avatar + Wins/Rank trophy progress bar + Quick Crate button.
 * Top-Right: 3 currencies (Bombas, Gemas, Fichas Centella) + Settings gear button.
 */
@Composable
fun LobbyTopBar(
    snapshot: GameStateSnapshot,
    onOpenTanks: () -> Unit,
    onOpenCrate: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeTank = GameCatalog.tankById(snapshot.activeTankId)
    val level = snapshot.tankLevels[activeTank.id] ?: 1
    val nextMilestone = ((snapshot.totalWins / 5) + 1) * 5
    val winProgress = ((snapshot.totalWins % 5) / 5f).coerceIn(0f, 1f)

    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // TOP-LEFT: Profile / Active Tank + Wins Road + Crate Shortcut
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(onClick = onOpenTanks),
                color = Color(0xFF0E2144).copy(alpha = 0.94f),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(2.dp, OutlineDark),
                shadowElevation = 6.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(id = tankDrawableRes(activeTank)),
                        contentDescription = activeTank.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(7.dp))
                            .border(1.5.dp, activeTank.rarity.accentColor, RoundedCornerShape(7.dp))
                    )
                    Spacer(Modifier.width(7.dp))
                    Column {
                        Text(
                            text = "TANKS WAR",
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 12.sp),
                            color = GoldPrimary,
                            maxLines = 1
                        )
                        Text(
                            text = "${activeTank.name} Nv.$level",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = TextWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Surface(
                color = Color(0xFF0E2144).copy(alpha = 0.94f),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(2.dp, OutlineDark),
                shadowElevation = 6.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TrophyArcadeIcon(Modifier.size(19.dp))
                    Column(modifier = Modifier.width(72.dp)) {
                        Text(
                            text = "${snapshot.totalWins}/$nextMilestone VIC.",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp, fontWeight = FontWeight.Bold),
                            color = TextWhite
                        )
                        Spacer(Modifier.height(2.dp))
                        LinearProgressIndicator(
                            progress = { winProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .border(1.dp, OutlineDark, RoundedCornerShape(3.dp)),
                            color = GoldPrimary,
                            trackColor = ArcadeNavyDeep
                        )
                    }
                }
            }

            Surface(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(onClick = onOpenCrate)
                    .testTag("top_crate_shortcut"),
                color = Color(0xFF1E3A8A),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(2.dp, GoldPrimary),
                shadowElevation = 6.dp
            ) {
                Box(contentAlignment = Alignment.Center) {
                    CrateArcadeIcon(Modifier.size(28.dp))
                }
            }
        }

        // TOP-RIGHT: 3 Currencies + Settings Gear Button
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            CurrencyBadge(
                label = "b",
                valueText = snapshot.bombas.toString(),
                icon = { BombIcon(Modifier.size(18.dp)) },
                modifier = Modifier.testTag("currency_bombas")
            )
            CurrencyBadge(
                label = "g",
                valueText = snapshot.gemas.toString(),
                icon = { GemIcon(Modifier.size(18.dp)) },
                modifier = Modifier.testTag("currency_gemas")
            )
            CurrencyBadge(
                label = "fc",
                valueText = snapshot.fichasCentella.toString(),
                icon = { CentellaCoinIcon(Modifier.size(18.dp)) },
                modifier = Modifier.testTag("currency_fc")
            )
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .size(40.dp)
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(10.dp))
                    .background(ArcadeBlueCard)
                    .border(2.dp, OutlineDark, RoundedCornerShape(10.dp))
                    .testTag("settings_button")
            ) {
                SettingsArcadeIcon(Modifier.size(22.dp))
            }
        }
    }
}

/**
 * Clean Landscape Sub-Screen Header (Tanks, Shop, Missions):
 * Only Back Button + Screen Title on Left | 3 Currencies + Settings on Right (no extra nav tab bar).
 */
@Composable
fun SubScreenTopBar(
    currentTab: AppTab,
    snapshot: GameStateSnapshot,
    onBackHome: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val screenTitle = when (currentTab) {
        AppTab.TANKS -> "GARAJE DE TANQUES"
        AppTab.SHOP -> "TIENDA"
        AppTab.MISSIONS -> "MISIONES Y PASE DE GUERRA"
        else -> "TANKS WAR"
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color(0xFF0E2144),
        border = BorderStroke(2.dp, OutlineDark),
        shadowElevation = 6.dp
    ) {
        Row(
            modifier = Modifier
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.displayCutout)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .size(width = 48.dp, height = 38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(onClick = onBackHome)
                        .testTag("back_to_home_button"),
                    color = ArcadeBlueBright,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(2.dp, OutlineDark)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Volver a Inicio",
                            tint = TextWhite,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                when (currentTab) {
                    AppTab.TANKS -> TankArcadeIcon(Modifier.size(26.dp))
                    AppTab.SHOP -> ShopArcadeIcon(Modifier.size(26.dp))
                    AppTab.MISSIONS -> MissionsArcadeIcon(Modifier.size(26.dp))
                    else -> Unit
                }

                Text(
                    text = screenTitle,
                    style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp),
                    color = GoldPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                CurrencyBadge(
                    label = "b",
                    valueText = snapshot.bombas.toString(),
                    icon = { BombIcon(Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("currency_bombas")
                )
                CurrencyBadge(
                    label = "g",
                    valueText = snapshot.gemas.toString(),
                    icon = { GemIcon(Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("currency_gemas")
                )
                CurrencyBadge(
                    label = "fc",
                    valueText = snapshot.fichasCentella.toString(),
                    icon = { CentellaCoinIcon(Modifier.size(16.dp)) },
                    modifier = Modifier.testTag("currency_fc")
                )
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .size(38.dp)
                        .minimumInteractiveComponentSize()
                        .clip(RoundedCornerShape(10.dp))
                        .background(ArcadeBlueCard)
                        .border(2.dp, OutlineDark, RoundedCornerShape(10.dp))
                        .testTag("settings_button")
                ) {
                    SettingsArcadeIcon(Modifier.size(20.dp))
                }
            }
        }
    }
}
