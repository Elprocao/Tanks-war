package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TankRarity
import com.example.ui.theme.CentellaCyan
import com.example.ui.theme.GemGreen
import com.example.ui.theme.OutlineDark
import com.example.ui.theme.TextWhite

@Composable
fun BombIcon(modifier: Modifier = Modifier.size(22.dp)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val center = Offset(w * 0.46f, h * 0.58f)
        val radius = w * 0.34f

        val fusePath = Path().apply {
            moveTo(center.x + radius * 0.4f, center.y - radius * 0.75f)
            quadraticTo(w * 0.76f, h * 0.14f, w * 0.86f, h * 0.24f)
        }
        drawPath(
            path = fusePath,
            color = Color(0xFFD97706),
            style = Stroke(width = w * 0.09f, cap = StrokeCap.Round)
        )

        drawCircle(color = Color(0xFFFFE566), radius = w * 0.11f, center = Offset(w * 0.86f, h * 0.22f))
        drawCircle(color = Color(0xFFFF6B00), radius = w * 0.055f, center = Offset(w * 0.86f, h * 0.22f))

        drawRoundRect(
            color = Color(0xFF475569),
            topLeft = Offset(center.x - radius * 0.32f, center.y - radius * 1.12f),
            size = androidx.compose.ui.geometry.Size(radius * 0.64f, radius * 0.32f)
        )

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF475569), Color(0xFF1E293B), Color(0xFF090D16)),
                center = Offset(center.x - radius * 0.3f, center.y - radius * 0.3f),
                radius = radius * 1.4f
            ),
            radius = radius,
            center = center
        )
        drawCircle(
            color = OutlineDark,
            radius = radius,
            center = center,
            style = Stroke(width = w * 0.08f)
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.6f),
            radius = radius * 0.24f,
            center = Offset(center.x - radius * 0.34f, center.y - radius * 0.34f)
        )
    }
}

@Composable
fun GemIcon(modifier: Modifier = Modifier.size(22.dp)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val outer = Path().apply {
            moveTo(w * 0.50f, h * 0.06f)
            lineTo(w * 0.90f, h * 0.30f)
            lineTo(w * 0.82f, h * 0.78f)
            lineTo(w * 0.50f, h * 0.94f)
            lineTo(w * 0.18f, h * 0.78f)
            lineTo(w * 0.10f, h * 0.30f)
            close()
        }
        drawPath(
            path = outer,
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFF6EE7B7), GemGreen, Color(0xFF047857)),
                start = Offset(0f, 0f),
                end = Offset(w, h)
            )
        )
        val innerFacet = Path().apply {
            moveTo(w * 0.50f, h * 0.22f)
            lineTo(w * 0.72f, h * 0.36f)
            lineTo(w * 0.66f, h * 0.68f)
            lineTo(w * 0.50f, h * 0.78f)
            lineTo(w * 0.34f, h * 0.68f)
            lineTo(w * 0.28f, h * 0.36f)
            close()
        }
        drawPath(path = innerFacet, color = Color(0xFFA7F3D0).copy(alpha = 0.55f))
        drawPath(
            path = outer,
            color = OutlineDark,
            style = Stroke(width = w * 0.08f, join = StrokeJoin.Round)
        )
    }
}

@Composable
fun CentellaCoinIcon(modifier: Modifier = Modifier.size(22.dp)) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val center = Offset(w * 0.5f, h * 0.5f)
        val radius = w * 0.42f

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFA5F3FC), CentellaCyan, Color(0xFF0369A1)),
                center = Offset(w * 0.35f, h * 0.35f),
                radius = radius * 1.5f
            ),
            radius = radius,
            center = center
        )
        drawCircle(
            color = OutlineDark,
            radius = radius,
            center = center,
            style = Stroke(width = w * 0.08f)
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.5f),
            radius = radius * 0.72f,
            center = center,
            style = Stroke(width = w * 0.05f)
        )
        val bolt = Path().apply {
            moveTo(w * 0.56f, h * 0.20f)
            lineTo(w * 0.35f, h * 0.52f)
            lineTo(w * 0.50f, h * 0.52f)
            lineTo(w * 0.44f, h * 0.80f)
            lineTo(w * 0.66f, h * 0.46f)
            lineTo(w * 0.51f, h * 0.46f)
            close()
        }
        drawPath(path = bolt, color = Color(0xFFFFFBEB))
        drawPath(
            path = bolt,
            color = Color(0xFF0C4A6E),
            style = Stroke(width = w * 0.04f, join = StrokeJoin.Round)
        )
    }
}

/**
 * Brawl Stars style chunky beveled button with glossy top shine and thick dark border.
 * Uses propagateMinConstraints so explicit widths (fillMaxWidth/weight/width) stretch properly,
 * while unconstrained buttons wrap their content cleanly without crushing sibling Views in Rows.
 */
@Composable
fun ArcadeButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    topColor: Color,
    bottomColor: Color,
    contentColor: Color = OutlineDark,
    cornerRadius: Dp = 14.dp,
    contentPadding: PaddingValues = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
    testTag: String? = null,
    content: @Composable RowScope.() -> Unit
) {
    val effectiveTop = if (enabled) topColor else Color(0xFF475569)
    val effectiveBottom = if (enabled) bottomColor else Color(0xFF334155)
    val effectiveContent = if (enabled) contentColor else Color(0xFFCBD5E1)
    val shape = RoundedCornerShape(cornerRadius)

    val taggedModifier = if (testTag != null) modifier.testTag(testTag) else modifier

    Box(
        modifier = taggedModifier
            .minimumInteractiveComponentSize()
            .defaultMinSize(minHeight = 46.dp)
            .shadow(elevation = if (enabled) 6.dp else 0.dp, shape = shape)
            .clip(shape)
            .background(effectiveBottom)
            .border(2.5.dp, OutlineDark, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(bottom = 5.dp),
        propagateMinConstraints = true
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape((cornerRadius - 2.dp).coerceAtLeast(2.dp)))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = if (enabled) 0.28f else 0.05f),
                            effectiveTop,
                            effectiveTop
                        )
                    )
                ),
            contentAlignment = Alignment.Center,
            propagateMinConstraints = true
        ) {
            Row(
                modifier = Modifier.padding(contentPadding),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                androidx.compose.runtime.CompositionLocalProvider(
                    androidx.compose.material3.LocalContentColor provides effectiveContent
                ) {
                    content()
                }
            }
        }
    }
}

@Composable
fun BrawlSectionRibbon(
    title: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.graphicsLayer { rotationZ = -1.2f },
        color = accentColor,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(2.5.dp, OutlineDark),
        shadowElevation = 5.dp
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge.copy(
                fontSize = 15.sp,
                letterSpacing = 0.6.sp
            ),
            color = TextWhite,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
        )
    }
}

@Composable
fun RarityPill(rarity: TankRarity, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = rarity.accentColor,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(2.dp, OutlineDark)
    ) {
        Text(
            text = "${rarity.shortCode.uppercase()} - ${rarity.displayName.uppercase()}",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.ExtraBold,
                fontSize = 10.sp
            ),
            color = TextWhite,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun CurrencyBadge(
    label: String,
    valueText: String,
    icon: @Composable () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = Color(0xFF0A162D),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(2.dp, OutlineDark),
        shadowElevation = 3.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            icon()
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = valueText,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp
                ),
                color = TextWhite,
                maxLines = 1
            )
            if (label.isNotEmpty()) {
                Spacer(modifier = Modifier.width(2.dp))
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = Color(0xFF93C5FD),
                    maxLines = 1
                )
            }
        }
    }
}
