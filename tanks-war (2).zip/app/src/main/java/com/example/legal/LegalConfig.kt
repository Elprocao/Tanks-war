package com.example.legal

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object LegalConfig {
    const val DEVELOPER_NAME = "Utility Apps"
    const val SUPPORT_EMAIL = "utilityappssupport@gmail.com"

    const val PRIVACY_POLICY_URL =
        "https://docs.google.com/document/d/1chFqpCrA0JbZniEBfpltclP9fvXFWgyjzUeKuVujg2s/edit?usp=sharing"
    const val TERMS_OF_SERVICE_URL =
        "https://docs.google.com/document/d/1sWbzbB2dd1l67v3p_zjvpzb0L7L2jxcksM840LuyJhs/edit?usp=sharing"
    const val DATA_DELETION_URL =
        "https://docs.google.com/document/d/1WVC5OmC6rURTFSviG3MTuNRuy0-F__dS1egSJnpsWO8/edit?usp=sharing"
}

object LegalConsentPrefs {
    private const val PREFS_NAME = "tanks_war_legal_prefs"
    private const val KEY_ACCEPTED_V1 = "legal_accepted_v1"
    private const val KEY_ACCEPTED_AT = "legal_accepted_at_ms"

    fun isAccepted(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_ACCEPTED_V1, false)
    }

    fun setAccepted(context: Context, accepted: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_ACCEPTED_V1, accepted)
            .putLong(KEY_ACCEPTED_AT, if (accepted) System.currentTimeMillis() else 0L)
            .apply()
    }
}

fun openExternalLegalUrl(context: Context, url: String) {
    if (!url.startsWith("https://")) {
        Toast.makeText(context, "Enlace no válido", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (_: Exception) {
        Toast.makeText(
            context,
            "No se encontró navegador para abrir el documento. Soporte: ${LegalConfig.SUPPORT_EMAIL}",
            Toast.LENGTH_LONG
        ).show()
    }
}

fun openSupportEmail(context: Context) {
    try {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:${LegalConfig.SUPPORT_EMAIL}")
            putExtra(Intent.EXTRA_SUBJECT, "Soporte Tanks War - Utility Apps")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (_: Exception) {
        Toast.makeText(
            context,
            "Contacto de soporte: ${LegalConfig.SUPPORT_EMAIL}",
            Toast.LENGTH_LONG
        ).show()
    }
}
