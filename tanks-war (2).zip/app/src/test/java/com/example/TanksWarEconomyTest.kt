package com.example

import com.example.data.GameCatalog
import com.example.model.EconomyRules
import com.example.model.ShopPackKind
import com.example.model.TankRarity
import com.example.viewmodel.SurvivalMapSpec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.hypot
import kotlin.math.max

class TanksWarEconomyTest {

    @Test
    fun rarityProbabilitiesSumTo100WithExactSpecValues() {
        val total = TankRarity.entries.sumOf { it.probabilityPercent }
        assertEquals(100.0, total, 0.0001)
        assertEquals(2.5, TankRarity.ESPECIAL.probabilityPercent, 0.0001)
        assertEquals(7.5, TankRarity.EPICA.probabilityPercent, 0.0001)
        assertEquals(10.0, TankRarity.MITICA.probabilityPercent, 0.0001)
        assertEquals(13.0, TankRarity.LEGENDARIA.probabilityPercent, 0.0001)
        assertEquals(17.0, TankRarity.CENTELLA.probabilityPercent, 0.0001)
    }

    @Test
    fun upgradeCostsScaleBy1Point5From50UpToLevel10() {
        assertEquals(50, EconomyRules.upgradeCostBombas(1))
        assertEquals(75, EconomyRules.upgradeCostBombas(2))
        assertEquals(113, EconomyRules.upgradeCostBombas(3))
        assertEquals(0, EconomyRules.upgradeCostBombas(EconomyRules.MAX_TANK_LEVEL))
    }

    @Test
    fun battleMapAndLimitsMatchSpec() {
        assertEquals(30, EconomyRules.MAP_WIDTH_TILES)
        assertEquals(15, EconomyRules.MAP_HEIGHT_TILES)
        assertEquals(120, EconomyRules.MATCH_DURATION_SECONDS)
        assertEquals(7.5f, EconomyRules.BASE_BOMB_SPEED_TILES_PER_SEC, 0.001f)
        assertEquals(500, EconomyRules.BASE_BOMB_DAMAGE)
        assertEquals(100, EconomyRules.MAX_DAILY_FC)
        assertEquals(400, EconomyRules.MAX_DAILY_MATCH_GEMS)
        assertEquals(100, EconomyRules.MAX_DAILY_BONUS_GEMS)
        assertEquals(4, EconomyRules.MAX_DAILY_ADS)
        assertEquals(1500, EconomyRules.BATTLE_PASS_COST_GEMS)
    }

    @Test
    fun shopContainsAllRequiredPacksAndOptionalAd() {
        val packs = GameCatalog.shopPacks
        assertEquals(7, packs.size)
        assertTrue(packs.any { it.kind == ShopPackKind.OPTIONAL_AD })
        assertTrue(packs.any { it.bombsGranted == 30 && it.gemCost == 100 })
        assertTrue(packs.any { it.bombsGranted == 100 && it.priceLabel == "2,49 €" })
        assertTrue(packs.any { it.bombsGranted == 250 && it.priceLabel == "4,99 €" })
        assertTrue(packs.any { it.bombsGranted == 650 && it.priceLabel == "9,99 €" })
        assertTrue(packs.any { it.bombsGranted == 2000 && it.priceLabel == "24,99 €" })
        assertTrue(packs.any { it.kind == ShopPackKind.MONDAY_WEEKLY_FC && it.fcGranted == 150 && it.priceLabel == "1,99 €" })
    }

    @Test
    fun survivalMapSpawnsAndWallsHaveTankClearance() {
        val tankDiameter = 1.10f
        val walls = SurvivalMapSpec.createInitialWalls()

        // All spawn points must sit outside walls
        SurvivalMapSpec.spawnPoints.forEach { sp ->
            walls.forEach { w ->
                val cx = sp.x.coerceIn(w.left, w.right)
                val cy = sp.y.coerceIn(w.top, w.bottom)
                val d = hypot(sp.x - cx, sp.y - cy)
                assertTrue("Spawn ${sp.id} too close to ${w.id}: $d", d >= 0.8f)
            }
        }

        // Every pair of walls must either touch or leave >= tankDiameter + 0.5f gap
        for (i in walls.indices) {
            for (j in i + 1 until walls.size) {
                val a = walls[i]
                val b = walls[j]
                val gapX = max(0f, max(b.left - a.right, a.left - b.right))
                val gapY = max(0f, max(b.top - a.bottom, a.top - b.bottom))
                val gap = hypot(gapX, gapY)
                assertTrue("Gap between ${a.id} and ${b.id} too narrow: $gap", gap >= tankDiameter + 0.5f)
            }
        }
    }
}
